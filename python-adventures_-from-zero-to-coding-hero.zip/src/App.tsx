import React, { useState } from 'react';
import { useProgress } from './hooks/useProgress';
import { ALL_CHAPTERS, getChapterByNumber } from './data/chapters';
import { BRANCHING_STORIES } from './data/branchingStoryData';
import { Navbar, NavTab } from './components/Navbar';
import { LandingView } from './components/LandingView';
import { ChapterMapView } from './components/ChapterMapView';
import { ComicReaderView } from './components/ComicReaderView';
import { LessonDetailView } from './components/LessonDetailView';
import { DashboardView } from './components/DashboardView';
import { PrintBookView } from './components/PrintBookView';
import { PlaygroundModal } from './components/PlaygroundModal';
import { DebuggingLabModal } from './components/DebuggingLabModal';
import { QuizModal } from './components/QuizModal';
import { ProjectWorkspaceModal } from './components/ProjectWorkspaceModal';
import { BranchingAdventureModal } from './components/BranchingAdventureModal';
import { CertificateModal } from './components/CertificateModal';
import { AdminDashboardModal } from './components/AdminDashboardModal';
import { AuthRequiredModal } from './components/AuthRequiredModal';
import { PipCharacter, AlexCharacter, ByteCharacter, BugsyCharacter } from './characters/CharacterSvgs';
import { soundFX } from './utils/soundEffects';
import { authService } from './services/authService';
import { UserAccount } from './types/auth';

export default function App() {
  const {
    progress,
    completeLesson,
    saveQuizScore,
    solveDebug,
    completeProject,
    toggleBookmark,
    setUserName,
    toggleSound,
    resetAllProgress,
    unlockAllChapters
  } = useProgress();

  const [activeTab, setActiveTab] = useState<NavTab>('landing');
  const [currentChapterNum, setCurrentChapterNum] = useState<number>(progress.lastVisitedChapter || 1);
  const [currentLessonIdx, setCurrentLessonIdx] = useState<number>(0);

  // Modals state
  const [playgroundCode, setPlaygroundCode] = useState<string | null>(null);
  const [quizChapterNum, setQuizChapterNum] = useState<number | null>(null);
  const [debugChapterNum, setDebugChapterNum] = useState<number | null>(null);
  const [projectChapterNum, setProjectChapterNum] = useState<number | null>(null);
  const [showBranching, setShowBranching] = useState<boolean>(false);
  const [showCertificate, setShowCertificate] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => authService.getCurrentUser());
  const [showAdminConsole, setShowAdminConsole] = useState<boolean>(false);
  const [authRequiredChapter, setAuthRequiredChapter] = useState<{ targetChapter: number; chapterTitle?: string } | null>(null);

  const handleLoginSuccess = (user: UserAccount) => {
    setCurrentUser(user);
    if (user.role === 'student' && user.name) {
      setUserName(user.name);
    }
  };

  const handleLogout = () => {
    authService.logout();
    setCurrentUser(null);
  };

  const handleRequireAuth = (chapterNum: number) => {
    const ch = getChapterByNumber(chapterNum);
    setAuthRequiredChapter({
      targetChapter: chapterNum,
      chapterTitle: ch ? ch.title : `Chapter ${chapterNum}`
    });
  };

  const handleGoToRegister = () => {
    setAuthRequiredChapter(null);
    setActiveTab('landing');
    setTimeout(() => {
      const el = document.getElementById('auth-portal');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handleGoToLogin = () => {
    setAuthRequiredChapter(null);
    setActiveTab('landing');
    setTimeout(() => {
      const el = document.getElementById('auth-portal');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const currentChapter = getChapterByNumber(currentChapterNum) || ALL_CHAPTERS[0];
  const currentLesson = currentChapter.lessons[currentLessonIdx] || currentChapter.lessons[0];

  const handleSelectChapter = (chapterNum: number) => {
    // Only Chapter 1 is public; Chapters 2-20 require registration
    if (chapterNum > 1 && !currentUser) {
      handleRequireAuth(chapterNum);
      return;
    }
    setCurrentChapterNum(chapterNum);
    setCurrentLessonIdx(0);
    setActiveTab('comic_reader');
  };

  const handleOpenQuiz = (chapterNum: number) => {
    if (chapterNum > 1 && !currentUser) {
      handleRequireAuth(chapterNum);
      return;
    }
    setQuizChapterNum(chapterNum);
  };

  const handleOpenDebugLab = (chapterNum: number) => {
    if (chapterNum > 1 && !currentUser) {
      handleRequireAuth(chapterNum);
      return;
    }
    setDebugChapterNum(chapterNum);
  };

  const handleOpenProject = (chapterNum: number) => {
    if (chapterNum > 1 && !currentUser) {
      handleRequireAuth(chapterNum);
      return;
    }
    setProjectChapterNum(chapterNum);
  };

  const handleNextLesson = () => {
    if (currentLessonIdx < currentChapter.lessons.length - 1) {
      setCurrentLessonIdx((prev) => prev + 1);
    } else if (currentChapterNum < 20) {
      const nextNum = currentChapterNum + 1;
      if (nextNum > 1 && !currentUser) {
        handleRequireAuth(nextNum);
        return;
      }
      setCurrentChapterNum(nextNum);
      setCurrentLessonIdx(0);
    }
  };

  const handlePrevLesson = () => {
    if (currentLessonIdx > 0) {
      setCurrentLessonIdx((prev) => prev - 1);
    } else if (currentChapterNum > 1) {
      setCurrentChapterNum((prev) => prev - 1);
      setCurrentLessonIdx(0);
    }
  };

  const handleNextChapter = () => {
    if (currentChapterNum < 20) {
      const nextNum = currentChapterNum + 1;
      if (nextNum > 1 && !currentUser) {
        handleRequireAuth(nextNum);
        return;
      }
      setCurrentChapterNum(nextNum);
      setCurrentLessonIdx(0);
      setActiveTab('comic_reader');
    } else {
      setShowCertificate(true);
    }
  };

  // If in Print View, render full standalone book
  if (activeTab === 'print_view') {
    return <PrintBookView onBack={() => setActiveTab('chapter_map')} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#FFFDF9] text-[#1E293B]">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenPlayground={() => setPlaygroundCode(currentLesson.workedExample.code)}
        onOpenCertificate={() => setShowCertificate(true)}
        onOpenBranchingAdventure={() => setShowBranching(true)}
        streakCount={progress.streakCount}
        soundEnabled={progress.soundEnabled}
        onToggleSound={toggleSound}
        currentChapterNumber={currentChapterNum}
        currentUser={currentUser}
        onOpenAdminConsole={() => setShowAdminConsole(true)}
        onLogout={handleLogout}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 md:py-8">
        {activeTab === 'landing' && (
          <LandingView
            onStartAdventure={() => {
              setCurrentChapterNum(1);
              setCurrentLessonIdx(0);
              setActiveTab('comic_reader');
            }}
            onExploreChapters={() => setActiveTab('chapter_map')}
            onOpenPlayground={(code) => setPlaygroundCode(code || currentLesson.workedExample.code)}
            onStartBranchingAdventure={() => setShowBranching(true)}
            currentUser={currentUser}
            onLoginSuccess={handleLoginSuccess}
            onLogout={handleLogout}
            onOpenAdminConsole={() => setShowAdminConsole(true)}
          />
        )}

        {activeTab === 'chapter_map' && (
          <ChapterMapView
            chapters={ALL_CHAPTERS}
            progress={progress}
            isAuthenticated={currentUser !== null}
            onSelectChapter={handleSelectChapter}
            onOpenQuiz={handleOpenQuiz}
            onOpenDebugLab={handleOpenDebugLab}
            onOpenProject={handleOpenProject}
            onRequireAuth={handleRequireAuth}
          />
        )}

        {activeTab === 'comic_reader' && (
          <ComicReaderView
            chapter={currentChapter}
            lesson={currentLesson}
            onOpenLessonExplanation={() => setActiveTab('lesson_detail')}
            onOpenPlayground={(code) => setPlaygroundCode(code || currentLesson.workedExample.code)}
            isBookmarked={progress.bookmarks.includes(currentLesson.id)}
            onToggleBookmark={() => toggleBookmark(currentLesson.id)}
            onNextLesson={handleNextLesson}
            onPrevLesson={handlePrevLesson}
            onNextChapter={handleNextChapter}
            isAuthenticated={currentUser !== null}
            onRequireAuth={handleRequireAuth}
          />
        )}

        {activeTab === 'lesson_detail' && (
          <LessonDetailView
            chapter={currentChapter}
            lesson={currentLesson}
            onOpenPlayground={(code) => setPlaygroundCode(code)}
            onCompleteLesson={(lId, chNum) => completeLesson(lId, chNum)}
            isCompleted={progress.completedLessons.includes(currentLesson.id)}
            isBookmarked={progress.bookmarks.includes(currentLesson.id)}
            onToggleBookmark={() => toggleBookmark(currentLesson.id)}
            onGoToComic={() => setActiveTab('comic_reader')}
            onNextLesson={handleNextLesson}
          />
        )}

        {activeTab === 'dashboard' && (
          <DashboardView
            progress={progress}
            onResumeLastLesson={() => {
              setCurrentChapterNum(progress.lastVisitedChapter || 1);
              setActiveTab('comic_reader');
            }}
            onSelectChapter={handleSelectChapter}
            onResetProgress={resetAllProgress}
            onOpenCertificate={() => setShowCertificate(true)}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="no-print bg-slate-900 text-white border-t-4 border-amber-400 py-10 px-6 mt-16">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
          <div className="flex items-center gap-3 justify-center md:justify-start">
            <div className="flex -space-x-2">
              <PipCharacter mood="happy" size={42} />
              <AlexCharacter mood="coding" size={42} />
              <ByteCharacter mood="happy" size={42} />
              <BugsyCharacter mood="happy" size={42} />
            </div>
            <div>
              <div className="font-comic text-base tracking-wide text-amber-400">
                PYTHON ADVENTURES
              </div>
              <div className="text-xs text-slate-400">
                From Zero to Coding Hero • Complete 20-Chapter Course
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-bold text-slate-300">
            <button
              onClick={() => setActiveTab('chapter_map')}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              Curriculum Map
            </button>
            <span>•</span>
            <button
              onClick={() => setPlaygroundCode(currentLesson.workedExample.code)}
              className="hover:text-emerald-400 transition-colors cursor-pointer"
            >
              Python Playground
            </button>
            <span>•</span>
            <button
              onClick={() => setShowBranching(true)}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              RPG Story
            </button>
            <span>•</span>
            <button
              onClick={() => setShowCertificate(true)}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              Diploma
            </button>
            <span>•</span>
            <button
              onClick={() => setActiveTab('print_view')}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              Print Edition
            </button>
          </div>

          <div className="text-xs text-slate-500 font-mono">
            Pure In-Browser Runtime • No Setup Required
          </div>
        </div>
      </footer>

      {/* Global Interactive Modals */}
      {playgroundCode !== null && (
        <PlaygroundModal
          initialCode={playgroundCode}
          onClose={() => setPlaygroundCode(null)}
          isModal={true}
        />
      )}

      {quizChapterNum !== null && (
        <QuizModal
          chapterNumber={quizChapterNum}
          chapterTitle={getChapterByNumber(quizChapterNum)?.title || ''}
          questions={getChapterByNumber(quizChapterNum)?.quiz || []}
          onClose={() => setQuizChapterNum(null)}
          onSaveScore={(chNum, score, total) => saveQuizScore(chNum, score, total)}
          previousScore={progress.quizScores[quizChapterNum]}
        />
      )}

      {debugChapterNum !== null && (
        <DebuggingLabModal
          challenge={getChapterByNumber(debugChapterNum)?.debugChallenge!}
          onClose={() => setDebugChapterNum(null)}
          onSolved={(debugId) => solveDebug(debugId)}
          isSolvedAlready={progress.solvedDebugs.includes(
            getChapterByNumber(debugChapterNum)?.debugChallenge.id!
          )}
        />
      )}

      {projectChapterNum !== null && (
        <ProjectWorkspaceModal
          project={getChapterByNumber(projectChapterNum)?.guidedProject!}
          onClose={() => setProjectChapterNum(null)}
          onCompleteProject={(pId) => completeProject(pId)}
          isCompleted={progress.completedProjects.includes(
            getChapterByNumber(projectChapterNum)?.guidedProject.id!
          )}
        />
      )}

      {showBranching && (
        <BranchingAdventureModal
          story={BRANCHING_STORIES.binary_vault}
          onClose={() => setShowBranching(false)}
        />
      )}

      {showCertificate && (
        <CertificateModal
          userName={progress.userName}
          onUpdateUserName={setUserName}
          onClose={() => setShowCertificate(false)}
          chaptersCompletedCount={progress.completedChapters.length}
        />
      )}

      {showAdminConsole && currentUser && (
        <AdminDashboardModal
          currentUser={currentUser}
          onClose={() => setShowAdminConsole(false)}
          onUnlockAllChapters={unlockAllChapters}
        />
      )}

      {authRequiredChapter && (
        <AuthRequiredModal
          targetChapter={authRequiredChapter.targetChapter}
          chapterTitle={authRequiredChapter.chapterTitle}
          onClose={() => setAuthRequiredChapter(null)}
          onGoToRegister={handleGoToRegister}
          onGoToLogin={handleGoToLogin}
        />
      )}
    </div>
  );
}
