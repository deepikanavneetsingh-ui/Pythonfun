import { UserAccount, UserRole } from '../types/auth';

const STORAGE_USERS_KEY = 'python_adventures_accounts_v1';
const STORAGE_CURRENT_USER_KEY = 'python_adventures_active_user_v1';

// Mandatory Pre-configured Admin Account specified by the user
export const DEFAULT_ADMIN: UserAccount = {
  id: 'admin_master_001',
  name: 'Deepika Navneet Singh',
  email: 'deepikanavneetsingh@gmail.com',
  password: 'India@1234',
  role: 'admin',
  createdAt: '2025-01-01T00:00:00.000Z',
  lastLoginAt: '2025-01-01T00:00:00.000Z',
  avatarCharacter: 'pip',
  gradeOrLevel: 'Course Director & Administrator'
};

// Seed student accounts for initial demonstration
const SEED_STUDENTS: UserAccount[] = [
  DEFAULT_ADMIN,
  {
    id: 'student_001',
    name: 'Aarav Sharma',
    email: 'aarav.sharma@example.in',
    password: 'PythonHero@123',
    role: 'student',
    createdAt: '2025-02-10T10:30:00.000Z',
    lastLoginAt: '2025-02-22T08:15:00.000Z',
    avatarCharacter: 'alex',
    gradeOrLevel: 'Grade 8 • New Delhi',
    enrolledChapter: 6
  },
  {
    id: 'student_002',
    name: 'Priya Patel',
    email: 'priya.patel@example.in',
    password: 'CodeWizard@456',
    role: 'student',
    createdAt: '2025-02-14T14:20:00.000Z',
    lastLoginAt: '2025-02-23T11:45:00.000Z',
    avatarCharacter: 'byte',
    gradeOrLevel: 'Grade 10 • Bengaluru',
    enrolledChapter: 12
  },
  {
    id: 'student_003',
    name: 'Rohan Deshmukh',
    email: 'rohan.d@example.in',
    password: 'RoboCoder@789',
    role: 'student',
    createdAt: '2025-02-18T09:10:00.000Z',
    lastLoginAt: '2025-02-21T16:00:00.000Z',
    avatarCharacter: 'bugsy',
    gradeOrLevel: 'Undergraduate • Pune',
    enrolledChapter: 18
  }
];

class AuthService {
  private users: UserAccount[] = [];
  private currentUser: UserAccount | null = null;

  constructor() {
    this.init();
  }

  private init() {
    if (typeof window === 'undefined') return;

    try {
      const storedUsers = localStorage.getItem(STORAGE_USERS_KEY);
      if (storedUsers) {
        this.users = JSON.parse(storedUsers);
        // Ensure admin account always exists and credentials match requirement
        const adminIndex = this.users.findIndex(
          (u) => u.email.toLowerCase() === DEFAULT_ADMIN.email.toLowerCase()
        );
        if (adminIndex === -1) {
          this.users.unshift(DEFAULT_ADMIN);
          this.saveUsers();
        } else {
          // Keep admin password and role in sync with requirement
          if (this.users[adminIndex].password !== DEFAULT_ADMIN.password || this.users[adminIndex].role !== 'admin') {
            this.users[adminIndex].password = DEFAULT_ADMIN.password;
            this.users[adminIndex].role = 'admin';
            this.saveUsers();
          }
        }
      } else {
        this.users = [...SEED_STUDENTS];
        this.saveUsers();
      }

      const storedCurrent = localStorage.getItem(STORAGE_CURRENT_USER_KEY);
      if (storedCurrent) {
        this.currentUser = JSON.parse(storedCurrent);
      }
    } catch (e) {
      console.error('Failed to initialize auth storage:', e);
      this.users = [...SEED_STUDENTS];
      this.currentUser = null;
    }
  }

  private saveUsers() {
    try {
      localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(this.users));
    } catch (e) {
      console.warn('Failed to save users to localStorage:', e);
    }
  }

  private saveCurrentUser() {
    try {
      if (this.currentUser) {
        localStorage.setItem(STORAGE_CURRENT_USER_KEY, JSON.stringify(this.currentUser));
      } else {
        localStorage.removeItem(STORAGE_CURRENT_USER_KEY);
      }
    } catch (e) {
      console.warn('Failed to save session:', e);
    }
  }

  public getCurrentUser(): UserAccount | null {
    return this.currentUser;
  }

  public getAllUsers(): UserAccount[] {
    return [...this.users];
  }

  public login(
    email: string,
    pass: string
  ): { success: boolean; user?: UserAccount; error?: string } {
    const cleanEmail = email.trim().toLowerCase();
    const cleanPass = pass.trim();

    if (!cleanEmail || !cleanPass) {
      return { success: false, error: 'Please enter both email and password.' };
    }

    const matched = this.users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (!matched) {
      return {
        success: false,
        error: 'No account found with this email address. Please register or check spelling.'
      };
    }

    if (matched.password !== cleanPass) {
      return {
        success: false,
        error: 'Incorrect password. Please verify and try again.'
      };
    }

    // Update last login
    matched.lastLoginAt = new Date().toISOString();
    this.saveUsers();

    this.currentUser = { ...matched };
    this.saveCurrentUser();

    return { success: true, user: this.currentUser };
  }

  public register(data: {
    name: string;
    email: string;
    password: string;
    avatarCharacter?: 'pip' | 'alex' | 'byte' | 'bugsy';
    gradeOrLevel?: string;
  }): { success: boolean; user?: UserAccount; error?: string } {
    const cleanEmail = data.email.trim().toLowerCase();
    const cleanName = data.name.trim();
    const cleanPass = data.password.trim();

    if (!cleanName) {
      return { success: false, error: 'Please provide your full name.' };
    }

    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      return { success: false, error: 'Please provide a valid email address.' };
    }

    if (!cleanPass || cleanPass.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters long.' };
    }

    const exists = this.users.some((u) => u.email.toLowerCase() === cleanEmail);
    if (exists) {
      return {
        success: false,
        error: 'An account with this email address already exists. Please log in instead.'
      };
    }

    const newUser: UserAccount = {
      id: `student_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: cleanName,
      email: cleanEmail,
      password: cleanPass,
      role: 'student',
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      avatarCharacter: data.avatarCharacter || 'alex',
      gradeOrLevel: data.gradeOrLevel || 'Python Adventurer',
      enrolledChapter: 1
    };

    this.users.push(newUser);
    this.saveUsers();

    this.currentUser = { ...newUser };
    this.saveCurrentUser();

    return { success: true, user: this.currentUser };
  }

  public logout(): void {
    this.currentUser = null;
    this.saveCurrentUser();
  }

  public deleteUser(userId: string): boolean {
    // Prevent deleting the primary admin
    if (userId === DEFAULT_ADMIN.id || this.users.find(u => u.id === userId)?.email.toLowerCase() === DEFAULT_ADMIN.email.toLowerCase()) {
      return false;
    }
    this.users = this.users.filter((u) => u.id !== userId);
    this.saveUsers();
    if (this.currentUser?.id === userId) {
      this.logout();
    }
    return true;
  }

  public resetUserPassword(userId: string, newPass: string): boolean {
    const target = this.users.find((u) => u.id === userId);
    if (!target) return false;
    target.password = newPass;
    this.saveUsers();
    if (this.currentUser?.id === userId) {
      this.currentUser.password = newPass;
      this.saveCurrentUser();
    }
    return true;
  }

  public toggleUserRole(userId: string): boolean {
    const target = this.users.find((u) => u.id === userId);
    if (!target) return false;
    // Don't downgrade primary admin
    if (target.email.toLowerCase() === DEFAULT_ADMIN.email.toLowerCase()) {
      return false;
    }
    target.role = target.role === 'admin' ? 'student' : 'admin';
    this.saveUsers();
    if (this.currentUser?.id === userId) {
      this.currentUser.role = target.role;
      this.saveCurrentUser();
    }
    return true;
  }

  public addStudentDirectly(user: Omit<UserAccount, 'id' | 'createdAt' | 'lastLoginAt'>): UserAccount {
    const newUser: UserAccount = {
      ...user,
      id: `user_${Date.now()}`,
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString()
    };
    this.users.push(newUser);
    this.saveUsers();
    return newUser;
  }
}

export const authService = new AuthService();
