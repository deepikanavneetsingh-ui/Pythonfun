import React from 'react';

export type CharacterMood = 'happy' | 'thinking' | 'surprised' | 'explaining' | 'coding';

export interface CharacterProps {
  mood?: CharacterMood;
  className?: string;
  size?: number;
  isSpeaking?: boolean;
}

// 1. PIP THE PYTHON - Mascot & Patient Instructor
export const PipCharacter: React.FC<CharacterProps> = ({
  mood = 'happy',
  className = '',
  size = 120,
  isSpeaking = false
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 140 140"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block drop-shadow-sm select-none transition-transform ${
        isSpeaking ? 'animate-character-talking' : ''
      } ${className}`}
      aria-label={`Pip the Python (${mood}${isSpeaking ? ' - Speaking' : ''})`}
    >
      {/* Coiled lower body */}
      <path
        d="M 35 115 C 20 115 15 100 25 85 C 35 70 55 75 60 90 C 65 105 85 115 110 110 C 125 105 130 90 120 80 C 110 70 95 75 90 85"
        stroke="#065F46"
        strokeWidth="18"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M 35 115 C 20 115 15 100 25 85 C 35 70 55 75 60 90 C 65 105 85 115 110 110 C 125 105 130 90 120 80 C 110 70 95 75 90 85"
        stroke="#10B981"
        strokeWidth="12"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Belly belly-scales accent */}
      <path
        d="M 40 115 C 30 115 26 103 33 93 C 40 83 50 86 55 96 C 58 102 70 110 90 110"
        stroke="#FDE047"
        strokeWidth="4"
        strokeLinecap="round"
      />

      {/* Main Head and Neck */}
      <path
        d="M 60 95 C 60 65 65 40 85 30 C 105 20 120 35 115 60 C 110 80 85 85 70 95"
        fill="#10B981"
        stroke="#065F46"
        strokeWidth="4"
      />

      {/* Head highlight */}
      <ellipse cx="98" cy="38" rx="16" ry="12" fill="#34D399" />

      {/* Glasses Frames (Nerd chic for Python) */}
      <circle cx="85" cy="42" r="14" fill="#ECFDF5" stroke="#1E293B" strokeWidth="3" />
      <circle cx="112" cy="42" r="14" fill="#ECFDF5" stroke="#1E293B" strokeWidth="3" />
      <path d="M 99 42 L 98 42" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" />
      <path d="M 71 40 L 65 44" stroke="#1E293B" strokeWidth="3" strokeLinecap="round" />

      {/* Eyes based on mood */}
      {mood === 'happy' && (
        <>
          <path d="M 80 44 Q 85 38 90 44" stroke="#065F46" strokeWidth="3.5" strokeLinecap="round" fill="none" />
          <path d="M 107 44 Q 112 38 117 44" stroke="#065F46" strokeWidth="3.5" strokeLinecap="round" fill="none" />
        </>
      )}
      {mood === 'thinking' && (
        <>
          <circle cx="87" cy="39" r="4.5" fill="#1E293B" />
          <circle cx="114" cy="39" r="4.5" fill="#1E293B" />
          <circle cx="89" cy="37" r="1.5" fill="#FFFFFF" />
          <circle cx="116" cy="37" r="1.5" fill="#FFFFFF" />
        </>
      )}
      {mood === 'surprised' && (
        <>
          <circle cx="85" cy="42" r="6" fill="#1E293B" />
          <circle cx="112" cy="42" r="6" fill="#1E293B" />
          <circle cx="87" cy="40" r="2" fill="#FFFFFF" />
          <circle cx="114" cy="40" r="2" fill="#FFFFFF" />
        </>
      )}
      {(mood === 'explaining' || mood === 'coding') && (
        <>
          <circle cx="86" cy="41" r="5" fill="#047857" />
          <circle cx="113" cy="41" r="5" fill="#047857" />
          <circle cx="88" cy="39" r="2" fill="#FFFFFF" />
          <circle cx="115" cy="39" r="2" fill="#FFFFFF" />
        </>
      )}

      {/* Cheeks */}
      <circle cx="76" cy="54" r="5" fill="#F472B6" opacity="0.6" />
      <circle cx="120" cy="54" r="5" fill="#F472B6" opacity="0.6" />

      {/* Mouth (with dynamic speech viseme) */}
      {isSpeaking ? (
        <g className="animate-mouth-flap" style={{ transformOrigin: '100px 62px' }}>
          <ellipse cx="100" cy="62" rx="7" ry="6" fill="#1E293B" />
          <ellipse cx="100" cy="63" rx="4.5" ry="3.5" fill="#EF4444" />
        </g>
      ) : mood === 'surprised' ? (
        <ellipse cx="100" cy="62" rx="4" ry="6" fill="#1E293B" />
      ) : mood === 'thinking' ? (
        <path d="M 94 62 Q 99 60 106 62" stroke="#065F46" strokeWidth="3" strokeLinecap="round" fill="none" />
      ) : (
        <path d="M 92 60 Q 100 68 108 60" stroke="#065F46" strokeWidth="3.5" strokeLinecap="round" fill="none" />
      )}

      {/* Tiny celebratory tongue */}
      {mood === 'happy' && !isSpeaking && (
        <path d="M 100 64 C 101 68 103 72 101 76 M 101 76 L 98 79 M 101 76 L 104 79" stroke="#EF4444" strokeWidth="2.5" strokeLinecap="round" />
      )}

      {/* Small Python blue/yellow bookmark badge on tail */}
      <g transform="translate(18, 92)">
        <path d="M 0 0 L 14 0 L 14 18 L 7 14 L 0 18 Z" fill="#3B82F6" stroke="#1E293B" strokeWidth="2" />
        <path d="M 4 2 L 10 2 L 10 12 L 7 10 L 4 12 Z" fill="#FBBF24" />
      </g>
    </svg>
  );
};

// 2. ALEX THE BEGINNER - The Curious Learner
export const AlexCharacter: React.FC<CharacterProps> = ({
  mood = 'happy',
  className = '',
  size = 120,
  isSpeaking = false
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 140 140"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block drop-shadow-sm select-none transition-transform ${
        isSpeaking ? 'animate-character-talking' : ''
      } ${className}`}
      aria-label={`Alex the Beginner (${mood}${isSpeaking ? ' - Speaking' : ''})`}
    >
      {/* Hoodie Body */}
      <path
        d="M 30 135 C 32 105 45 92 70 92 C 95 92 108 105 110 135 Z"
        fill="#F59E0B"
        stroke="#1E293B"
        strokeWidth="3.5"
      />
      {/* Hoodie Collar & Drawstrings */}
      <path d="M 58 95 C 64 108 76 108 82 95" fill="#D97706" stroke="#1E293B" strokeWidth="3" />
      <path d="M 64 105 L 63 120 M 76 105 L 77 120" stroke="#FEF3C7" strokeWidth="2.5" strokeLinecap="round" />

      {/* Neck */}
      <rect x="62" y="80" width="16" height="15" fill="#FCD34D" stroke="#1E293B" strokeWidth="2.5" rx="3" />

      {/* Head / Face */}
      <ellipse cx="70" cy="58" rx="26" ry="28" fill="#FDE68A" stroke="#1E293B" strokeWidth="3.5" />

      {/* Hair (Messy brown adventurer cut) */}
      <path
        d="M 43 54 C 40 35 55 24 72 24 C 92 24 102 36 97 54 C 93 42 85 36 76 38 C 65 40 55 38 43 54 Z"
        fill="#78350F"
        stroke="#1E293B"
        strokeWidth="3"
      />
      <path d="M 72 22 Q 76 12 84 18" stroke="#78350F" strokeWidth="4" strokeLinecap="round" />

      {/* Eyebrows */}
      {mood === 'thinking' ? (
        <>
          <path d="M 52 46 Q 60 49 64 45" stroke="#78350F" strokeWidth="3" strokeLinecap="round" />
          <path d="M 76 43 Q 82 40 88 44" stroke="#78350F" strokeWidth="3" strokeLinecap="round" />
        </>
      ) : mood === 'surprised' ? (
        <>
          <path d="M 52 42 Q 60 38 64 40" stroke="#78350F" strokeWidth="3" strokeLinecap="round" />
          <path d="M 76 40 Q 80 38 88 42" stroke="#78350F" strokeWidth="3" strokeLinecap="round" />
        </>
      ) : (
        <>
          <path d="M 54 44 Q 60 41 65 44" stroke="#78350F" strokeWidth="3" strokeLinecap="round" />
          <path d="M 75 44 Q 80 41 86 44" stroke="#78350F" strokeWidth="3" strokeLinecap="round" />
        </>
      )}

      {/* Eyes */}
      {mood === 'happy' && (
        <>
          <path d="M 55 54 Q 60 48 65 54" stroke="#1E293B" strokeWidth="3.5" strokeLinecap="round" fill="none" />
          <path d="M 75 54 Q 80 48 85 54" stroke="#1E293B" strokeWidth="3.5" strokeLinecap="round" fill="none" />
        </>
      )}
      {mood === 'surprised' && (
        <>
          <circle cx="60" cy="52" r="5" fill="#1E293B" />
          <circle cx="80" cy="52" r="5" fill="#1E293B" />
          <circle cx="62" cy="50" r="1.5" fill="#FFFFFF" />
          <circle cx="82" cy="50" r="1.5" fill="#FFFFFF" />
        </>
      )}
      {(mood === 'thinking' || mood === 'explaining' || mood === 'coding') && (
        <>
          <circle cx="60" cy="52" r="4.5" fill="#1E293B" />
          <circle cx="80" cy="52" r="4.5" fill="#1E293B" />
          <circle cx="61.5" cy="50.5" r="1.5" fill="#FFFFFF" />
          <circle cx="81.5" cy="50.5" r="1.5" fill="#FFFFFF" />
        </>
      )}

      {/* Nose */}
      <path d="M 70 56 Q 72 61 68 62" stroke="#D97706" strokeWidth="2.5" strokeLinecap="round" fill="none" />

      {/* Cheeks */}
      <circle cx="52" cy="62" r="4.5" fill="#F87171" opacity="0.5" />
      <circle cx="88" cy="62" r="4.5" fill="#F87171" opacity="0.5" />

      {/* Mouth (with dynamic speech viseme) */}
      {isSpeaking ? (
        <g className="animate-mouth-flap" style={{ transformOrigin: '70px 71px' }}>
          <ellipse cx="70" cy="71" rx="8" ry="6" fill="#1E293B" />
          <ellipse cx="70" cy="72" rx="5" ry="3.5" fill="#EF4444" />
        </g>
      ) : mood === 'surprised' ? (
        <ellipse cx="70" cy="71" rx="5" ry="7" fill="#1E293B" />
      ) : mood === 'thinking' ? (
        <path d="M 64 71 Q 70 69 75 72" stroke="#1E293B" strokeWidth="3" strokeLinecap="round" fill="none" />
      ) : (
        <path d="M 63 68 Q 70 76 77 68" stroke="#1E293B" strokeWidth="3.5" strokeLinecap="round" fill="none" />
      )}

      {/* If coding, show small laptop rim at bottom */}
      {mood === 'coding' && (
        <g transform="translate(42, 114)">
          <rect x="0" y="0" width="56" height="20" rx="3" fill="#64748B" stroke="#1E293B" strokeWidth="2" />
          <path d="M 28 6 L 28 12" stroke="#38BDF8" strokeWidth="2" strokeLinecap="round" />
        </g>
      )}
    </svg>
  );
};

// 3. BYTE THE ROBOT - Literal-Minded Helper Machine
export const ByteCharacter: React.FC<CharacterProps> = ({
  mood = 'happy',
  className = '',
  size = 120,
  isSpeaking = false
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 140 140"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block drop-shadow-sm select-none transition-transform ${
        isSpeaking ? 'animate-character-talking' : ''
      } ${className}`}
      aria-label={`Byte the Robot (${mood}${isSpeaking ? ' - Speaking' : ''})`}
    >
      {/* Antenna */}
      <path d="M 70 32 L 70 18" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" />
      <circle
        cx="70"
        cy="14"
        r="8"
        fill={isSpeaking ? '#38BDF8' : mood === 'surprised' ? '#EF4444' : '#FBBF24'}
        stroke="#1E293B"
        strokeWidth="3"
        className={isSpeaking ? 'animate-ping' : ''}
      />
      {(mood === 'surprised' || isSpeaking) && (
        <path d="M 64 8 L 76 8 M 70 2 L 70 14" stroke={isSpeaking ? '#38BDF8' : '#EF4444'} strokeWidth="2" strokeLinecap="round" />
      )}

      {/* Robot Ears / Bolts */}
      <rect x="24" y="52" width="8" height="18" rx="2" fill="#94A3B8" stroke="#1E293B" strokeWidth="3" />
      <rect x="108" y="52" width="8" height="18" rx="2" fill="#94A3B8" stroke="#1E293B" strokeWidth="3" />

      {/* Head Chassis */}
      <rect x="30" y="32" width="80" height="60" rx="14" fill="#38BDF8" stroke="#1E293B" strokeWidth="4" />

      {/* Screen Monitor Face */}
      <rect x="40" y="42" width="60" height="40" rx="8" fill="#0F172A" stroke="#1E293B" strokeWidth="2.5" />

      {/* Screen LED Eyes / Expressions or Speech Equalizer */}
      {isSpeaking ? (
        <g>
          {/* Animated robotic equalizer bars on Byte's face */}
          <rect x="46" y="56" width="3.5" height="10" rx="1" fill="#38BDF8" className="animate-eq-1" />
          <rect x="52" y="50" width="3.5" height="18" rx="1" fill="#34D399" className="animate-eq-2" />
          <rect x="58" y="54" width="3.5" height="13" rx="1" fill="#FBBF24" className="animate-eq-3" />
          <rect x="64" y="48" width="3.5" height="20" rx="1" fill="#38BDF8" className="animate-eq-4" />
          <rect x="70" y="52" width="3.5" height="16" rx="1" fill="#34D399" className="animate-eq-1" />
          <rect x="76" y="55" width="3.5" height="12" rx="1" fill="#F87171" className="animate-eq-2" />
          <rect x="82" y="49" width="3.5" height="18" rx="1" fill="#FBBF24" className="animate-eq-3" />
          <rect x="88" y="53" width="3.5" height="14" rx="1" fill="#38BDF8" className="animate-eq-4" />
        </g>
      ) : mood === 'happy' ? (
        <>
          <path d="M 48 60 L 53 54 L 58 60" stroke="#34D399" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
          <path d="M 82 60 L 87 54 L 92 60" stroke="#34D399" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
          <path d="M 64 68 Q 70 72 76 68" stroke="#34D399" strokeWidth="2.5" strokeLinecap="round" fill="none" />
        </>
      ) : mood === 'surprised' ? (
        <>
          <rect x="49" y="52" width="8" height="14" rx="2" fill="#F87171" />
          <rect x="83" y="52" width="8" height="14" rx="2" fill="#F87171" />
          <circle cx="70" cy="70" r="4" fill="#F87171" />
        </>
      ) : mood === 'thinking' ? (
        <>
          <path d="M 48 56 H 58" stroke="#38BDF8" strokeWidth="3.5" strokeLinecap="round" />
          <circle cx="87" cy="56" r="4" fill="#38BDF8" />
          <path d="M 63 68 H 77" stroke="#38BDF8" strokeWidth="2.5" strokeLinecap="round" />
        </>
      ) : (
        <>
          <rect x="48" y="54" width="10" height="8" rx="2" fill="#38BDF8" />
          <rect x="82" y="54" width="10" height="8" rx="2" fill="#38BDF8" />
          <path d="M 62 68 H 78" stroke="#38BDF8" strokeWidth="3" strokeLinecap="round" />
        </>
      )}

      {/* Robot Body / Shoulders */}
      <path
        d="M 38 92 L 34 135 H 106 L 102 92 Z"
        fill="#0284C7"
        stroke="#1E293B"
        strokeWidth="4"
      />
      {/* Chest Meter / Dials */}
      <circle cx="56" cy="112" r="7" fill="#0F172A" stroke="#1E293B" strokeWidth="2" />
      <path d="M 56 112 L 60 108" stroke="#FBBF24" strokeWidth="2" strokeLinecap="round" />
      <rect x="72" y="108" width="22" height="8" rx="2" fill="#0F172A" />
      <path d="M 75 112 H 88" stroke="#34D399" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
};

// 4. BUGSY THE BUG - Playful Debugging Mascot
export const BugsyCharacter: React.FC<CharacterProps> = ({
  mood = 'happy',
  className = '',
  size = 120,
  isSpeaking = false
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 140 140"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block drop-shadow-sm select-none transition-transform ${
        isSpeaking ? 'animate-character-talking' : ''
      } ${className}`}
      aria-label={`Bugsy the Debugging Bug (${mood}${isSpeaking ? ' - Speaking' : ''})`}
    >
      {/* Antennae */}
      <path d="M 55 35 Q 40 15 28 22" stroke="#1E293B" strokeWidth="3.5" strokeLinecap="round" fill="none" />
      <circle cx="28" cy="22" r="4.5" fill="#F43F5E" stroke="#1E293B" strokeWidth="2" />
      <path d="M 85 35 Q 100 15 112 22" stroke="#1E293B" strokeWidth="3.5" strokeLinecap="round" fill="none" />
      <circle cx="112" cy="22" r="4.5" fill="#F43F5E" stroke="#1E293B" strokeWidth="2" />

      {/* Tiny translucent wings (flutter when speaking) */}
      <ellipse
        cx="40"
        cy="70"
        rx="20"
        ry="12"
        transform="rotate(-30 40 70)"
        fill="#E0E7FF"
        opacity="0.8"
        stroke="#1E293B"
        strokeWidth="2.5"
        className={isSpeaking ? 'animate-wing-flutter' : ''}
      />
      <ellipse
        cx="100"
        cy="70"
        rx="20"
        ry="12"
        transform="rotate(30 100 70)"
        fill="#E0E7FF"
        opacity="0.8"
        stroke="#1E293B"
        strokeWidth="2.5"
        className={isSpeaking ? 'animate-wing-flutter' : ''}
      />

      {/* Bug Legs */}
      <path d="M 38 85 L 20 95 M 38 100 L 22 112 M 102 85 L 120 95 M 102 100 L 118 112" stroke="#1E293B" strokeWidth="3.5" strokeLinecap="round" />

      {/* Beetle Body */}
      <ellipse cx="70" cy="90" rx="36" ry="34" fill="#A855F7" stroke="#1E293B" strokeWidth="4" />

      {/* Wing cover divider line & polka dots */}
      <path d="M 70 65 L 70 124" stroke="#1E293B" strokeWidth="3" />
      <circle cx="54" cy="85" r="5" fill="#7E22CE" />
      <circle cx="56" cy="106" r="4" fill="#7E22CE" />
      <circle cx="86" cy="85" r="5" fill="#7E22CE" />
      <circle cx="84" cy="106" r="4" fill="#7E22CE" />

      {/* Bug Head */}
      <circle cx="70" cy="50" r="24" fill="#C084FC" stroke="#1E293B" strokeWidth="3.5" />

      {/* Big Expressive Eyes */}
      <circle cx="58" cy="46" r="8" fill="#FFFFFF" stroke="#1E293B" strokeWidth="2.5" />
      <circle cx="82" cy="46" r="8" fill="#FFFFFF" stroke="#1E293B" strokeWidth="2.5" />
      
      {mood === 'happy' ? (
        <>
          <circle cx="60" cy="46" r="4" fill="#1E293B" />
          <circle cx="80" cy="46" r="4" fill="#1E293B" />
          <circle cx="61.5" cy="44.5" r="1.5" fill="#FFFFFF" />
          <circle cx="81.5" cy="44.5" r="1.5" fill="#FFFFFF" />
        </>
      ) : mood === 'thinking' ? (
        <>
          <circle cx="56" cy="44" r="4" fill="#1E293B" />
          <circle cx="80" cy="44" r="4" fill="#1E293B" />
        </>
      ) : (
        <>
          <circle cx="59" cy="48" r="4.5" fill="#1E293B" />
          <circle cx="81" cy="48" r="4.5" fill="#1E293B" />
        </>
      )}

      {/* Mouth (with dynamic speech viseme) */}
      {isSpeaking ? (
        <g className="animate-mouth-flap" style={{ transformOrigin: '70px 58px' }}>
          <ellipse cx="70" cy="58" rx="6" ry="5" fill="#1E293B" />
          <ellipse cx="70" cy="59" rx="3.5" ry="2.5" fill="#F43F5E" />
        </g>
      ) : (
        <path d="M 64 56 Q 70 62 76 56" stroke="#1E293B" strokeWidth="3" strokeLinecap="round" fill="none" />
      )}

      {/* Bugsy's signature detective magnifying glass */}
      <g transform="translate(86, 75)">
        <circle cx="14" cy="14" r="10" fill="#67E8F9" fillOpacity="0.4" stroke="#1E293B" strokeWidth="3" />
        <path d="M 21 21 L 32 32" stroke="#B45309" strokeWidth="4" strokeLinecap="round" />
      </g>
    </svg>
  );
};

// Comic Sound FX badge
export const ComicSoundFx: React.FC<{ text: string; color?: string; className?: string }> = ({
  text,
  color = '#F59E0B',
  className = '',
}) => {
  return (
    <div
      className={`inline-block font-comic px-3 py-1 text-sm md:text-base tracking-wider uppercase text-white font-extrabold transform -rotate-6 select-none ${className}`}
      style={{
        backgroundColor: color,
        border: '3px solid #1E293B',
        boxShadow: '3px 3px 0px #1E293B',
        borderRadius: '6px',
        textShadow: '1px 1px 0px #1E293B',
      }}
    >
      {text}
    </div>
  );
};
