import { Achievement } from '../types/curriculum';

export const ALL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_program',
    title: 'First Program',
    description: 'Executed your very first Python program with print()!',
    icon: '🚀',
    category: 'code'
  },
  {
    id: 'variable_explorer',
    title: 'Variable Explorer',
    description: 'Created and updated named memory boxes in Python.',
    icon: '📦',
    category: 'milestone'
  },
  {
    id: 'math_magician',
    title: 'Math Magician',
    description: 'Performed integer and float calculations with arithmetic operators.',
    icon: '⚡',
    category: 'code'
  },
  {
    id: 'text_wizard',
    title: 'Text Wizard',
    description: 'Combined strings, sliced text, and mastered Python f-strings.',
    icon: '✨',
    category: 'milestone'
  },
  {
    id: 'interactive_master',
    title: 'Interactive Master',
    description: 'Used input() to converse with users and safely cast types.',
    icon: '💬',
    category: 'code'
  },
  {
    id: 'decision_maker',
    title: 'Decision Maker',
    description: 'Taught computers how to make smart choices using if, elif, and else.',
    icon: '🚦',
    category: 'milestone'
  },
  {
    id: 'logic_knight',
    title: 'Logic Knight',
    description: 'Mastered boolean expressions, truth tables, and compound conditions.',
    icon: '🛡️',
    category: 'milestone'
  },
  {
    id: 'loop_explorer',
    title: 'Loop Explorer',
    description: 'Conquered repetition with for and while loops without infinite traps.',
    icon: '🔄',
    category: 'milestone'
  },
  {
    id: 'collection_keeper',
    title: 'Collection Keeper',
    description: 'Organized dynamic inventories with Python lists, dictionaries, and tuples.',
    icon: '📚',
    category: 'milestone'
  },
  {
    id: 'function_builder',
    title: 'Function Builder',
    description: 'Created custom reusable functions with parameters and return values.',
    icon: '🧩',
    category: 'code'
  },
  {
    id: 'bug_detective',
    title: 'Bug Detective',
    description: 'Solved challenging debugging puzzles in Bugsy\'s laboratory.',
    icon: '🔍',
    category: 'debug'
  },
  {
    id: 'quiz_ace',
    title: 'Quiz Ace',
    description: 'Scored 100% on a chapter assessment test.',
    icon: '🏆',
    category: 'quiz'
  },
  {
    id: 'project_creator',
    title: 'Project Creator',
    description: 'Built practical real-world Python applications.',
    icon: '🛠️',
    category: 'milestone'
  },
  {
    id: 'seven_day_streak',
    title: '7 Day Streak',
    description: 'Maintained an active coding streak for 7 consecutive days!',
    icon: '🔥',
    category: 'milestone'
  },
  {
    id: 'first_5_chapters',
    title: 'Completed First 5 Chapters',
    description: 'Mastered Act 1: The First Spark (Chapters 1 through 5)!',
    icon: '🌟',
    category: 'milestone'
  },
  {
    id: 'python_hero',
    title: 'Python Hero',
    description: 'Completed the grand Chapter 20 graduation adventure capstone!',
    icon: '👑',
    category: 'hero'
  }
];
