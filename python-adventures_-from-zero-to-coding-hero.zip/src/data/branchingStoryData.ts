import { BranchingStory } from '../types/curriculum';

export const BRANCHING_STORIES: Record<string, BranchingStory> = {
  binary_vault: {
    id: 'binary_vault',
    title: 'The Mystery of the Binary Vault',
    startNodeId: 'vault_entrance',
    nodes: {
      vault_entrance: {
        id: 'vault_entrance',
        speaker: 'alex',
        mood: 'thinking',
        situationText: 'Alex, Pip, and Byte arrive at the ancient obsidian Binary Vault in the Silicon Mountains. The heavy stone doors have an LED readout that says: "INPUT SECURITY TOKEN". A sign on the wall reads: # Hint: Check if token is positive and divisible by 2.',
        codeDisplay: `token = 42\n# What decision should the gate check?`,
        choices: [
          {
            text: 'Inspect the door mechanism with Byte (Use if token > 0 and token % 2 == 0:)',
            pythonSnippet: 'if token > 0 and token % 2 == 0:\n    open_door()',
            feedback: 'Spot on! token 42 is positive AND divisible by 2 with no remainder! The giant vault gears click open.',
            leadsToNodeId: 'inside_hall',
            isEducationalSuccess: true
          },
          {
            text: 'Force the lock with a single equals sign (if token = 42:)',
            pythonSnippet: 'if token = 42:\n    open_door()',
            feedback: 'SyntaxError: invalid syntax! Bugsy pops out: "Single = is for assigning, not comparing! You jammed the scanner!"',
            leadsToNodeId: 'trap_room',
            isEducationalSuccess: false
          },
          {
            text: 'Ask Pip to read the mysterious glyph on the stone',
            pythonSnippet: 'clue = "The answer is hidden in even numbers"\nprint("even" in clue)',
            feedback: 'Pip smiles: "The glyph confirms we need an even number! 42 is divisible by 2."',
            leadsToNodeId: 'vault_entrance',
            isEducationalSuccess: true
          }
        ]
      },
      trap_room: {
        id: 'trap_room',
        speaker: 'bugsy',
        mood: 'happy',
        situationText: 'You fell through a trapdoor into Bugsy\'s Puzzle Pit! Spikes of code error messages line the walls! To lower the emergency rope ladder, Byte needs an exact countdown loop.',
        codeDisplay: `# How should Byte count down from 3 to 1?\nfor i in range(3, 0, -1):\n    lower_ladder()`,
        choices: [
          {
            text: 'Run the countdown for loop: for i in range(3, 0, -1):',
            pythonSnippet: 'for i in range(3, 0, -1):\n    print(f"Lowering rope step {i}...")',
            feedback: '3... 2... 1... The rope ladder deploys safely! You climb back up to the entrance hall.',
            leadsToNodeId: 'inside_hall',
            isEducationalSuccess: true
          },
          {
            text: 'Try an infinite while loop without updating the counter',
            pythonSnippet: 'count = 3\nwhile count > 0:\n    print("Lowering ladder...")',
            feedback: 'TimeoutError! Byte freezes in an endless loop! Pip hits the emergency reset switch.',
            leadsToNodeId: 'trap_room',
            isEducationalSuccess: false
          }
        ]
      },
      inside_hall: {
        id: 'inside_hall',
        speaker: 'byte',
        mood: 'coding',
        situationText: 'You enter the Grand Archive of Python! In the center of the hall rests the legendary Golden USB of Guido. But two pedestal guardians challenge your collection knowledge: one pedestal wants a List, the other wants a Dictionary!',
        codeDisplay: `chest_key = {"name": "Citadel Key", "level": 10}\nloot_bag = ["Golden USB", "Emerald Ruby"]`,
        choices: [
          {
            text: 'Place the key on the Dictionary pedestal (look up key["name"])',
            pythonSnippet: 'if chest_key.get("level", 0) >= 10:\n    claim_treasure()',
            feedback: 'BEEP! Perfect key-value match! The pedestal recognizes Citadel Key level 10 and lowers the force field!',
            leadsToNodeId: 'treasure_chamber',
            isEducationalSuccess: true
          },
          {
            text: 'Try to access chest_key[0] using an integer index',
            pythonSnippet: 'print(chest_key[0])',
            feedback: 'KeyError: 0! Dictionaries use named keys, not index numbers! The pedestal zaps with harmless static.',
            leadsToNodeId: 'inside_hall',
            isEducationalSuccess: false
          }
        ]
      },
      treasure_chamber: {
        id: 'treasure_chamber',
        speaker: 'pip',
        mood: 'happy',
        situationText: 'VICTORY! You claimed the Golden USB of Python Wisdom! You mastered conditionals, loops, dictionaries, and error handling along the way!',
        choices: [
          {
            text: 'Celebrate and return to the Chapter Map to continue your adventure!',
            pythonSnippet: 'print("Python Adventure Quest Complete! ⭐⭐⭐")',
            feedback: 'Hooray! Achievement Unlocked: Binary Vault Explorer!',
            leadsToNodeId: 'vault_entrance',
            isEducationalSuccess: true
          }
        ]
      }
    }
  }
};
