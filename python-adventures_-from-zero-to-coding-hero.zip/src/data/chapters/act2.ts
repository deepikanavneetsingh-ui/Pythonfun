import { Chapter } from '../../types/curriculum';

export const ACT2_CHAPTERS: Chapter[] = [
  // CHAPTER 6
  {
    number: 6,
    act: 2,
    actTitle: 'Act 2: Logic & Control',
    title: 'Input and Interaction',
    subtitle: 'Listening to the user and converting data types',
    tagline: 'Programs become alive when they listen and respond.',
    icon: '💬',
    summary: 'Teach your code to ask questions with input(), discover why all inputs arrive as text, and learn how to safely convert text into integers or floats.',
    lessons: [
      {
        id: 'ch6-l1',
        chapterNumber: 6,
        lessonNumber: 1,
        title: 'Asking Questions with input()',
        objective: 'Collect user responses and convert string inputs into numbers with int().',
        comicPanels: [
          {
            id: 'c6-p1',
            speaker: 'alex',
            mood: 'coding',
            dialogue: 'Up until now, we gave the computer all the numbers. How do we let a real player type their own answer?',
            visualAction: 'Alex points to a blinking cursor in a terminal prompt.'
          },
          {
            id: 'c6-p2',
            speaker: 'byte',
            mood: 'surprised',
            dialogue: 'Activate INPUT sensor! When you call input("What is your name? "), I pause and wait for the human to press Enter!',
            visualAction: 'Byte pauses with an animated waiting hour-glass on its screen.',
            soundFx: 'WAIT...',
            soundFxColor: '#0284C7'
          },
          {
            id: 'c6-p3',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'Important secret: input() ALWAYS gives you text (a string), even if the user typed "10"! To do math with it, wrap it in int()!',
            visualAction: 'Pip shows the number 10 wrapped inside a text envelope stamped "str".',
            soundFx: 'AHA!',
            soundFxColor: '#10B981'
          }
        ],
        realLifeProblem: 'When you sign up for an app, you type your birth year. The app receives the letters "2", "0", "1", "0". To calculate your age, it must first convert those letters into an actual integer number!',
        analogy: {
          title: 'The Letterbox Envelope',
          description: 'input() delivers whatever the user types inside a string envelope. If they typed 25, you receive "25". Calling int("25") opens the envelope and pulls out the real number 25.',
          icon: '✉️'
        },
        conceptText: 'The input() function prompts the user and returns their typed text as a string. Because Python will not let you do math on raw text, use int(response) for whole numbers or float(response) for decimals.',
        syntaxRules: [
          'name = input("Enter your name: ") pauses and collects text.',
          'Always remember: input() returns a string, even if numbers are typed.',
          'Use int(input("Age: ")) to convert input directly into an integer.'
        ],
        workedExample: {
          id: 'ex-6-1',
          title: 'Calculating Age from User Input',
          code: `# Ask user for their birth year
birth_year_text = input("What year were you born? ")
birth_year = int(birth_year_text)

current_year = 2026
age = current_year - birth_year

print(f"You will turn {age} years old this year!")`,
          expectedOutput: 'What year were you born? 2000\nYou will turn 26 years old this year!',
          lineByLine: [
            { line: 2, code: 'birth_year_text = input(...)', explanation: 'Waits for user input and saves response as text.' },
            { line: 3, code: 'birth_year = int(birth_year_text)', explanation: 'Converts the text into a real integer for math calculations.' },
            { line: 6, code: 'age = current_year - birth_year', explanation: 'Performs arithmetic calculation with two integer values.' },
            { line: 8, code: 'print(f"You will turn {age}...")', explanation: 'Outputs the result cleanly in an f-string.' }
          ],
          newlyIntroduced: ['input()', 'int() type conversion', 'Interactive program flow']
        },
        prediction: {
          question: 'If user enters 5 for num1 and 5 for num2 in: num1 = input()\nnum2 = input()\nprint(num1 + num2)',
          codeSnippet: `num1 = input()  # User types 5\nnum2 = input()  # User types 5\nprint(num1 + num2)`,
          options: ['10', '55', 'Error', '5 + 5'],
          correctIndex: 1,
          explanation: 'Because input() returns strings, "5" + "5" glues the two text characters together, producing "55" instead of 10! You must convert them with int() first.'
        },
        practiceChallenge: {
          title: 'Currency Converter Quest',
          prompt: 'Write a program that asks for gold coins with input("Gold: "), converts it to an integer, multiplies by 10 to get silver coins, and prints: "That equals {silver} silver coins!"',
          starterCode: '# Ask for gold and calculate silver below:\n',
          solutionCode: `gold = int(input("Gold: "))
silver = gold * 10
print(f"That equals {silver} silver coins!")`,
          hints: [
            'Use int(input("Gold: ")) to get the number directly.',
            'Multiply gold by 10 to get silver.',
            'Use an f-string to print the sentence.'
          ]
        },
        commonMistake: {
          title: 'Trying to Do Math on Raw Input',
          badCode: `age = input("Enter age: ")\nnext_year = age + 1`,
          whyItFails: 'Python raises TypeError: can only concatenate str (not "int") to str. age is still a string!',
          fixedCode: `age = int(input("Enter age: "))\nnext_year = age + 1`,
          tip: 'Always wrap numeric inputs in int() or float() before math.'
        },
        threeKeyTakeaways: [
          'input() prompts the user and captures their keyboard input.',
          'All input() results are strings by default.',
          'Use int() or float() to transform text numbers into actual mathematical values.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q6-1',
        question: 'What is the return type of input() in Python?',
        options: ['Always an integer', 'Always a string', 'It automatically detects the type', 'A boolean'],
        correctIndex: 1,
        explanation: 'input() always returns text (str), regardless of whether the user typed letters, symbols, or digits.',
        misconceptionHint: 'Even if you type 999, Python receives it as the string "999".'
      },
      {
        id: 'q6-2',
        question: 'What happens if you run int("hello")?',
        options: [
          'It converts it to 0.',
          'It raises a ValueError because "hello" cannot be parsed as a base-10 number.',
          'It returns the length of the word.',
          'It deletes the letters.'
        ],
        correctIndex: 1,
        explanation: 'int() only works on text that represents valid numbers (e.g., "42"). Words cause a ValueError.',
        misconceptionHint: 'Python cannot turn ordinary words into numbers.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch6',
      title: 'The String Multiplication Mystery',
      scenario: 'Alex asked the player for their favorite number (3) and wanted to double it (6), but Python printed "33"!',
      buggyCode: `number = input("Favorite number: ")
# Alex forgot to convert to int!
doubled = number * 2
print("Doubled:", doubled)`,
      fixedCode: `number = int(input("Favorite number: "))
doubled = number * 2
print("Doubled:", doubled)`,
      errorType: 'LogicError',
      hint1Line: 'Look at line 1 where number is captured.',
      hint2Concept: 'In Python, multiplying a string by 2 repeats the string: "3" * 2 is "33"!',
      hint3Fix: 'Wrap input(...) inside int(...) on line 1.',
      explanation: 'Multiplying a string repeats it ("ha" * 3 = "hahaha"). To perform mathematical multiplication, convert the input string to an integer with int().'
    },
    guidedProject: {
      id: 'proj-ch6',
      chapterNumber: 6,
      title: 'Interactive Hero Questionnaire',
      description: 'Build an interactive character questionnaire that asks for hero name, favorite color, and power level, then prints a superhero card.',
      requirements: [
        'Ask hero for their name using input().',
        'Ask hero for power level (1-100) and convert to int().',
        'Calculate next_level_power as power_level + 15.',
        'Print a celebratory summary card.'
      ],
      planningSteps: [
        'Step 1: Prompt for name.',
        'Step 2: Prompt and convert power level.',
        'Step 3: Calculate boosted power.',
        'Step 4: Output hero profile.'
      ],
      pseudocode: 'name = INPUT "Hero Name: "\npower = INT(INPUT "Power Level (1-100): ")\nboost = power + 15\nPRINT f"Hero {name} registered! Boosted Power: {boost}"',
      starterCode: '# Build your interactive hero questionnaire below:\n',
      solutionCode: `name = input("Hero Name: ")
power = int(input("Power Level: "))
boost = power + 15

print(f"Hero {name} registered! Boosted Power: {boost}")`,
      verificationTips: [
        'Check that power is wrapped in int().',
        'Ensure the boosted power calculation adds 15.'
      ]
    }
  },

  // CHAPTER 7
  {
    number: 7,
    act: 2,
    actTitle: 'Act 2: Logic & Control',
    title: 'Decisions with Conditions',
    subtitle: 'Booleans, comparison operators, and if / elif / else',
    tagline: 'Code that makes decisions is code that has intelligence.',
    icon: '🚦',
    summary: 'Teach your code to evaluate truth with comparisons (==, !=, <, >), make decisions with if / elif / else, and master Python\'s famous indentation.',
    lessons: [
      {
        id: 'ch7-l1',
        chapterNumber: 7,
        lessonNumber: 1,
        title: 'Making Choices with if, elif, and else',
        objective: 'Write conditional branches that execute code only when conditions are True.',
        comicPanels: [
          {
            id: 'c7-p1',
            speaker: 'alex',
            mood: 'thinking',
            dialogue: 'We reached a fork in the road! A wooden door and an iron gate. How does code choose which one to open?',
            visualAction: 'Alex points to two pathways with different colored doors.'
          },
          {
            id: 'c7-p2',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'We ask a question that evaluates to True or False! That is called a Boolean. If the answer is True, Python follows that path!',
            visualAction: 'Pip flips a coin showing "True" on one side and "False" on the other.',
            soundFx: 'FLIP!',
            soundFxColor: '#10B981'
          },
          {
            id: 'c7-p3',
            speaker: 'byte',
            mood: 'coding',
            dialogue: 'Watch my indentation! Python uses 4 spaces to know which instructions belong inside the if block. No spaces, no block!',
            visualAction: 'Byte projects four glowing alignment guides.'
          }
        ],
        realLifeProblem: 'In traffic, IF the light is green, you drive. ELIF the light is yellow, you slow down. ELSE (it is red), you stop. Your daily life is full of conditional logic!',
        analogy: {
          title: 'The Railway Switch',
          description: 'A conditional statement is a railway switch. If the condition is True, the train takes Track A. Otherwise, it takes Track B.',
          icon: '🛤️'
        },
        conceptText: 'Comparisons evaluate to True or False. Use == to check equality (distinct from single = for assignment!). Python evaluates conditions in order: if runs first, elif checks alternative conditions, and else catches everything else.',
        syntaxRules: [
          '== checks equality. != checks not equal.',
          '<, <=, >, >= check less than and greater than.',
          'Always end if, elif, and else lines with a colon (:).',
          'Indent the code inside the block by 4 spaces.'
        ],
        workedExample: {
          id: 'ex-7-1',
          title: 'Deciding Player Rank by Score',
          code: `score = 85

if score >= 90:
    print("Grade: Rank S (Legendary!)")
elif score >= 75:
    print("Grade: Rank A (Excellent!)")
elif score >= 50:
    print("Grade: Rank B (Good!)")
else:
    print("Grade: Rank C (Keep Practicing!)")`,
          expectedOutput: 'Grade: Rank A (Excellent!)',
          lineByLine: [
            { line: 1, code: 'score = 85', explanation: 'Creates variable score set to 85.' },
            { line: 3, code: 'if score >= 90:', explanation: 'Checks if 85 >= 90. This is False, so Python skips the indented block.' },
            { line: 5, code: 'elif score >= 75:', explanation: 'Checks if 85 >= 75. This is True! Python enters this block.' },
            { line: 6, code: '    print("Grade: Rank A...")', explanation: 'Prints the Rank A message. Python then exits the entire if structure.' }
          ],
          newlyIntroduced: ['if, elif, else', 'Comparison operators (>=, ==)', '4-space indentation']
        },
        prediction: {
          question: 'What will print when x = 10 in: if x == 10:\n    print("A")\nelse:\n    print("B")',
          codeSnippet: `x = 10\nif x == 10:\n    print("A")\nelse:\n    print("B")`,
          options: ['A', 'B', 'AB', 'SyntaxError'],
          correctIndex: 0,
          explanation: 'x is exactly 10, so x == 10 is True. Python prints "A" and ignores the else branch.'
        },
        practiceChallenge: {
          title: 'Door Guard Password Checker',
          prompt: 'Write code where secret = "python". If secret == "python", print "Access Granted!". Otherwise, print "Access Denied!".',
          starterCode: `secret = "python"\n# Write your if / else logic below:\n`,
          solutionCode: `secret = "python"

if secret == "python":
    print("Access Granted!")
else:
    print("Access Denied!")`,
          hints: [
            'Use secret == "python" with double equals.',
            'Remember colons after if and else.',
            'Indent the print statements by 4 spaces.'
          ]
        },
        commonMistake: {
          title: 'Confusing = with ==',
          badCode: `if score = 100:\n    print("Max score!")`,
          whyItFails: 'Single = is for assigning variables, not comparing! Python raises SyntaxError: invalid syntax.',
          fixedCode: `if score == 100:\n    print("Max score!")`,
          tip: 'Use double equals (==) to test if two things are equal.'
        },
        threeKeyTakeaways: [
          '== compares values; = assigns values.',
          'Conditions evaluate to Boolean True or False.',
          'Indentation (4 spaces) defines which lines belong inside a code block.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q7-1',
        question: 'Which operator checks if two values are NOT equal in Python?',
        options: ['<>', '!=', '!==', 'not='],
        correctIndex: 1,
        explanation: 'In Python, != means "not equal to". (e.g., 5 != 3 is True).',
        misconceptionHint: 'The exclamation mark represents NOT, paired with =.'
      },
      {
        id: 'q7-2',
        question: 'What happens if you forget to indent code under an if statement?',
        options: [
          'Python assumes 0 spaces and runs it fine.',
          'Python raises an IndentationError.',
          'Python converts it into a comment.',
          'The code runs in reverse.'
        ],
        correctIndex: 1,
        explanation: 'Indentation is part of Python\'s grammar. Missing indentation causes an IndentationError: expected an indented block.',
        misconceptionHint: 'In Python, whitespace indentation is mandatory.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch7',
      title: 'The Missing Colon Catastrophe',
      scenario: 'Bugsy stole the colon from the if statement, leaving Python completely stranded!',
      buggyCode: `gold = 50
if gold >= 20
    print("You can buy the potion!")`,
      fixedCode: `gold = 50
if gold >= 20:
    print("You can buy the potion!")`,
      errorType: 'SyntaxError',
      hint1Line: 'Look at the end of line 2.',
      hint2Concept: 'Every if, elif, and else statement must end with a colon (:).',
      hint3Fix: 'Add : to the end of line 2: if gold >= 20:',
      explanation: 'In Python, the colon (:) indicates the beginning of a code block. Forgetting it causes a SyntaxError: expected \':\'.'
    },
    guidedProject: {
      id: 'proj-ch7',
      chapterNumber: 7,
      title: 'The Enchanted Forest Path Picker',
      description: 'Build a branching text adventure where the player chooses a direction ("left" or "right") and faces different encounters.',
      requirements: [
        'Ask direction = input("Choose left or right: ").',
        'If direction is "left", print "You discover a sparkling river with friendly river otters!".',
        'Elif direction is "right", print "You encounter a sleeping dragon. Tread quietly!".',
        'Else, print "You wandered off the path into mystical fog!"'
      ],
      planningSteps: [
        'Step 1: Collect user direction choice.',
        'Step 2: Check "left" branch.',
        'Step 3: Check "right" branch with elif.',
        'Step 4: Catch unknown choices with else.'
      ],
      pseudocode: 'direction = INPUT "Choose left or right: "\nIF direction == "left": PRINT river\nELIF direction == "right": PRINT dragon\nELSE: PRINT mystical fog',
      starterCode: '# Build your enchanted path picker below:\n',
      solutionCode: `direction = input("Choose left or right: ")

if direction == "left":
    print("You discover a sparkling river with friendly river otters!")
elif direction == "right":
    print("You encounter a sleeping dragon. Tread quietly!")
else:
    print("You wandered off the path into mystical fog!")`,
      verificationTips: [
        'Remember to use double equals (==) in comparisons.',
        'Check indentation inside each branch.'
      ]
    }
  },

  // CHAPTER 8
  {
    number: 8,
    act: 2,
    actTitle: 'Act 2: Logic & Control',
    title: 'Logical Thinking',
    subtitle: 'Combining conditions with and, or, not, and in',
    tagline: 'Connect simple truths to solve complex puzzles.',
    icon: '🛡️',
    summary: 'Master compound conditions using logical operators: and (both must be true), or (either can be true), not (flips true to false), and membership checks with in.',
    lessons: [
      {
        id: 'ch8-l1',
        chapterNumber: 8,
        lessonNumber: 1,
        title: 'Compound Logic with and, or, and in',
        objective: 'Combine multiple boolean conditions into powerful logical decision engines.',
        comicPanels: [
          {
            id: 'c8-p1',
            speaker: 'byte',
            mood: 'thinking',
            dialogue: 'Security protocol: Player requires Level >= 5 AND Key == True to open the vault!',
            visualAction: 'Byte inspects two padlock requirements on a giant steel safe.'
          },
          {
            id: 'c8-p2',
            speaker: 'alex',
            mood: 'coding',
            dialogue: 'What if they only have one of them? If they are level 10 but have no key, can they open it?',
            visualAction: 'Alex holds up a high level badge but empty hands.'
          },
          {
            id: 'c8-p3',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'With "and", BOTH conditions must be True! If either one is False, the whole test fails. With "or", just ONE condition needs to be True!',
            visualAction: 'Pip shows a light switch diagram where two switches in series both need to be ON.',
            soundFx: 'CLICK!',
            soundFxColor: '#10B981'
          }
        ],
        realLifeProblem: 'To ride a roller coaster, you must be taller than 48 inches AND at least 10 years old. If you pass only one rule, you cannot ride!',
        analogy: {
          title: 'The Two-Key Vault',
          description: '"and" is a vault requiring two keys turned at once. "or" is a door with two handles: opening either handle unlocks the door.',
          icon: '🔑'
        },
        conceptText: 'Python uses plain English words for logic: and, or, not. You can also use the in keyword to test if a character or word exists inside a string (e.g., "cat" in "caterpillar" is True).',
        syntaxRules: [
          'A and B is True ONLY if both A and B are True.',
          'A or B is True if AT LEAST ONE of A or B is True.',
          'not A reverses the boolean value (not True becomes False).',
          '"item" in collection checks membership.'
        ],
        workedExample: {
          id: 'ex-8-1',
          title: 'Raid Dungeon Eligibility Checker',
          code: `level = 12
has_ticket = True
has_shield = False

# Requires level >= 10 AND (ticket OR shield)
if level >= 10 and (has_ticket or has_shield):
    print("Entry allowed! Prepare for battle.")
else:
    print("Entry denied. You need proper level and gear.")`,
          expectedOutput: 'Entry allowed! Prepare for battle.',
          lineByLine: [
            { line: 1, code: 'level = 12', explanation: 'Player level is 12.' },
            { line: 5, code: 'if level >= 10 and (has_ticket or has_shield):', explanation: 'level >= 10 is True. (has_ticket or has_shield) is True because has_ticket is True. True and True is True!' },
            { line: 6, code: '    print("Entry allowed!...")', explanation: 'Runs because the compound condition passed.' }
          ],
          newlyIntroduced: ['and operator', 'or operator', 'Grouped parentheses in logic']
        },
        prediction: {
          question: 'What does print(not (5 > 2)) output?',
          codeSnippet: 'print(not (5 > 2))',
          options: ['True', 'False', '5', 'Error'],
          correctIndex: 1,
          explanation: '5 > 2 is True. The "not" operator flips True to False, so the output is False.'
        },
        practiceChallenge: {
          title: 'Discount Eligibility Checker',
          prompt: 'Write code where age = 15 and is_student = True. If age < 18 or is_student is True, print "Eligible for student discount!". Otherwise print "Standard rate applies."',
          starterCode: `age = 15\nis_student = True\n# Write your compound condition below:\n`,
          solutionCode: `age = 15
is_student = True

if age < 18 or is_student:
    print("Eligible for student discount!")
else:
    print("Standard rate applies.")`,
          hints: [
            'Use the "or" operator between the two conditions.',
            'Remember colons after if and else.',
            'Indent the print statements by 4 spaces.'
          ]
        },
        commonMistake: {
          title: 'Chaining Comparisons Incorrectly with or',
          badCode: `color = "blue"\nif color == "red" or "blue":\n    print("Valid color!")`,
          whyItFails: 'Python evaluates "blue" on its own, which is always truthy! So the condition is always True regardless of color!',
          fixedCode: `color = "blue"\nif color == "red" or color == "blue":\n    print("Valid color!")`,
          tip: 'Always write the full comparison on both sides of or: color == "red" or color == "blue".'
        },
        threeKeyTakeaways: [
          'and requires all conditions to be True.',
          'or requires at least one condition to be True.',
          'The in operator checks if a substring or element exists inside a collection.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q8-1',
        question: 'What is the value of True and False in Python?',
        options: ['True', 'False', 'None', 'SyntaxError'],
        correctIndex: 1,
        explanation: 'With "and", both sides must be True. Because one side is False, the result is False.',
        misconceptionHint: 'One false spoils the whole "and" operation.'
      },
      {
        id: 'q8-2',
        question: 'What does "py" in "python" evaluate to?',
        options: ['True', 'False', '2', 'Error'],
        correctIndex: 0,
        explanation: 'The letters "py" appear at the start of "python", so "py" in "python" is True.',
        misconceptionHint: 'in tests whether one piece of text is contained inside another.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch8',
      title: 'The Flawed Gatekeeper Condition',
      scenario: 'Alex wanted to check if age is between 13 and 19 (inclusive), but Bugsy wrote an "or" that let everyone in!',
      buggyCode: `age = 25
# Bugsy used "or" instead of "and"!
if age >= 13 or age <= 19:
    print("You are a teenager!")`,
      fixedCode: `age = 25
if age >= 13 and age <= 19:
    print("You are a teenager!")`,
      errorType: 'LogicError',
      hint1Line: 'Look at the operator between the two age checks on line 3.',
      hint2Concept: 'Since 25 >= 13 is True, "or" makes the entire statement True, even though 25 is not a teenager!',
      hint3Fix: 'Change "or" to "and" so both bounds are enforced.',
      explanation: 'To verify a value falls inside a range, both conditions must hold simultaneously, so use "and": age >= 13 and age <= 19.'
    },
    guidedProject: {
      id: 'proj-ch8',
      chapterNumber: 8,
      title: 'Amusement Park Ride Eligibility Checker',
      description: 'Build an eligibility system that checks height, age, and parent accompaniment to approve or deny entry to the Cyclone Coaster.',
      requirements: [
        'Set height = 50 (inches) and age = 9.',
        'Set with_parent = True.',
        'A rider is approved if (height >= 48 and age >= 10) OR (height >= 44 and with_parent).',
        'Print "Ready to ride!" or "Sorry, ride requirements not met."'
      ],
      planningSteps: [
        'Step 1: Set rider variables.',
        'Step 2: Construct grouped compound conditional.',
        'Step 3: Print corresponding approval status.'
      ],
      pseudocode: 'IF (height >= 48 and age >= 10) or (height >= 44 and with_parent):\n  PRINT "Ready to ride!"\nELSE:\n  PRINT "Sorry, ride requirements not met."',
      starterCode: '# Build the eligibility checker below:\nheight = 50\nage = 9\nwith_parent = True\n',
      solutionCode: `height = 50
age = 9
with_parent = True

if (height >= 48 and age >= 10) or (height >= 44 and with_parent):
    print("Ready to ride!")
else:
    print("Sorry, ride requirements not met.")`,
      verificationTips: [
        'Use parentheses to keep the two approval scenarios clear.',
        'Verify with age=9 and with_parent=True that rider is approved.'
      ]
    }
  },

  // CHAPTER 9
  {
    number: 9,
    act: 2,
    actTitle: 'Act 2: Logic & Control',
    title: 'Loops and Repetition',
    subtitle: 'Automating repetitive tasks with for, while, and range()',
    tagline: 'Never do by hand what a 2-line loop can repeat a million times.',
    icon: '🔄',
    summary: 'Conquer loops! Use for loops with range() to repeat actions a exact number of times, while loops to repeat until conditions change, and learn how to avoid infinite loop traps.',
    lessons: [
      {
        id: 'ch9-l1',
        chapterNumber: 9,
        lessonNumber: 1,
        title: 'for Loops, range(), and while Loops',
        objective: 'Write loops to iterate over sequences and repeat tasks safely.',
        comicPanels: [
          {
            id: 'c9-p1',
            speaker: 'alex',
            mood: 'surprised',
            dialogue: 'My teacher told me to write "I will practice coding" 100 times. Do I have to copy-paste 100 print lines?!',
            visualAction: 'Alex holds a massive stack of 100 sheets of paper.'
          },
          {
            id: 'c9-p2',
            speaker: 'pip',
            mood: 'happy',
            dialogue: 'Two lines of Python can do that in 1 millisecond! for i in range(100): print("I will practice coding")!',
            visualAction: 'Pip spins in a circle, generating a whirlwind of clean code lines.',
            soundFx: 'ZOOM!',
            soundFxColor: '#10B981'
          },
          {
            id: 'c9-p3',
            speaker: 'byte',
            mood: 'coding',
            dialogue: 'range(5) counts: 0, 1, 2, 3, 4! It stops before 5! Loop counters start at 0 just like strings!',
            visualAction: 'Byte ticks off 5 gears on an automated assembly line.'
          }
        ],
        realLifeProblem: 'A digital clock updates every second, a game re-renders 60 times every second, and a music player cycles through songs. Loops power the heart of every interactive app!',
        analogy: {
          title: 'The Running Track Lap Counter',
          description: 'A for loop is like running laps on a track. range(5) means run 5 laps. Each time you pass the starting line, the lap number increases until all laps are done.',
          icon: '🏃'
        },
        conceptText: 'Python has two main loops: for loops (used when you know how many times to repeat, or want to visit every item in a collection) and while loops (used when you want to keep going until a condition becomes False).',
        syntaxRules: [
          'for item in range(count): repeats count times (from 0 to count - 1).',
          'range(start, stop) starts at start and stops before stop.',
          'while condition: keeps repeating as long as condition remains True.',
          'Always make sure a while loop has code inside that eventually makes the condition False!'
        ],
        workedExample: {
          id: 'ex-9-1',
          title: 'Countdown Timer and Blastoff',
          code: `# Count down from 3 to 1
for count in range(3, 0, -1):
    print(f"{count}...")

print("BLAST OFF! Rocket launch successful!")`,
          expectedOutput: '3...\n2...\n1...\nBLAST OFF! Rocket launch successful!',
          lineByLine: [
            { line: 2, code: 'for count in range(3, 0, -1):', explanation: 'Starts at 3, stops before 0, stepping by -1 (counts: 3, 2, 1).' },
            { line: 3, code: '    print(f"{count}...")', explanation: 'Prints current number on each lap of the loop.' },
            { line: 5, code: 'print("BLAST OFF!...")', explanation: 'Runs once after the loop finishes.' }
          ],
          newlyIntroduced: ['for loop syntax', 'range(start, stop, step)', 'Loop termination']
        },
        prediction: {
          question: 'What is the output of:\nfor n in range(3):\n    print(n)',
          codeSnippet: `for n in range(3):\n    print(n)`,
          options: ['1\n2\n3', '0\n1\n2', '0\n1\n2\n3', '3'],
          correctIndex: 1,
          explanation: 'range(3) starts at 0 and stops before 3, yielding 0, 1, and 2.'
        },
        practiceChallenge: {
          title: 'Multiplication Table of 5',
          prompt: 'Write a for loop using range(1, 6) to print the multiplication table of 5 from 1 to 5: "5 x {i} = {5 * i}".',
          starterCode: '# Write your multiplication loop below:\n',
          solutionCode: `for i in range(1, 6):
    print(f"5 x {i} = {5 * i}")`,
          hints: [
            'Use for i in range(1, 6):',
            'Indent the print statement inside the loop.',
            'Use an f-string: f"5 x {i} = {5 * i}"'
          ]
        },
        commonMistake: {
          title: 'The Infinite While Loop Trap',
          badCode: `count = 1\nwhile count <= 3:\n    print(count)\n    # Forgot count = count + 1!`,
          whyItFails: 'Because count never changes, count <= 3 stays True forever! The program freezes or crashes.',
          fixedCode: `count = 1\nwhile count <= 3:\n    print(count)\n    count = count + 1`,
          tip: 'Always ensure your while loop modifies the condition variable inside the loop body.'
        },
        threeKeyTakeaways: [
          'for loops iterate over a sequence of numbers or items.',
          'range(n) starts at 0 and generates n numbers up to n-1.',
          'Always increment or update loop variables in while loops to avoid infinite loops.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q9-1',
        question: 'How many times will this loop run: for x in range(5): pass ?',
        options: ['4 times', '5 times', '6 times', 'Infinite times'],
        correctIndex: 1,
        explanation: 'range(5) produces 0, 1, 2, 3, 4, which is exactly 5 iterations.',
        misconceptionHint: 'Even though it stops at 4, starting at 0 gives a total of 5 runs.'
      },
      {
        id: 'q9-2',
        question: 'What keyword immediately exits a loop early in Python?',
        options: ['exit', 'stop', 'break', 'return'],
        correctIndex: 2,
        explanation: 'The break keyword immediately terminates the enclosing loop.',
        misconceptionHint: 'break breaks out of the loop immediately.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch9',
      title: 'The Frozen Infinite Loop',
      scenario: 'Byte got stuck in an endless loop because Bugsy deleted the line that updates the counter!',
      buggyCode: `energy = 3
while energy > 0:
    print(f"Energy remaining: {energy}")
    # Energy never decreases!`,
      fixedCode: `energy = 3
while energy > 0:
    print(f"Energy remaining: {energy}")
    energy = energy - 1
print("Battery depleted.")`,
      errorType: 'LogicError',
      hint1Line: 'Look inside the while loop body.',
      hint2Concept: 'energy starts at 3 and stays at 3 forever, so energy > 0 is always True.',
      hint3Fix: 'Add energy = energy - 1 inside the loop.',
      explanation: 'In a while loop, something inside the loop must move the condition toward False. Subtracting 1 from energy ensures it reaches 0 and stops safely.'
    },
    guidedProject: {
      id: 'proj-ch9',
      chapterNumber: 9,
      title: 'Counting Game & Sum of Numbers',
      description: 'Build a program that calculates the sum of all numbers from 1 to 10 using a loop and reports the final total.',
      requirements: [
        'Initialize total_sum = 0.',
        'Use a for loop over range(1, 11).',
        'Add each number to total_sum.',
        'Print: "The sum of numbers 1 to 10 is: 55".'
      ],
      planningSteps: [
        'Step 1: Create running accumulator total_sum.',
        'Step 2: Loop from 1 up to 10.',
        'Step 3: Accumulate with total_sum = total_sum + num.',
        'Step 4: Print final result after the loop finishes.'
      ],
      pseudocode: 'total_sum = 0\nFOR num IN range(1, 11):\n  total_sum = total_sum + num\nPRINT total_sum',
      starterCode: '# Build your accumulator loop below:\ntotal_sum = 0\n',
      solutionCode: `total_sum = 0

for num in range(1, 11):
    total_sum = total_sum + num

print(f"The sum of numbers 1 to 10 is: {total_sum}")`,
      verificationTips: [
        'Use range(1, 11) so 10 is included.',
        'Ensure the final print is unindented (outside the loop).'
      ]
    }
  }
];
