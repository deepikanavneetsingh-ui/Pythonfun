import { Chapter } from '../../types/curriculum';

export const ACT4_CHAPTERS: Chapter[] = [
  // CHAPTER 14
  {
    number: 14,
    act: 4,
    actTitle: 'Act 4: Real-World Mastery',
    title: 'Files and Data Persistence',
    subtitle: 'Reading and writing text data that outlasts the program',
    tagline: 'When the power turns off, saved files keep your memories safe.',
    icon: '💾',
    summary: 'Discover how computers store information permanently in text files, master the safe with open(...) statement, read and write lines, and learn how browser virtual storage works.',
    lessons: [
      {
        id: 'ch14-l1',
        chapterNumber: 14,
        lessonNumber: 1,
        title: 'Reading and Writing Files Safely',
        objective: 'Write text to files and read them back using with open(...) as f:.',
        comicPanels: [
          {
            id: 'c14-p1',
            speaker: 'alex',
            mood: 'surprised',
            dialogue: 'Every time my program stops, all my variables vanish into thin air! How do games save high scores?',
            visualAction: 'Alex watches glowing numbers fade away into smoke.'
          },
          {
            id: 'c14-p2',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'Variables live in RAM, which disappears when the program exits. To keep data safe, write it to a file on your disk!',
            visualAction: 'Pip locks a parchment into a sturdy brass filing cabinet.',
            soundFx: 'CLICK!',
            soundFxColor: '#10B981'
          },
          {
            id: 'c14-p3',
            speaker: 'byte',
            mood: 'coding',
            dialogue: 'Always use "with open() as file:"! The "with" keyword automatically closes the file even if a power failure occurs! Zero corrupted files!',
            visualAction: 'Byte closes a safe door with a green checkmark.'
          }
        ],
        realLifeProblem: 'When you take a note on your phone or save your progress in a video game, the app writes your data into a file. If it only kept it in memory, you\'d lose everything as soon as you switched apps!',
        analogy: {
          title: 'Writing in a Diary vs Memorizing',
          description: 'Variables are your short-term memory (RAM). Files are your written diary (hard drive). Even if you fall asleep, the diary preserves your memories tomorrow.',
          icon: '📓'
        },
        conceptText: 'Use with open("filename.txt", "w") as f: to write to a file ("w" overwrites, "a" appends). Use "r" to read. The with statement automatically closes the file when the indented block finishes.',
        syntaxRules: [
          'open("file.txt", "w") -> write mode (creates new or replaces existing).',
          'open("file.txt", "a") -> append mode (adds to the end).',
          'open("file.txt", "r") -> read mode (default).',
          'Always use the with keyword to ensure safe file closure.'
        ],
        workedExample: {
          id: 'ex-14-1',
          title: 'Saving and Reading Adventurer Notes',
          code: `# In Python, you can write and read notes
notes_data = "Alex discovered the Crystal Cave on Day 14."

# Simulating file write and read
print("Writing note to adventure_log.txt...")
print(f"Content saved: '{notes_data}'")

# Reading back
print("Reading back from adventure_log.txt:")
print(f"Read success: '{notes_data.upper()}'")`,
          expectedOutput: 'Writing note to adventure_log.txt...\nContent saved: \'Alex discovered the Crystal Cave on Day 14.\'\nReading back from adventure_log.txt:\nRead success: \'ALEX DISCOVERED THE CRYSTAL CAVE ON DAY 14.\'',
          lineByLine: [
            { line: 2, code: 'notes_data = "..."', explanation: 'Creates string data to save.' },
            { line: 5, code: 'print("Writing...")', explanation: 'Saves text to persistent storage.' },
            { line: 9, code: 'print("Reading...")', explanation: 'Loads and processes the saved file contents.' }
          ],
          newlyIntroduced: ['open() modes ("r", "w", "a")', 'with statement', 'File persistence']
        },
        prediction: {
          question: 'What happens if you open an existing file in "w" (write) mode?',
          codeSnippet: `with open("notes.txt", "w") as f:\n    f.write("New text")`,
          options: [
            'It appends the new text to the bottom.',
            'It erases the old content and replaces it with "New text".',
            'It raises an error.',
            'It creates a duplicate file.'
          ],
          correctIndex: 1,
          explanation: '"w" mode overwrites the file from the start. To keep existing text, use "a" (append) mode instead.'
        },
        practiceChallenge: {
          title: 'Simulate High Score Persistence',
          prompt: 'Store player = "Alex" and high_score = 9999. Use an f-string to format the save log line: "Saved high score for {player}: {high_score}".',
          starterCode: `player = "Alex"\nhigh_score = 9999\n# Print save message below:\n`,
          solutionCode: `player = "Alex"
high_score = 9999
print(f"Saved high score for {player}: {high_score}")`,
          hints: [
            'Use an f-string.',
            'Embed both {player} and {high_score}.',
            'Print the message cleanly.'
          ]
        },
        commonMistake: {
          title: 'Forgetting to Close Files (or Not Using with)',
          badCode: `f = open("log.txt", "w")\nf.write("Data")\n# Forgot f.close()!`,
          whyItFails: 'If the program crashes or forgets f.close(), data may remain stuck in the write buffer and get corrupted.',
          fixedCode: `with open("log.txt", "w") as f:\n    f.write("Data")`,
          tip: 'Always use with open() as f: so Python guarantees the file is safely closed.'
        },
        threeKeyTakeaways: [
          'Files persist on disk long after the program exits.',
          '"w" overwrites files, "a" appends to files, "r" reads files.',
          'with open() ensures files are closed automatically.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q14-1',
        question: 'Which file mode should you use if you want to add new lines to a log without erasing previous text?',
        options: ['"r"', '"w"', '"a"', '"x"'],
        correctIndex: 2,
        explanation: '"a" stands for Append. It writes new data at the end of the file without deleting existing contents.',
        misconceptionHint: '"w" wipes out old data; "a" appends.'
      },
      {
        id: 'q14-2',
        question: 'Why is the with statement recommended when working with files in Python?',
        options: [
          'It makes the file invisible to other users.',
          'It automatically closes the file when the block finishes, preventing resource leaks.',
          'It runs 10 times faster.',
          'It converts text into numbers.'
        ],
        correctIndex: 1,
        explanation: 'with is a context manager that guarantees the file handle is closed cleanly, even if an exception occurs.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch14',
      title: 'The Accidental Overwrite Hazard',
      scenario: 'Bugsy wanted to add a second log line, but used "w" instead of "a", which wiped out the first entry!',
      buggyCode: `# Bugsy used "w" which erased entry 1!
log_mode = "w"
print(f"Log opened in mode: {log_mode}")
if log_mode == "w":
    print("Warning: Previous logs will be erased!")`,
      fixedCode: `# Change mode to "a" for append!
log_mode = "a"
print(f"Log opened in mode: {log_mode}")
if log_mode == "a":
    print("Success: Previous logs preserved!")`,
      errorType: 'LogicError',
      hint1Line: 'Look at line 2 where log_mode is defined.',
      hint2Concept: '"w" mode truncates existing files.',
      hint3Fix: 'Change "w" to "a" for append mode.',
      explanation: 'Append mode ("a") is critical for log files where you want to keep historical records intact.'
    },
    guidedProject: {
      id: 'proj-ch14',
      chapterNumber: 14,
      title: 'Adventurer Quest Diary Log',
      description: 'Build a formatted journal logger that combines dates, entry titles, and quest notes into a structured log format.',
      requirements: [
        'Define quest_date = "2026-10-18".',
        'Define quest_title = "The Obsidian Tower".',
        'Define quest_notes = "Found ancient runestone at the tower base."',
        'Print a formatted 4-line journal entry ready for file storage.'
      ],
      planningSteps: [
        'Step 1: Set journal entry variables.',
        'Step 2: Print entry header.',
        'Step 3: Print entry body.',
        'Step 4: Print separator line.'
      ],
      pseudocode: 'PRINT f"=== JOURNAL ENTRY: {date} ==="\nPRINT f"TITLE: {title}"\nPRINT f"NOTES: {notes}"\nPRINT "================================="',
      starterCode: '# Build your journal logger below:\nquest_date = "2026-10-18"\nquest_title = "The Obsidian Tower"\n',
      solutionCode: `quest_date = "2026-10-18"
quest_title = "The Obsidian Tower"
quest_notes = "Found ancient runestone at the tower base."

print(f"=== JOURNAL ENTRY: {quest_date} ===")
print(f"TITLE: {quest_title}")
print(f"NOTES: {quest_notes}")
print("=================================")`
    }
  },

  // CHAPTER 15
  {
    number: 15,
    act: 4,
    actTitle: 'Act 4: Real-World Mastery',
    title: 'Errors and Debugging',
    subtitle: 'Syntax errors, runtime errors, tracebacks, and try / except',
    tagline: 'Errors are not failures — they are the computer\'s way of asking for help.',
    icon: '🔍',
    summary: 'Meet Bugsy in his natural habitat! Learn to read Python error tracebacks without fear, master try / except blocks to handle unexpected input, and fix bugs like a seasoned pro.',
    lessons: [
      {
        id: 'ch15-l1',
        chapterNumber: 15,
        lessonNumber: 1,
        title: 'Catching Exceptions with try and except',
        objective: 'Handle runtime errors gracefully using try / except so programs don\'t crash.',
        comicPanels: [
          {
            id: 'c15-p1',
            speaker: 'bugsy',
            mood: 'happy',
            dialogue: 'Hehehe! A human typed the word "banana" when the program asked for an age number! KABOOM! ValueError!',
            visualAction: 'Bugsy giggles with a magnifying glass as a red error flashes.',
            soundFx: 'ZAP!',
            soundFxColor: '#A855F7'
          },
          {
            id: 'c15-p2',
            speaker: 'alex',
            mood: 'surprised',
            dialogue: 'Ah! The whole program crashed with a scary red traceback! Is there a safety net?',
            visualAction: 'Alex shields his face from glowing error text.'
          },
          {
            id: 'c15-p3',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'Yes! It is called try / except! You put risky code inside "try:". If Bugsy tries to cause an error, the "except:" block catches it gracefully!',
            visualAction: 'Pip opens a safety net underneath the falling program block.',
            soundFx: 'CATCH!',
            soundFxColor: '#10B981'
          }
        ],
        realLifeProblem: 'When an ATM asks how much cash you want, if you type "lots of money", the ATM shouldn\'t self-destruct! It catches the invalid input and gently asks: "Please enter a valid numeric amount".',
        analogy: {
          title: 'The Trapeze Safety Net',
          description: 'try is performing a stunt on the trapeze. except is the safety net underneath. If you slip (raise an exception), you land gently in the net instead of crashing the whole circus!',
          icon: '🎪'
        },
        conceptText: 'There are 3 main types of bugs: 1) SyntaxError (grammar mistakes caught before running), 2) RuntimeError/Exceptions (accidents while running, like ZeroDivisionError or ValueError), and 3) LogicError (runs fine, but gives the wrong answer). try / except handles runtime exceptions.',
        syntaxRules: [
          'try: wraps code that might raise an exception.',
          'except ValueError: catches specific conversion errors.',
          'except Exception as e: catches any unexpected error.',
          'Never use a bare except without printing or logging what happened.'
        ],
        workedExample: {
          id: 'ex-15-1',
          title: 'Safely Parsing Numeric User Input',
          code: `# Simulated user input that could be invalid
user_response = "twenty"

try:
    number = int(user_response)
    print(f"Success! Number is {number}")
except ValueError:
    print("Oops! 'twenty' is not a valid digit. Please enter numbers like 20.")`,
          expectedOutput: 'Oops! \'twenty\' is not a valid digit. Please enter numbers like 20.',
          lineByLine: [
            { line: 2, code: 'user_response = "twenty"', explanation: 'User typed letters instead of digits.' },
            { line: 4, code: 'try:', explanation: 'Tells Python to monitor the indented block for exceptions.' },
            { line: 5, code: 'int(user_response)', explanation: 'Raises a ValueError because "twenty" cannot be turned into an int.' },
            { line: 7, code: 'except ValueError:', explanation: 'Catches the ValueError and executes friendly recovery code!' }
          ],
          newlyIntroduced: ['try and except', 'ValueError', 'Exception handling flow']
        },
        prediction: {
          question: 'What is printed by: try:\n    print(10 / 0)\nexcept ZeroDivisionError:\n    print("Cannot divide by zero!")',
          codeSnippet: `try:\n    print(10 / 0)\nexcept ZeroDivisionError:\n    print("Cannot divide by zero!")`,
          options: ['0', '10', 'Cannot divide by zero!', 'Program crashes'],
          correctIndex: 2,
          explanation: 'Dividing by zero raises a ZeroDivisionError, which is immediately caught by the except block.'
        },
        practiceChallenge: {
          title: 'Defend Against Zero Division',
          prompt: 'Write a safe division program where a = 10 and b = 0. Use try / except ZeroDivisionError to catch the division and print "Division by zero prevented!".',
          starterCode: `a = 10\nb = 0\n# Write your try / except block below:\n`,
          solutionCode: `a = 10
b = 0

try:
    result = a / b
    print("Result:", result)
except ZeroDivisionError:
    print("Division by zero prevented!")`,
          hints: [
            'Put result = a / b inside try:',
            'Use except ZeroDivisionError:',
            'Print the safety message inside except.'
          ]
        },
        commonMistake: {
          title: 'Hiding Bugs with an Empty except',
          badCode: `try:\n    risky_code()\nexcept:\n    pass`,
          whyItFails: 'This swallows ALL errors, including typos and keyboard interrupts, making it impossible to diagnose real bugs!',
          fixedCode: `try:\n    risky_code()\nexcept Exception as e:\n    print(f"Error caught: {e}")`,
          tip: 'Always catch specific exceptions or print the error message.'
        },
        threeKeyTakeaways: [
          'Syntax errors are caught before running; runtime exceptions occur during execution.',
          'try / except protects programs from crashing on bad data.',
          'Reading tracebacks helps you find the exact file and line number of any bug.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q15-1',
        question: 'What error occurs if you try to open a variable that has never been created?',
        options: ['SyntaxError', 'NameError', 'TypeError', 'IndexError'],
        correctIndex: 1,
        explanation: 'Using an unrecognized variable name raises a NameError (e.g. name \'x\' is not defined).',
        misconceptionHint: 'NameError means Python looked for a named variable and found nothing.'
      },
      {
        id: 'q15-2',
        question: 'Which block runs when an error occurs inside a try block?',
        options: ['The else block', 'The except block', 'The finally block only', 'The return block'],
        correctIndex: 1,
        explanation: 'When an exception is raised inside try, execution jumps immediately into the matching except block.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch15',
      title: 'The Uncaught Zero Division Crash',
      scenario: 'Bugsy divided by 0 without a safety net, crashing the spell casting engine!',
      buggyCode: `mana = 100
spells_cast = 0
# Unprotected division by zero!
cost_per_spell = mana / spells_cast
print("Cost:", cost_per_spell)`,
      fixedCode: `mana = 100
spells_cast = 0

try:
    cost_per_spell = mana / spells_cast
    print("Cost:", cost_per_spell)
except ZeroDivisionError:
    print("No spells have been cast yet!")`,
      errorType: 'ZeroDivisionError',
      hint1Line: 'Look at line 4 where mana is divided by spells_cast.',
      hint2Concept: 'Dividing by zero is mathematically undefined and raises ZeroDivisionError.',
      hint3Fix: 'Wrap the calculation in a try / except ZeroDivisionError block.',
      explanation: 'Wrapping risky math in try / except ensures the application stays responsive and shows a helpful message instead of crashing.'
    },
    guidedProject: {
      id: 'proj-ch15',
      chapterNumber: 15,
      title: 'Resilient Calculator Engine',
      description: 'Build a division tool that safely accepts input strings, handles non-numbers, and prevents zero division.',
      requirements: [
        'Define a function safe_divide(x_str, y_str).',
        'Convert both to integers inside try.',
        'Catch ValueError with: "Error: Inputs must be valid numbers!".',
        'Catch ZeroDivisionError with: "Error: Cannot divide by zero!".',
        'Return the quotient on success.'
      ],
      planningSteps: [
        'Step 1: Define safe_divide function.',
        'Step 2: Add try block with int conversion and division.',
        'Step 3: Add except ValueError.',
        'Step 4: Add except ZeroDivisionError.'
      ],
      pseudocode: 'DEF safe_divide(a, b):\n  TRY:\n    RETURN int(a) / int(b)\n  EXCEPT ValueError: RETURN "Invalid number"\n  EXCEPT ZeroDivisionError: RETURN "Cannot divide by 0"',
      starterCode: '# Build your safe_divide function below:\n',
      solutionCode: `def safe_divide(a, b):
    try:
        return int(a) / int(b)
    except ValueError:
        return "Error: Inputs must be valid numbers!"
    except ZeroDivisionError:
        return "Error: Cannot divide by zero!"

print(safe_divide("10", "2"))
print(safe_divide("10", "0"))
print(safe_divide("ten", "2"))`
    }
  },

  // CHAPTER 16
  {
    number: 16,
    act: 4,
    actTitle: 'Act 4: Real-World Mastery',
    title: 'Object-Oriented Programming',
    subtitle: 'Classes, instances, attributes, methods, and self',
    tagline: 'Model the real world by bundling data and behaviors together.',
    icon: '🏰',
    summary: 'A gentle introduction to OOP! Learn how classes act as cookie-cutter blueprints to create unique character objects with their own health, inventories, and action methods.',
    lessons: [
      {
        id: 'ch16-l1',
        chapterNumber: 16,
        lessonNumber: 1,
        title: 'Classes, Objects, and __init__',
        objective: 'Create a Hero class and instantiate unique player objects.',
        comicPanels: [
          {
            id: 'c16-p1',
            speaker: 'alex',
            mood: 'thinking',
            dialogue: 'In my game, there are 50 different goblins. Do I have to make 50 separate dictionaries?',
            visualAction: 'Alex envisions an army of 50 goblins.'
          },
          {
            id: 'c16-p2',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'That is what Classes are for! A class is a cookie-cutter blueprint. You define what a Goblin has once, then press it to stamp out 50 unique goblins!',
            visualAction: 'Pip presses a cookie cutter into dough to stamp out identical goblin silhouettes.',
            soundFx: 'STAMP!',
            soundFxColor: '#10B981'
          },
          {
            id: 'c16-p3',
            speaker: 'byte',
            mood: 'coding',
            dialogue: 'The special method __init__() is the constructor! It initializes each object\'s unique attributes when it is born! self refers to the specific instance!',
            visualAction: 'Byte stamps a serial number on a newly assembled robot.'
          }
        ],
        realLifeProblem: 'Every car blueprint specifies that a car has wheels, an engine, and color. When the factory builds them, one car is red and another is blue. The class is the blueprint; the actual car is the object!',
        analogy: {
          title: 'The Gingerbread Cookie Cutter',
          description: 'The metal cookie cutter is the Class. Each cookie stamped out of the dough is an Object (instance). You can frost one cookie with red icing and another with green icing (attributes)!',
          icon: '🍪'
        },
        conceptText: 'A class bundles data (attributes) and actions (methods) together. Define a class with class Hero:. The __init__(self, name, hp) method runs automatically when a new object is created. Methods are functions inside a class that take self as their first parameter.',
        syntaxRules: [
          'class ClassName: (use CamelCase for class names).',
          'def __init__(self, ...): initializes object attributes.',
          'self refers to the specific instance being operated on.',
          'Call methods using dot notation: hero.take_damage(10).'
        ],
        workedExample: {
          id: 'ex-16-1',
          title: 'Creating and Battling Hero Objects',
          code: `class Hero:
    def __init__(self, name, hp):
        self.name = name
        self.hp = hp

    def take_damage(self, amount):
        self.hp -= amount
        print(f"{self.name} took {amount} damage! HP remaining: {self.hp}")

# Create two independent hero objects
alex = Hero("Alex", 100)
pip = Hero("Pip", 80)

alex.take_damage(15)
print(f"Pip's HP is still safe at: {pip.hp}")`,
          expectedOutput: 'Alex took 15 damage! HP remaining: 85\nPip\'s HP is still safe at: 80',
          lineByLine: [
            { line: 1, code: 'class Hero:', explanation: 'Defines the Hero class blueprint.' },
            { line: 2, code: 'def __init__(self, name, hp):', explanation: 'Constructor method that runs when a new hero is created.' },
            { line: 3, code: 'self.name = name', explanation: 'Saves name attribute to this specific hero instance.' },
            { line: 6, code: 'def take_damage(self, amount):', explanation: 'Defines a method (behavior) that modifies self.hp.' },
            { line: 11, code: 'alex = Hero("Alex", 100)', explanation: 'Creates a new Hero instance named alex.' }
          ],
          newlyIntroduced: ['class keyword', '__init__ constructor', 'self parameter', 'Object methods']
        },
        prediction: {
          question: 'If hero1 = Hero("Alex", 100) and hero2 = Hero("Byte", 200), what does hero1.name print?',
          codeSnippet: `hero1 = Hero("Alex", 100)\nhero2 = Hero("Byte", 200)\nprint(hero1.name)`,
          options: ['Alex', 'Byte', 'Hero', 'None'],
          correctIndex: 0,
          explanation: 'hero1 and hero2 are distinct objects. hero1.name points to "Alex".'
        },
        practiceChallenge: {
          title: 'Build a Pet Companion Class',
          prompt: 'Create a Pet class with __init__(self, name, animal_type). Instantiate my_pet = Pet("Mochi", "Cat") and print: "My pet {my_pet.name} is a {my_pet.animal_type}!".',
          starterCode: '# Build your Pet class below:\n',
          solutionCode: `class Pet:
    def __init__(self, name, animal_type):
        self.name = name
        self.animal_type = animal_type

my_pet = Pet("Mochi", "Cat")
print(f"My pet {my_pet.name} is a {my_pet.animal_type}!")`,
          hints: [
            'Use class Pet:',
            'Define def __init__(self, name, animal_type):',
            'Assign self.name = name and self.animal_type = animal_type'
          ]
        },
        commonMistake: {
          title: 'Forgetting self in Method Definitions',
          badCode: `class Hero:\n    def heal(amount):\n        self.hp += amount`,
          whyItFails: 'Python automatically passes the object instance as the first argument. Missing self causes TypeError: heal() takes 1 positional argument but 2 were given.',
          fixedCode: `class Hero:\n    def heal(self, amount):\n        self.hp += amount`,
          tip: 'Always include self as the very first parameter in any class method.'
        },
        threeKeyTakeaways: [
          'A class is a blueprint; an object is an instance created from that blueprint.',
          '__init__() sets up the initial attributes for each new object.',
          'self lets an object access its own internal attributes and methods.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q16-1',
        question: 'What is the role of self in Python class methods?',
        options: [
          'It is a global variable accessible by every file.',
          'It represents the specific instance of the class that called the method.',
          'It deletes the object when finished.',
          'It is an optional decorator.'
        ],
        correctIndex: 1,
        explanation: 'self refers to the instance calling the method, allowing it to read and write its own attributes.',
        misconceptionHint: 'self connects the method to the specific object calling it.'
      },
      {
        id: 'q16-2',
        question: 'When is __init__() executed?',
        options: [
          'Only when the program terminates',
          'Automatically whenever a new object is created from the class',
          'Only when manually called with object.__init__()',
          'Never'
        ],
        correctIndex: 1,
        explanation: '__init__() is the initializer (constructor) that runs automatically during object instantiation.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch16',
      title: 'The Missing Self Attribute',
      scenario: 'Bugsy forgot to attach the attribute to self in the constructor!',
      buggyCode: `class Player:
    def __init__(self, name):
        # Bugsy forgot self.name = name!
        name = name

p = Player("Alex")
print("Player name:", p.name)`,
      fixedCode: `class Player:
    def __init__(self, name):
        self.name = name

p = Player("Alex")
print("Player name:", p.name)`,
      errorType: 'AttributeError',
      hint1Line: 'Look inside __init__ on line 3-4.',
      hint2Concept: 'name = name only creates a temporary local variable that vanishes.',
      hint3Fix: 'Write self.name = name to attach it to the instance.',
      explanation: 'To store data on an object, you must assign it to self (e.g. self.name = name). Otherwise, the variable is discarded when the function exits.'
    },
    guidedProject: {
      id: 'proj-ch16',
      chapterNumber: 16,
      title: 'RPG Character Inventory System',
      description: 'Build an Adventurer class equipped with an inventory list, methods to pick_up_item() and show_bag(), and test it with multiple items.',
      requirements: [
        'Create class Adventurer with name and empty inventory list in __init__.',
        'Add pick_up(self, item) that appends item to self.inventory.',
        'Create hero = Adventurer("Alex").',
        'Pick up "Magic Wand" and "Healing Potion".',
        'Print: "{hero.name}\'s bag has {len(hero.inventory)} items."'
      ],
      planningSteps: [
        'Step 1: Declare Adventurer class.',
        'Step 2: Initialize self.name and self.inventory = [].',
        'Step 3: Define pick_up method.',
        'Step 4: Instantiate and test.'
      ],
      pseudocode: 'CLASS Adventurer:\n  INIT(name):\n    self.name = name\n    self.inventory = []\n  DEF pick_up(item):\n    self.inventory.append(item)',
      starterCode: '# Build your Adventurer class below:\n',
      solutionCode: `class Adventurer:
    def __init__(self, name):
        self.name = name
        self.inventory = []

    def pick_up(self, item):
        self.inventory.append(item)
        print(f"{self.name} picked up {item}!")

hero = Adventurer("Alex")
hero.pick_up("Magic Wand")
hero.pick_up("Healing Potion")

print(f"{hero.name}'s bag has {len(hero.inventory)} items.")`
    }
  },

  // CHAPTER 17
  {
    number: 17,
    act: 4,
    actTitle: 'Act 4: Real-World Mastery',
    title: 'Working with Real Data',
    subtitle: 'JSON structured data, CSV tables, and data cleaning',
    tagline: 'Modern software runs on structured data.',
    icon: '📊',
    summary: 'Discover how web services share information: parse JSON text into Python dictionaries, format records, handle missing entries, and build data validation pipelines.',
    lessons: [
      {
        id: 'ch17-l1',
        chapterNumber: 17,
        lessonNumber: 1,
        title: 'Working with JSON in Python',
        objective: 'Convert between Python dictionaries and JSON strings with json.loads() and json.dumps().',
        comicPanels: [
          {
            id: 'c17-p1',
            speaker: 'alex',
            mood: 'thinking',
            dialogue: 'When weather apps get weather from a server across the world, what format is the data in?',
            visualAction: 'Alex looks at a weather icon with temperature data.'
          },
          {
            id: 'c17-p2',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'Almost the entire internet speaks JSON (JavaScript Object Notation)! It looks almost identical to Python dictionaries!',
            visualAction: 'Pip displays a JSON file connecting continents with glowing data wires.',
            soundFx: 'SYNC!',
            soundFxColor: '#10B981'
          },
          {
            id: 'c17-p3',
            speaker: 'byte',
            mood: 'coding',
            dialogue: 'Python has the built-in json module! json.loads() turns JSON text into a Python dict. json.dumps() turns a Python dict into JSON text!',
            visualAction: 'Byte translates a binary stream into a clean Python dictionary.'
          }
        ],
        realLifeProblem: 'Video game leaderboards, Spotify playlist tracks, and flight booking engines all exchange information in JSON. Knowing how to handle JSON lets you interact with any web service!',
        analogy: {
          title: 'The Universal Data Translator',
          description: 'Imagine English and Spanish speakers trading notes. JSON is the universal common trade language. Every programming language knows how to read and write JSON!',
          icon: '🌐'
        },
        conceptText: 'import json brings in JSON tools. json.loads(json_string) parses JSON text into Python dictionaries or lists. json.dumps(data, indent=2) converts Python structures into pretty-printed JSON text.',
        syntaxRules: [
          'import json to use the module.',
          'json.loads(string) converts JSON text -> Python dict.',
          'json.dumps(dict) converts Python dict -> JSON text string.',
          'JSON uses true/false/null, while Python uses True/False/None.'
        ],
        workedExample: {
          id: 'ex-17-1',
          title: 'Parsing Weather Data from a Server Response',
          code: `import json

# Simulated JSON payload from a weather service
json_payload = '{"city": "Codetown", "temp_c": 22, "condition": "Sunny", "humidity": 45}'

# Parse JSON into a real Python dictionary
weather = json.loads(json_payload)

print(f"Weather Report for {weather['city']}:")
print(f" - Temperature: {weather['temp_c']}°C")
print(f" - Conditions: {weather['condition']}")`,
          expectedOutput: 'Weather Report for Codetown:\n - Temperature: 22°C\n - Conditions: Sunny',
          lineByLine: [
            { line: 1, code: 'import json', explanation: 'Imports the standard JSON processing library.' },
            { line: 4, code: 'json_payload = \'...\'', explanation: 'Raw text string formatted as JSON.' },
            { line: 7, code: 'weather = json.loads(...)', explanation: 'Converts JSON string into an accessible Python dictionary.' },
            { line: 9, code: 'weather[\'city\']', explanation: 'Accesses dictionary fields just like standard Python.' }
          ],
          newlyIntroduced: ['json module', 'json.loads()', 'json.dumps()']
        },
        prediction: {
          question: 'What Python data type does json.loads(\'{"score": 100}\') produce?',
          codeSnippet: `import json\ndata = json.loads('{"score": 100}')`,
          options: ['A string', 'A dictionary', 'A list', 'A class'],
          correctIndex: 1,
          explanation: 'JSON objects bounded by { } parse directly into Python dictionaries.'
        },
        practiceChallenge: {
          title: 'Serialize Player Data to JSON',
          prompt: 'Import json. Create a dictionary player = {"name": "Alex", "level": 10}. Convert it to a JSON string with json.dumps(player) and print the JSON string.',
          starterCode: '# Convert player dictionary to JSON string below:\n',
          solutionCode: `import json

player = {"name": "Alex", "level": 10}
json_string = json.dumps(player)
print(json_string)`,
          hints: [
            'Start with import json',
            'Define player = {"name": "Alex", "level": 10}',
            'Use json.dumps(player)'
          ]
        },
        commonMistake: {
          title: 'Confusing json.load() with json.loads()',
          badCode: `import json\ndata = json.load('{"id": 1}')`,
          whyItFails: 'json.load() (without the "s") expects a file stream. To parse a string, use json.loads() with an "s" for String!',
          fixedCode: `import json\ndata = json.loads('{"id": 1}')`,
          tip: 'loads stands for "Load String". load (without s) is for files.'
        },
        threeKeyTakeaways: [
          'JSON is the standard format for web data exchange.',
          'json.loads() converts JSON text into Python dictionaries.',
          'json.dumps() turns Python data structures into JSON text.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q17-1',
        question: 'What does the "s" in json.loads() and json.dumps() stand for?',
        options: ['Secure', 'String', 'Standard', 'Server'],
        correctIndex: 1,
        explanation: 'The "s" stands for String. It indicates that the function operates on an in-memory string rather than a file stream.',
        misconceptionHint: 'load = file, loads = string.'
      },
      {
        id: 'q17-2',
        question: 'How is null in a JSON payload represented when parsed into Python?',
        options: ['0', 'False', 'None', '"" (empty string)'],
        correctIndex: 2,
        explanation: 'JSON null maps directly to Python\'s None value.',
        misconceptionHint: 'null and None represent the absence of a value.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch17',
      title: 'The Single-Quote JSON Bug',
      scenario: 'Bugsy used single quotes inside a JSON string, which causes JSON parsers to reject it!',
      buggyCode: `import json
# Bugsy used single quotes inside JSON:
bad_json = "{'name': 'Alex'}"
data = json.loads(bad_json)
print(data)`,
      fixedCode: `import json
# Valid JSON strictly requires double quotes for keys and strings:
good_json = '{"name": "Alex"}'
data = json.loads(good_json)
print(data)`,
      errorType: 'SyntaxError',
      hint1Line: 'Look at the quotes inside bad_json on line 3.',
      hint2Concept: 'The official JSON specification strictly requires double quotes (") for keys and strings.',
      hint3Fix: 'Change single quotes inside JSON to double quotes: \'{"name": "Alex"}\'.',
      explanation: 'While Python allows both single and double quotes for strings, the standard JSON format only accepts double quotes.'
    },
    guidedProject: {
      id: 'proj-ch17',
      chapterNumber: 17,
      title: 'Personal Quest Expense Tracker',
      description: 'Process a list of adventure expense dictionaries, calculate category totals, and flag any item over 50 gold.',
      requirements: [
        'Create expenses list with 3 dicts: {"item": "Potion", "cost": 25}, {"item": "Armor", "cost": 60}, {"item": "Rations", "cost": 15}.',
        'Loop through expenses and calculate total_cost.',
        'If item["cost"] > 50, print f"Expensive purchase: {item[\'item\']}".',
        'Print final total_cost.'
      ],
      planningSteps: [
        'Step 1: Set up expense records.',
        'Step 2: Initialize total_cost = 0.',
        'Step 3: Iterate, accumulate, and check thresholds.',
        'Step 4: Print summary.'
      ],
      pseudocode: 'expenses = [...]\ntotal = 0\nFOR exp IN expenses:\n  total += exp["cost"]\n  IF exp["cost"] > 50: PRINT alert\nPRINT total',
      starterCode: '# Build your expense tracker below:\n',
      solutionCode: `expenses = [
    {"item": "Potion", "cost": 25},
    {"item": "Armor", "cost": 60},
    {"item": "Rations", "cost": 15}
]

total_cost = 0
for exp in expenses:
    total_cost += exp["cost"]
    if exp["cost"] > 50:
        print(f"Expensive purchase: {exp['item']}")

print(f"Total expedition cost: {total_cost} gold")`
    }
  },

  // CHAPTER 18
  {
    number: 18,
    act: 4,
    actTitle: 'Act 4: Real-World Mastery',
    title: 'Building Useful Applications',
    subtitle: 'Architecture, modular planning, and complete mini-apps',
    tagline: 'Coding is craftsmanship: plan before you type.',
    icon: '🛠️',
    summary: 'Learn the professional software development workflow: break big requirements into bite-sized functions, draft pseudocode, implement cleanly, and build complete real-world utilities.',
    lessons: [
      {
        id: 'ch18-l1',
        chapterNumber: 18,
        lessonNumber: 1,
        title: 'Structuring a Complete Console Program',
        objective: 'Architect an interactive command-line app using functions, loops, and clean menus.',
        comicPanels: [
          {
            id: 'c18-p1',
            speaker: 'alex',
            mood: 'thinking',
            dialogue: 'We know variables, if statements, loops, lists, dicts, and functions. How do they all fit together into a real, finished app?',
            visualAction: 'Alex looks at all the coding concepts laid out on a workbench.'
          },
          {
            id: 'c18-p2',
            speaker: 'byte',
            mood: 'coding',
            dialogue: 'App Architecture: 1) State storage at top. 2) Helper functions in middle. 3) Main loop at bottom with user exit choice!',
            visualAction: 'Byte draws a 3-tier blueprint of a production application.'
          },
          {
            id: 'c18-p3',
            speaker: 'pip',
            mood: 'happy',
            dialogue: 'Always write pseudocode first! If you can explain the steps in plain human words, translating to Python is pure joy!',
            visualAction: 'Pip shows a checklist transforming effortlessly into Python code.',
            soundFx: 'AHA!',
            soundFxColor: '#10B981'
          }
        ],
        realLifeProblem: 'When building a house, you don\'t start nailing boards randomly. You draw a blueprint, pour the foundation, frame the walls, and then add doors. Real programs need the same structured blueprint!',
        analogy: {
          title: 'The Restaurant Kitchen Workflow',
          description: 'Pantry holds the ingredients (State). Chefs prepare dishes in stations (Functions). The head waiter takes orders and keeps the dining room running (Main Loop).',
          icon: '🍳'
        },
        conceptText: 'Professional programs follow a clean structure: 1) Data model (lists/dicts), 2) Business logic functions (add, remove, calculate), 3) User interface layer (prompts, menus, formatting). This separation makes code readable and easy to maintain.',
        syntaxRules: [
          'Store program state at top of scope.',
          'Keep functions small and focused on doing one thing well.',
          'Use a main loop: while is_running: to handle user sessions.',
          'Always provide a clear exit command (e.g. choice == "quit").'
        ],
        workedExample: {
          id: 'ex-18-1',
          title: 'A Complete Task To-Do Manager',
          code: `# 1. State
tasks = ["Brew potion", "Sharpen sword"]

# 2. Logic Functions
def show_tasks(task_list):
    print("--- ADVENTURE TO-DO LIST ---")
    for i, t in enumerate(task_list, 1):
        print(f"[{i}] {t}")

def add_task(task_list, new_task):
    task_list.append(new_task)
    print(f"Added: '{new_task}'")

# 3. Simulate operations
show_tasks(tasks)
add_task(tasks, "Rescue royal dragon")
show_tasks(tasks)`,
          expectedOutput: '--- ADVENTURE TO-DO LIST ---\n[1] Brew potion\n[2] Sharpen sword\nAdded: \'Rescue royal dragon\'\n--- ADVENTURE TO-DO LIST ---\n[1] Brew potion\n[2] Sharpen sword\n[3] Rescue royal dragon',
          lineByLine: [
            { line: 2, code: 'tasks = [...]', explanation: 'State: the master list of tasks.' },
            { line: 5, code: 'def show_tasks(...)', explanation: 'UI function: displays formatted list with index numbers.' },
            { line: 10, code: 'def add_task(...)', explanation: 'Business logic function: updates state and provides feedback.' },
            { line: 15, code: 'add_task(...)', explanation: 'Executes the function to append new entry.' }
          ],
          newlyIntroduced: ['Application architecture', 'enumerate(list, 1)', 'Modular program organization']
        },
        prediction: {
          question: 'Why do professional programmers split code into separate functions instead of writing one giant script?',
          codeSnippet: `# Modularity principle`,
          options: [
            'Because Python limits files to 20 lines',
            'To make code reusable, testable, and easier to debug',
            'To make the computer use less electricity',
            'It is required by the operating system'
          ],
          correctIndex: 1,
          explanation: 'Functions isolate concerns. You can test and fix each piece individually without breaking the rest.'
        },
        practiceChallenge: {
          title: 'Build a Contact Quick-Lookup Function',
          prompt: 'Create a function find_phone(contacts_dict, name). If name is in contacts_dict, return contacts_dict[name]. Otherwise return "Not Found". Test with {"Pip": "555-0101"} and "Pip".',
          starterCode: '# Build find_phone function below:\n',
          solutionCode: `def find_phone(contacts_dict, name):
    return contacts_dict.get(name, "Not Found")

directory = {"Pip": "555-0101"}
print(find_phone(directory, "Pip"))
print(find_phone(directory, "Alex"))`,
          hints: [
            'Use dict.get(name, "Not Found")',
            'Return the result from the function.',
            'Test with both existing and missing names.'
          ]
        },
        commonMistake: {
          title: 'Modifying a List While Looping Over It',
          badCode: `items = [1, 2, 3, 4]\nfor item in items:\n    if item % 2 == 0:\n        items.remove(item)`,
          whyItFails: 'Modifying a list while iterating over it shifts indexes and causes items to be skipped unexpectedly!',
          fixedCode: `items = [1, 2, 3, 4]\n# Create a new filtered list instead\nitems = [item for item in items if item % 2 != 0]`,
          tip: 'Filter into a new list or loop over a copy when removing items.'
        },
        threeKeyTakeaways: [
          'Separate your data state, business logic, and presentation.',
          'Small, focused functions are easy to test and maintain.',
          'Always plan the flow in pseudocode before writing actual syntax.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q18-1',
        question: 'What does enumerate(my_list, 1) do in a for loop?',
        options: [
          'It deletes the first item.',
          'It yields both a 1-based index number and the item value together.',
          'It sorts the list.',
          'It counts how many items are equal to 1.'
        ],
        correctIndex: 1,
        explanation: 'enumerate(iterable, start) yields pairs of (index, item), perfect for numbered lists.'
      },
      {
        id: 'q18-2',
        question: 'What is the primary benefit of pseudocode?',
        options: [
          'Computers execute pseudocode twice as fast as Python.',
          'It allows you to solve the program logic in plain human words before worrying about syntax.',
          'It creates an executable file automatically.',
          'It encrypts your secret variables.'
        ],
        correctIndex: 1,
        explanation: 'Pseudocode lets you focus purely on the algorithmic steps without getting bogged down by syntax punctuation.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch18',
      title: 'The Unreturned Calculator Result',
      scenario: 'Bugsy wrote an add function that computed total but forgot to return it to the caller!',
      buggyCode: `def add(a, b):
    total = a + b
    # Bugsy forgot the return statement!

grand_total = add(10, 20)
print("Grand Total:", grand_total)`,
      fixedCode: `def add(a, b):
    total = a + b
    return total

grand_total = add(10, 20)
print("Grand Total:", grand_total)`,
      errorType: 'LogicError',
      hint1Line: 'Look inside the add function.',
      hint2Concept: 'Without return, Python functions evaluate to None.',
      hint3Fix: 'Add return total at the end of the function.',
      explanation: 'Every calculation function must use return to send its answer back into the main program flow.'
    },
    guidedProject: {
      id: 'proj-ch18',
      chapterNumber: 18,
      title: 'Interactive Quiz Master Engine',
      description: 'Build a modular quiz engine with a question bank, score accumulator, and final percentage report.',
      requirements: [
        'Store questions list containing dicts with "q", "options", "a" (correct index).',
        'Create run_quiz(questions) function.',
        'Track score and print: "Final Score: {score}/{len(questions)}".',
        'Demonstrate with 2 sample questions.'
      ],
      planningSteps: [
        'Step 1: Set up question bank.',
        'Step 2: Loop through questions.',
        'Step 3: Compare answer and increment score.',
        'Step 4: Output summary report.'
      ],
      pseudocode: 'score = 0\nFOR q IN questions:\n  IF simulated_choice == q["a"]:\n    score += 1\nPRINT score / total',
      starterCode: '# Build your quiz engine below:\n',
      solutionCode: `questions = [
    {"q": "What is Python?", "a": 1},
    {"q": "Which symbol begins a comment?", "a": 0}
]

score = 0
# Simulating correct answers for both
simulated_answers = [1, 0]

for i, q in enumerate(questions):
    if simulated_answers[i] == q["a"]:
        score += 1

print(f"Quiz Complete! Final Score: {score}/{len(questions)} (100%)")`
    }
  },

  // CHAPTER 19
  {
    number: 19,
    act: 4,
    actTitle: 'Act 4: Real-World Mastery',
    title: 'Python, the Web, Automation, and AI',
    subtitle: 'Where Python goes next in the modern technology world',
    tagline: 'You have learned the foundation — now see the skyscrapers built with it.',
    icon: '🌐',
    summary: 'Explore the modern landscape of Python: web development (Django, FastAPI), automated workflows, API integrations, data science, and artificial intelligence.',
    lessons: [
      {
        id: 'ch19-l1',
        chapterNumber: 19,
        lessonNumber: 1,
        title: 'Automation, APIs, and the AI Frontier',
        objective: 'Understand how Python scripts automate tasks and connect to AI services.',
        comicPanels: [
          {
            id: 'c19-p1',
            speaker: 'alex',
            mood: 'happy',
            dialogue: 'We can write loops, functions, and classes! Where is Python used in the real world out there?',
            visualAction: 'Alex looks at a sprawling city skyline of technology.'
          },
          {
            id: 'c19-p2',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'Python powers the backend of Instagram, automates NASA rovers, trains AI models at Google, and organizes scientific research!',
            visualAction: 'Pip gestures towards rockets, planetary rovers, and neural network diagrams.',
            soundFx: 'WOW!',
            soundFxColor: '#10B981'
          },
          {
            id: 'c19-p3',
            speaker: 'byte',
            mood: 'happy',
            dialogue: 'Automation rule #1: If a human must perform a repetitive computer task more than twice, a 10-line Python script can do it automatically!',
            visualAction: 'Byte presses an automated turbo button.'
          }
        ],
        realLifeProblem: 'Renaming 5,000 photo files manually would take 10 hours of wrist-breaking clicking. A simple Python loop can rename all 5,000 photos in 0.4 seconds!',
        analogy: {
          title: 'The Tireless Digital Assistant',
          description: 'A Python automation script is an assistant who never sleeps, never complains, and can sort millions of spreadsheets while you drink tea.',
          icon: '🤖'
        },
        conceptText: 'Python shines in 4 modern fields: 1) Web APIs (FastAPI/Flask) that serve mobile apps, 2) Task automation (renaming files, scraping, scheduled reports), 3) Data science (pandas, numpy), and 4) Artificial Intelligence (training and calling LLM APIs).',
        syntaxRules: [
          'An API (Application Programming Interface) lets two programs talk over the web.',
          'Never hardcode private API keys in public code; use environment variables.',
          'Python automation scripts save hundreds of hours of manual labor.'
        ],
        workedExample: {
          id: 'ex-19-1',
          title: 'Simulating a Batch File Renamer Automation',
          code: `# Simulating an automated file rename pipeline
raw_files = ["photo 1.png", "vacation 2.png", "family 3.png"]

print("--- STARTING BATCH AUTOMATION ---")
for index, filename in enumerate(raw_files, 1):
    clean_name = filename.replace(" ", "_").lower()
    new_filename = f"2026_archive_{clean_name}"
    print(f"Renamed: '{filename}' -> '{new_filename}'")

print("--- AUTOMATION COMPLETE: 3 files processed! ---")`,
          expectedOutput: '--- STARTING BATCH AUTOMATION ---\nRenamed: \'photo 1.png\' -> \'2026_archive_photo_1.png\'\nRenamed: \'vacation 2.png\' -> \'2026_archive_vacation_2.png\'\nRenamed: \'family 3.png\' -> \'2026_archive_family_3.png\'\n--- AUTOMATION COMPLETE: 3 files processed! ---',
          lineByLine: [
            { line: 2, code: 'raw_files = [...]', explanation: 'List of unorganized filenames to process.' },
            { line: 5, code: 'for index, filename in enumerate(...):', explanation: 'Loops through each file automatically.' },
            { line: 6, code: 'clean_name = filename.replace(...)', explanation: 'Cleans spaces and standardizes naming format.' },
            { line: 7, code: 'new_filename = f"2026_archive_..."', explanation: 'Generates standardized timestamped filename.' }
          ],
          newlyIntroduced: ['Batch automation concepts', '.replace() string method', 'Real-world pipelines']
        },
        prediction: {
          question: 'What is the most important security practice when using web API keys in Python?',
          codeSnippet: `# API security rule`,
          options: [
            'Post your API key in public chat rooms',
            'Keep API keys secret and never commit them into public repositories',
            'Use your password as the API key',
            'Delete the key after every line'
          ],
          correctIndex: 1,
          explanation: 'API keys grant access to your account and quota. They must always be kept secret in environment variables.'
        },
        practiceChallenge: {
          title: 'Simulate an AI Sentiment Classifier',
          prompt: 'Write a function analyze_feedback(text). If "love" or "great" is in text.lower(), return "Positive". Elif "bad" or "slow" in text.lower(), return "Negative". Else return "Neutral". Test with "Python is great!".',
          starterCode: '# Build analyze_feedback function below:\n',
          solutionCode: `def analyze_feedback(text):
    clean = text.lower()
    if "love" in clean or "great" in clean:
        return "Positive"
    elif "bad" in clean or "slow" in clean:
        return "Negative"
    return "Neutral"

print("Feedback:", analyze_feedback("Python is great!"))`,
          hints: [
            'Use text.lower() to make the search case-insensitive.',
            'Use "great" in clean or "love" in clean.',
            'Return "Positive", "Negative", or "Neutral".'
          ]
        },
        commonMistake: {
          title: 'Hardcoding Secret Credentials in Code',
          badCode: `API_KEY = "sk-123456789SECRET"\n# Pushed to public GitHub!`,
          whyItFails: 'Bots constantly scan public code repositories for exposed keys, which can lead to stolen access and unauthorized bills.',
          fixedCode: `import os\nAPI_KEY = os.environ.get("MY_API_KEY")`,
          tip: 'Always use environment variables for passwords and API tokens.'
        },
        threeKeyTakeaways: [
          'Python is the leading language for automation, backend web APIs, and AI.',
          'Automating simple scripts saves hundreds of hours of manual repetition.',
          'Never expose secret API keys or credentials in code.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q19-1',
        question: 'What does API stand for in software development?',
        options: [
          'Automated Python Instruction',
          'Application Programming Interface',
          'Advanced Program Integration',
          'Apple Python Installer'
        ],
        correctIndex: 1,
        explanation: 'API stands for Application Programming Interface — a structured set of rules that allows different applications to communicate.'
      },
      {
        id: 'q19-2',
        question: 'Why has Python become the dominant language for Artificial Intelligence and Machine Learning?',
        options: [
          'It is the only language that supports numbers',
          'Its clean, readable syntax and massive ecosystem of scientific libraries (NumPy, PyTorch, TensorFlow)',
          'It runs directly inside computer chips without an operating system',
          'It was invented specifically for robots'
        ],
        correctIndex: 1,
        explanation: 'Python\'s friendly syntax allows researchers to focus on mathematical models, supported by world-class optimized libraries.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch19',
      title: 'The Case-Sensitive Search Bug',
      scenario: 'Bugsy wrote an automated email filter that searched for "URGENT", but missed emails containing "urgent" in lowercase!',
      buggyCode: `email_subject = "urgent: server maintenance"
# Bugsy forgot to standardize case!
if "URGENT" in email_subject:
    print("Priority Alert!")
else:
    print("Normal priority")`,
      fixedCode: `email_subject = "urgent: server maintenance"
# Convert to upper() or lower() before checking:
if "URGENT" in email_subject.upper():
    print("Priority Alert!")
else:
    print("Normal priority")`,
      errorType: 'LogicError',
      hint1Line: 'Look at the in comparison on line 3.',
      hint2Concept: '"URGENT" != "urgent" because Python is strictly case-sensitive.',
      hint3Fix: 'Use email_subject.upper() or email_subject.lower().',
      explanation: 'Text searches in automation should almost always normalize case using .lower() or .upper() so you never miss matches due to capitalization.'
    },
    guidedProject: {
      id: 'proj-ch19',
      chapterNumber: 19,
      title: 'Automated Log Alert Pipeline',
      description: 'Build an automated log auditor that inspects a list of server events, counts error messages, and generates an executive status report.',
      requirements: [
        'Create logs list with 4 events: "[INFO] Server started", "[ERROR] Database timeout", "[INFO] Request 200", "[ERROR] Disk full".',
        'Loop through logs and count how many start with "[ERROR]".',
        'If error_count > 0, print f"ALERT: {error_count} critical errors detected!".',
        'Else, print "All systems operational."'
      ],
      planningSteps: [
        'Step 1: Set up log events list.',
        'Step 2: Initialize error counter.',
        'Step 3: Scan with event.startswith("[ERROR]").',
        'Step 4: Output alert status.'
      ],
      pseudocode: 'errors = 0\nFOR log IN logs:\n  IF log.startswith("[ERROR]"): errors += 1\nPRINT status',
      starterCode: '# Build your automated log auditor below:\n',
      solutionCode: `logs = [
    "[INFO] Server started",
    "[ERROR] Database timeout",
    "[INFO] Request 200",
    "[ERROR] Disk full"
]

error_count = 0
for entry in logs:
    if entry.startswith("[ERROR]"):
        error_count += 1

if error_count > 0:
    print(f"ALERT: {error_count} critical errors detected!")
else:
    print("All systems operational.")`
    }
  },

  // CHAPTER 20 - CAPSTONE GRADUATION ADVENTURE
  {
    number: 20,
    act: 4,
    actTitle: 'Act 4: Real-World Mastery',
    title: 'The Python Hero Graduation Adventure',
    subtitle: 'The grand capstone quest uniting all 20 chapters',
    tagline: 'You started from zero. Now graduate as a Coding Hero.',
    icon: '👑',
    summary: 'The ultimate graduation quest! Combine variables, strings, user decisions, loops, lists, dictionaries, functions, and error handling in a complete text adventure game, claim your diploma, and celebrate your mastery!',
    lessons: [
      {
        id: 'ch20-l1',
        chapterNumber: 20,
        lessonNumber: 1,
        title: 'The Citadel of Code: Capstone Challenge',
        objective: 'Assemble all 20 chapters of Python knowledge to conquer the Grand Graduation Quest.',
        comicPanels: [
          {
            id: 'c20-p1',
            speaker: 'alex',
            mood: 'coding',
            dialogue: 'Look at how far we came! When we started in Chapter 1, I didn\'t even know what a variable was. Now we can build complete worlds!',
            visualAction: 'Alex wears a hero cape and holds a glowing keyboard with confidence.'
          },
          {
            id: 'c20-p2',
            speaker: 'byte',
            mood: 'happy',
            dialogue: 'Diagnostic analysis: Logic processors operating at 100%! All syntax errors resolved! Ready for graduation protocol!',
            visualAction: 'Byte projects fireworks and confetti from its antenna.',
            soundFx: 'FANFARE!',
            soundFxColor: '#F59E0B'
          },
          {
            id: 'c20-p3',
            speaker: 'bugsy',
            mood: 'happy',
            dialogue: 'I am so proud of you! You caught every bug I threw at you, and you didn\'t give up once! You are a true Bug Detective!',
            visualAction: 'Bugsy hands Alex a golden magnifying glass badge with a wink.'
          },
          {
            id: 'c20-p4',
            speaker: 'pip',
            mood: 'happy',
            dialogue: 'Congratulations, Python Hero! The entire universe of software is now yours to explore. Keep your curiosity burning bright!',
            visualAction: 'Pip presents a glowing Certificate of Mastery.',
            soundFx: 'VICTORY!',
            soundFxColor: '#10B981'
          }
        ],
        realLifeProblem: 'Every great software engineer started exactly where you did: looking at a blank screen and wondering how "Hello World" worked. The superpower you learned isn\'t just Python syntax — it is how to think logically and solve real problems!',
        analogy: {
          title: 'The Master Craftsman\'s Guild',
          description: 'You started as an apprentice learning how to hold the hammer (print) and measure wood (variables). Today you have built an entire clockwork cathedral (capstone project)!',
          icon: '🏛️'
        },
        conceptText: 'Our capstone adventure unites everything you learned into a complete interactive RPG: 1) Variables & Types for stats, 2) Conditionals for story choices, 3) Loops for turn-based gameplay, 4) Dictionaries for character records, 5) Functions for reusable encounters, and 6) try/except for resilient input.',
        syntaxRules: [
          'State: hero dictionary holds name, hp, and inventory list.',
          'Encounter functions return updated player state.',
          'Main game loop continues until victory condition is met or player retreats.',
          'Celebrate every solved bug as a milestone of growth!'
        ],
        workedExample: {
          id: 'ex-20-1',
          title: 'The Python Hero Graduation Game',
          code: `# ============================================
# PYTHON HERO: THE CITADEL OF CODE
# Capstone Graduation Game uniting all skills!
# ============================================

# 1. Player State (Dict + List)
player = {
    "name": "Alex",
    "hp": 100,
    "inventory": ["Magic Compass"]
}

# 2. Combat / Encounter Function
def encounter_guardian(hero):
    print(f"Guardian appears! {hero['name']} prepares for the test of wit.")
    # Test question
    answer = "def"
    if answer == "def":
        print("Correct! The Guardian bows: 'You know how to define functions!'")
        hero["inventory"].append("Golden Key")
        return True
    return False

# 3. Game Run
print(f"Welcome, {player['name']}! Your quest begins.")
victory = encounter_guardian(player)

if victory and "Golden Key" in player["inventory"]:
    print(f"Victory! {player['name']} unlocked the Citadel of Code!")
    print(f"Final Inventory: {player['inventory']}")`,
          expectedOutput: 'Welcome, Alex! Your quest begins.\nGuardian appears! Alex prepares for the test of wit.\nCorrect! The Guardian bows: \'You know how to define functions!\'\nVictory! Alex unlocked the Citadel of Code!\nFinal Inventory: [\'Magic Compass\', \'Golden Key\']',
          lineByLine: [
            { line: 7, code: 'player = {...}', explanation: 'Dictionary holding name, health, and list of items.' },
            { line: 14, code: 'def encounter_guardian(hero):', explanation: 'Function handling the game encounter.' },
            { line: 19, code: 'hero["inventory"].append("Golden Key")', explanation: 'Updates object state on successful puzzle.' },
            { line: 27, code: 'if victory and "Golden Key" in player["inventory"]:', explanation: 'Compound condition checking boolean and membership.' }
          ],
          newlyIntroduced: ['Full Capstone Synthesis', 'Multi-System Integration', 'Graduation Mastery']
        },
        prediction: {
          question: 'What is the most valuable skill you acquired by completing this course?',
          codeSnippet: `# Final reflection`,
          options: [
            'Memorizing every Python keyword forever',
            'Understanding how to break down complex problems and solve them step by step',
            'Typing at 120 words per minute',
            'Avoiding all computers'
          ],
          correctIndex: 1,
          explanation: 'Syntax can always be looked up in documentation. The true superpower is computational thinking and confident problem-solving!'
        },
        practiceChallenge: {
          title: 'The Final Hero Oath',
          prompt: 'Write your graduation program! Set hero_name = "Alex". Use an f-string to print: "I, {hero_name}, am officially a Python Hero!".',
          starterCode: `hero_name = "Alex"\n# Print your graduation declaration below:\n`,
          solutionCode: `hero_name = "Alex"
print(f"I, {hero_name}, am officially a Python Hero!")`,
          hints: [
            'Use an f-string.',
            'Include {hero_name}.',
            'Celebrate your graduation!'
          ]
        },
        commonMistake: {
          title: 'Thinking You Must Know Everything to Build',
          badCode: `# "I am not ready to build a real project yet"`,
          whyItFails: 'Waiting until you know "everything" means you never build anything! Even senior Google engineers look up documentation daily.',
          fixedCode: `# Start building small projects and learn along the way!`,
          tip: 'Build small things, break them, fix them, and keep coding!'
        },
        threeKeyTakeaways: [
          'You have mastered the foundational building blocks of programming.',
          'Debugging is a normal, rewarding part of the creative process.',
          'The best way to keep learning is to build small, fun projects that excite you.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q20-1',
        question: 'Which of the following describes the complete journey from source code to output?',
        options: [
          'Source Code -> Python Interpreter -> Step-by-Step Execution -> Program Output',
          'Source Code -> Physical Printer -> Paper Shredder',
          'Output -> Source Code -> Variables',
          'Code -> Internet -> Error'
        ],
        correctIndex: 0,
        explanation: 'The Python interpreter parses your source code and executes it instruction by instruction to produce results.'
      },
      {
        id: 'q20-2',
        question: 'What should you do when you encounter an unfamiliar error message in the future?',
        options: [
          'Give up programming forever',
          'Read the line number, identify the error type (Syntax, Name, Type), and search or test hypotheses calmly',
          'Buy a new computer',
          'Delete all files'
        ],
        correctIndex: 1,
        explanation: 'Errors are clues! Check the line number, read the message, and debug methodically just like we did with Bugsy.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch20',
      title: 'The Final Grand Debug Challenge',
      scenario: 'Bugsy hid one final typo in the Graduation Anthem: an unclosed quotation mark at the very end of the course!',
      buggyCode: `hero = "Alex"
print(f"Three cheers for Python Hero {hero}! Hip hip hooray!)`,
      fixedCode: `hero = "Alex"
print(f"Three cheers for Python Hero {hero}! Hip hip hooray!")`,
      errorType: 'SyntaxError',
      hint1Line: 'Look at the very end of the string on line 2.',
      hint2Concept: 'Every opening quote must have a matching closing quote.',
      hint3Fix: 'Add a closing double quote before the final parenthesis: hooray!")',
      explanation: 'You did it! You caught Bugsy\'s final typo. Congratulations on mastering Python debugging!'
    },
    guidedProject: {
      id: 'proj-ch20',
      chapterNumber: 20,
      title: 'The Python Hero Graduation Diploma Generator',
      description: 'Generate a personalized ASCII-art Graduation Certificate commemorating your mastery of the complete 20-chapter curriculum.',
      requirements: [
        'Define graduate_name = "Alex".',
        'Define chapters_mastered = 20.',
        'Print a decorative 6-line certificate with borders and title.',
        'Display your official title: "CERTIFIED PYTHON HERO".'
      ],
      planningSteps: [
        'Step 1: Declare graduate name.',
        'Step 2: Print top border.',
        'Step 3: Print diploma title and recipient.',
        'Step 4: Print bottom border.'
      ],
      pseudocode: 'PRINT "======================================="\nPRINT "    CERTIFICATE OF PYTHON MASTERY     "\nPRINT f"  Awarded to: {name}                  "\nPRINT "    Title: CERTIFIED PYTHON HERO       "\nPRINT "======================================="',
      starterCode: '# Generate your official diploma below:\ngraduate_name = "Alex"\n',
      solutionCode: `graduate_name = "Alex"
chapters_mastered = 20

print("========================================")
print("     CERTIFICATE OF PYTHON MASTERY      ")
print("========================================")
print(f" Awarded to: {graduate_name}")
print(f" Chapters Completed: {chapters_mastered} / 20")
print(" Official Rank: CERTIFIED PYTHON HERO")
print("========================================")`
    }
  }
];
