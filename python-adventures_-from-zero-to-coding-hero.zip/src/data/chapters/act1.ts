import { Chapter } from '../../types/curriculum';

export const ACT1_CHAPTERS: Chapter[] = [
  // CHAPTER 1
  {
    number: 1,
    act: 1,
    actTitle: 'Act 1: The First Spark',
    title: 'Enter the World of Programming',
    subtitle: 'From human curiosity to computer code',
    tagline: 'Computers do not guess — they follow our instructions step by step.',
    icon: '✨',
    summary: 'Discover what a program really is, meet your guide Pip, human learner Alex, and literal robot Byte, and run your very first Python instruction!',
    lessons: [
      {
        id: 'ch1-l1',
        chapterNumber: 1,
        lessonNumber: 1,
        title: 'What is a Computer Program?',
        objective: 'Understand how written instructions make computers perform actions.',
        comicPanels: [
          {
            id: 'c1-p1',
            speaker: 'alex',
            mood: 'thinking',
            dialogue: 'Computers feel like magic boxes. How do they know what to do when we tap a button?',
            narration: 'Alex stares at a blank screen in wonder.',
            visualAction: 'Alex points a finger at the computer monitor with curiosity.'
          },
          {
            id: 'c1-p2',
            speaker: 'byte',
            mood: 'explaining',
            dialogue: 'BEEP! Zero magic detected! I have zero thoughts of my own. I only execute instructions!',
            narration: 'Byte holds up an empty checklist with an antenna beep.',
            visualAction: 'Byte displays 010101 on its chest meter.',
            soundFx: 'BEEP-BOOP!',
            soundFxColor: '#0284C7'
          },
          {
            id: 'c1-p3',
            speaker: 'pip',
            mood: 'happy',
            dialogue: 'Welcome Alex! A program is just a recipe: a list of clear steps you give to a computer. Python is the language we use to write that recipe!',
            narration: 'Pip coils in with a warm smile and nerd glasses.',
            visualAction: 'Pip unrolls a colorful scroll of Python instructions.',
            soundFx: 'AHA!',
            soundFxColor: '#10B981'
          }
        ],
        realLifeProblem: 'When you bake cookies, if the recipe says "add 2 cups of sugar" instead of "salt", you get sweet cookies. If you skip a step, the recipe fails. Computers are like bakers who follow recipes 100% literally!',
        analogy: {
          title: 'The Recipe Card Analogy',
          description: 'A program is a recipe. The computer is the baker. The code is the written instructions. If you write clear steps, you get delicious results every time.',
          icon: '📜'
        },
        conceptText: 'A computer is an obedient machine. It cannot read your mind, but it can execute billions of instructions per second with zero fatigue. Python was created by Guido van Rossum to make reading and writing code feel as clean and natural as plain English sentences.',
        syntaxRules: [
          'Python programs run from top to bottom, one line at a time.',
          'Computers execute what you actually typed, not what you intended to type.',
          'Comments start with # and are ignored by Python — they are notes for humans.'
        ],
        workedExample: {
          id: 'ex-1-1',
          title: 'Your Very First Python Instruction',
          code: `# Welcome to Python Adventures!
print("Hello, World!")
print("I am ready to code!")`,
          expectedOutput: 'Hello, World!\nI am ready to code!',
          lineByLine: [
            { line: 1, code: '# Welcome to Python Adventures!', explanation: 'This is a comment. Python skips lines starting with #.' },
            { line: 2, code: 'print("Hello, World!")', explanation: 'print() is a built-in Python command that displays text onto your screen.' },
            { line: 3, code: 'print("I am ready to code!")', explanation: 'Python moves to the next line and prints the second message right underneath.' }
          ],
          newlyIntroduced: ['print()', 'Quotation marks (" ")', 'Comments (#)']
        },
        prediction: {
          question: 'What will Python show on screen after executing this code snippet?',
          codeSnippet: 'print("Welcome to the quest!")',
          options: [
            'print("Welcome to the quest!")',
            'Welcome to the quest!',
            '"Welcome to the quest!"',
            'Nothing happens'
          ],
          correctIndex: 1,
          explanation: 'The print() function strips away the quotation marks and prints the clean text inside them to the screen.'
        },
        practiceChallenge: {
          title: 'Speak, Python!',
          prompt: 'Write a Python program that uses print() to display "Pip and Alex are coding!".',
          starterCode: '# Type your print statement below:\n',
          solutionCode: 'print("Pip and Alex are coding!")',
          hints: [
            'Use the print() function with lowercase letters.',
            'Wrap your text inside double quotation marks: "..."',
            'Put the quotes inside parentheses: print("Pip and Alex are coding!")'
          ],
          testCases: {
            expectedSubstring: 'Pip and Alex are coding!'
          }
        },
        commonMistake: {
          title: 'Capitalizing Print',
          badCode: 'Print("Hello!")',
          whyItFails: 'Python is case-sensitive! It knows "print" in lowercase, but "Print" with a capital P causes a NameError.',
          fixedCode: 'print("Hello!")',
          tip: 'Always write Python keywords and built-in functions in lowercase.'
        },
        threeKeyTakeaways: [
          'A program is a step-by-step set of instructions executed by a computer.',
          'print() sends text to the output screen.',
          'Python is case-sensitive: print() is correct, Print() is an error.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q1-1',
        question: 'What is the primary job of the print() function in Python?',
        options: [
          'It connects to a physical desktop paper printer.',
          'It displays text or numbers onto the computer screen.',
          'It permanently saves a file to your hard drive.',
          'It calculates mathematical equations silently.'
        ],
        correctIndex: 1,
        explanation: 'In programming, print() outputs text to the console or screen, not to physical paper.',
        misconceptionHint: 'Don\'t let everyday office words confuse you! In coding, "printing" means displaying text on screen.'
      },
      {
        id: 'q1-2',
        question: 'Which of the following will run without errors in Python?',
        options: [
          'PRINT("Python is fun")',
          'print("Python is fun")',
          'Print("Python is fun")',
          'print[Python is fun]'
        ],
        correctIndex: 1,
        explanation: 'Python requires lowercase "print" followed by parentheses ( ) containing quotes.',
        misconceptionHint: 'Remember that Python strictly checks uppercase vs lowercase letters.'
      },
      {
        id: 'q1-3',
        question: 'What happens to lines of code that start with a hash symbol (#)?',
        options: [
          'Python turns them into secret encrypted passwords.',
          'They produce a warning error.',
          'Python skips them completely because they are comments for human readers.',
          'They print in bold text on the screen.'
        ],
        correctIndex: 2,
        explanation: 'Comments starting with # are completely ignored by Python. They exist to explain code to humans.',
        misconceptionHint: 'Comments are invisible to the Python runner.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch1',
      title: 'Bugsy\'s Missing Quotes',
      scenario: 'Byte tried to introduce himself, but Bugsy pinched the closing quotation mark from the instruction!',
      buggyCode: 'print("Beep boop, I am Byte the Robot!)',
      fixedCode: 'print("Beep boop, I am Byte the Robot!")',
      errorType: 'SyntaxError',
      hint1Line: 'Look closely at line 1 right after the word "Robot!".',
      hint2Concept: 'Every opening quote (") must have a closing quote (") before the closing parenthesis.',
      hint3Fix: 'Add a double quote right before the final parenthesis: "Robot!")',
      explanation: 'Strings in Python must always be enclosed in matching quotes. If an opening quote has no matching close quote, Python reports a SyntaxError (unterminated string literal).'
    },
    guidedProject: {
      id: 'proj-ch1',
      chapterNumber: 1,
      title: 'Make Byte Introduce Himself',
      description: 'Write a 3-line program where Byte announces his name, version number, and favorite food (electricity!).',
      requirements: [
        'Use three separate print() statements.',
        'Line 1 must announce Byte\'s name.',
        'Line 2 must state: Version: 1.0.',
        'Line 3 must state his favorite fuel.'
      ],
      planningSteps: [
        'Step 1: Write a print() statement for greeting.',
        'Step 2: Write a print() statement with version information.',
        'Step 3: Write a print() statement with a fun punchline.'
      ],
      pseudocode: 'PRINT "Hello! I am Byte the Robot."\nPRINT "System Version: 1.0"\nPRINT "Fuel Preference: Pure Electricity!"',
      starterCode: '# Write Byte\'s three introduction lines below:\n',
      solutionCode: `print("Hello! I am Byte the Robot.")
print("System Version: 1.0")
print("Fuel Preference: Pure Electricity!")`,
      verificationTips: [
        'Make sure all three lines start with lowercase print().',
        'Check that all strings have both opening and closing quotes.'
      ]
    }
  },

  // CHAPTER 2
  {
    number: 2,
    act: 1,
    actTitle: 'Act 1: The First Spark',
    title: 'Your First Python Instructions',
    subtitle: 'Quotes, numbers, commas, and newlines',
    tagline: 'Precision matters: punctuation is Python\'s steering wheel.',
    icon: '💬',
    summary: 'Master printing text, numbers, commas, spaces, and multi-line messages without stumbling on syntax errors.',
    lessons: [
      {
        id: 'ch2-l1',
        chapterNumber: 2,
        lessonNumber: 1,
        title: 'Printing Numbers and Multiple Items',
        objective: 'Learn how print() handles numbers and separates multiple items with commas.',
        comicPanels: [
          {
            id: 'c2-p1',
            speaker: 'alex',
            mood: 'thinking',
            dialogue: 'Wait Pip, do I have to put quotes around numbers like 42 as well?',
            visualAction: 'Alex writes 42 in the air with a curious expression.'
          },
          {
            id: 'c2-p2',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'Great question! Text needs quotes so Python knows it is words. Numbers do not need quotes because Python already knows math!',
            visualAction: 'Pip juggles the number 7 and the word "Seven" in bubbles.',
            soundFx: 'POP!',
            soundFxColor: '#F59E0B'
          },
          {
            id: 'c2-p3',
            speaker: 'byte',
            mood: 'happy',
            dialogue: 'Affirmative! When you give me print("Score:", 100), I automatically insert a space between items!',
            visualAction: 'Byte displays "Score: 100" with a green checkmark.'
          }
        ],
        realLifeProblem: 'When filling out an ID card, your name is letters, but your age is a number. Python treats words and numbers differently too!',
        analogy: {
          title: 'Words in Quotes vs Pure Numbers',
          description: 'Quotes are like quotation bubbles in a comic book: they say "this is exact human dialogue". Pure numbers are raw values ready for math.',
          icon: '🔢'
        },
        conceptText: 'You can print multiple pieces of information on a single line by separating them with commas inside print(). Python will print each piece in order and automatically put a single space between them.',
        syntaxRules: [
          'Text (strings) must be wrapped in matching quotes: "Alex" or \'Alex\'.',
          'Numbers are written directly: 42 or 3.14.',
          'Commas inside print() separate items and automatically add spaces between them.'
        ],
        workedExample: {
          id: 'ex-2-1',
          title: 'Printing Text and Numbers Together',
          code: `print("Player Name:", "Alex")
print("Level:", 1)
print("Coins:", 50 + 25)`,
          expectedOutput: 'Player Name: Alex\nLevel: 1\nCoins: 75',
          lineByLine: [
            { line: 1, code: 'print("Player Name:", "Alex")', explanation: 'Prints both text items on one line, separated by a space.' },
            { line: 2, code: 'print("Level:", 1)', explanation: 'Prints the text label followed by the numeric value 1.' },
            { line: 3, code: 'print("Coins:", 50 + 25)', explanation: 'Python calculates 50 + 25 first to get 75, then prints it!' }
          ],
          newlyIntroduced: ['Comma separation in print()', 'Direct numbers without quotes', 'Math evaluation inside print()']
        },
        prediction: {
          question: 'What will print("Apples:", 3, "Oranges:", 5) display?',
          codeSnippet: 'print("Apples:", 3, "Oranges:", 5)',
          options: [
            'Apples:3Oranges:5',
            'Apples: 3 Oranges: 5',
            '"Apples:" 3 "Oranges:" 5',
            'Error: too many commas'
          ],
          correctIndex: 1,
          explanation: 'Commas inside print() insert a space between each argument automatically.'
        },
        practiceChallenge: {
          title: 'Print Your Hero Stats',
          prompt: 'Write a single print() statement that outputs: Hero: Alex Health: 100 using commas between the labels and values.',
          starterCode: '# Write your hero stats line below:\n',
          solutionCode: 'print("Hero: Alex Health:", 100)',
          hints: [
            'Remember commas separate the label from the number.',
            'You do not need quotes around 100.',
            'Check that your text matches the exact words requested.'
          ]
        },
        commonMistake: {
          title: 'Forgetting the Comma Between Arguments',
          badCode: 'print("Score:" 100)',
          whyItFails: 'Python sees two separate things without a comma between them and raises a SyntaxError: invalid syntax.',
          fixedCode: 'print("Score:", 100)',
          tip: 'Always put a comma between different values inside print().'
        },
        threeKeyTakeaways: [
          'Numbers do not need quotes.',
          'Commas in print() separate items and insert a space.',
          'Python can calculate math right inside print() arguments.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q2-1',
        question: 'What is the output of print(10 + 20)?',
        options: [
          '10 + 20',
          '30',
          '"10 + 20"',
          '1020'
        ],
        correctIndex: 1,
        explanation: 'Because there are no quotes around 10 + 20, Python performs the addition math and prints 30.',
        misconceptionHint: 'Quotes make it text; no quotes make it math!'
      },
      {
        id: 'q2-2',
        question: 'What is the difference between print("7") and print(7)?',
        options: [
          'They print completely different characters on the screen.',
          'They look identical on screen, but "7" is text while 7 is a mathematical integer.',
          'print(7) causes a syntax error.',
          'print("7") prints 7 times.'
        ],
        correctIndex: 1,
        explanation: 'Both display the digit 7 on screen, but to Python, "7" is text that cannot be multiplied numerically like a number.',
        misconceptionHint: 'One is stored as text characters, the other as a numeric value.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch2',
      title: 'The Missing Comma Collision',
      scenario: 'Bugsy ate the comma separating the greeting from the name!',
      buggyCode: 'print("Hello" "Alex")',
      fixedCode: 'print("Hello", "Alex")',
      errorType: 'LogicError',
      hint1Line: 'Look between "Hello" and "Alex".',
      hint2Concept: 'Without a comma, Python glues the strings together into "HelloAlex" without any space.',
      hint3Fix: 'Put a comma between "Hello" and "Alex" to separate them cleanly.',
      explanation: 'In Python, placing two string literals side by side without a comma concatenates them into one word ("HelloAlex"). A comma adds the expected space ("Hello Alex").'
    },
    guidedProject: {
      id: 'proj-ch2',
      chapterNumber: 2,
      title: 'Create an Adventurer ID Card',
      description: 'Build a formatted adventurer badge with character name, class, HP, and Gold.',
      requirements: [
        'Print a decorative top and bottom border using asterisks (***).',
        'Display Character Name: Alex.',
        'Display Class: Python Apprentice.',
        'Display HP: 100 and Gold: 50 using numeric values without quotes.'
      ],
      planningSteps: [
        'Step 1: Print border header.',
        'Step 2: Print name and class.',
        'Step 3: Print numeric attributes.',
        'Step 4: Print footer border.'
      ],
      pseudocode: 'PRINT "***********************"\nPRINT "NAME:", "Alex"\nPRINT "CLASS:", "Apprentice"\nPRINT "HP:", 100, "GOLD:", 50\nPRINT "***********************"',
      starterCode: '# Build your Adventurer ID Card below:\n',
      solutionCode: `print("***********************")
print("NAME:", "Alex")
print("CLASS:", "Apprentice")
print("HP:", 100, "GOLD:", 50)
print("***********************")`,
      verificationTips: [
        'Check that HP and GOLD numbers do not have quotation marks.',
        'Ensure the borders frame the information nicely.'
      ]
    }
  },

  // CHAPTER 3
  {
    number: 3,
    act: 1,
    actTitle: 'Act 1: The First Spark',
    title: 'Variables and Values',
    subtitle: 'Labeled boxes for storing information',
    tagline: 'Names are handles we use to hold onto data.',
    icon: '📦',
    summary: 'Learn what variables are, how to name them according to Python rules, and how to update values dynamically.',
    lessons: [
      {
        id: 'ch3-l1',
        chapterNumber: 3,
        lessonNumber: 1,
        title: 'Creating and Updating Variables',
        objective: 'Learn how to store values in variables with the assignment operator (=).',
        comicPanels: [
          {
            id: 'c3-p1',
            speaker: 'alex',
            mood: 'thinking',
            dialogue: 'Every time my game score changes, do I have to rewrite the whole code?',
            visualAction: 'Alex holds a chalkboard with scores scratched out.'
          },
          {
            id: 'c3-p2',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'Nope! Think of a variable as a labeled storage box. Put a sticky note on the box, and you can change what is inside anytime!',
            visualAction: 'Pip sticks a label saying "score" onto a glowing treasure box.',
            soundFx: 'STICK!',
            soundFxColor: '#10B981'
          },
          {
            id: 'c3-p3',
            speaker: 'byte',
            mood: 'coding',
            dialogue: 'The single equals sign (=) means ASSIGN, not math equal. It takes the value on the right and places it into the variable on the left!',
            visualAction: 'Byte slides a number 10 into the box named "score".'
          }
        ],
        realLifeProblem: 'In a game, your player level changes, your gold goes up and down, and your health drops when attacked. Variables let programs remember changing values!',
        analogy: {
          title: 'The Labeled Storage Box',
          description: 'Imagine a shoe box with a label "hero_name". Inside the box is a slip of paper that says "Alex". Whenever you ask for hero_name, Python looks inside the box.',
          icon: '🏷️'
        },
        conceptText: 'Creating a variable is simple: write the name, write an equals sign (=), and then write the value. In Python, this is called assignment. Python will create the box and remember what you put inside.',
        syntaxRules: [
          'Variable names must start with a letter or an underscore (_), never a number.',
          'Names can contain letters, numbers, and underscores (e.g., player_score_1).',
          'Spaces are not allowed in variable names; use snake_case (words separated by underscores).'
        ],
        workedExample: {
          id: 'ex-3-1',
          title: 'Tracking Game Score with a Variable',
          code: `hero_name = "Alex"
score = 0
print("Starting score:", score)

# Alex finds a gem!
score = score + 10
print("Score after gem:", score)`,
          expectedOutput: 'Starting score: 0\nScore after gem: 10',
          lineByLine: [
            { line: 1, code: 'hero_name = "Alex"', explanation: 'Creates a variable named hero_name containing the text "Alex".' },
            { line: 2, code: 'score = 0', explanation: 'Creates a variable named score containing the number 0.' },
            { line: 3, code: 'print("Starting score:", score)', explanation: 'Prints the text and the current value inside score.' },
            { line: 5, code: 'score = score + 10', explanation: 'Takes current score (0), adds 10, and saves 10 back into score!' },
            { line: 6, code: 'print("Score after gem:", score)', explanation: 'Prints the updated value (10).' }
          ],
          newlyIntroduced: ['Variable creation', 'Assignment operator (=)', 'Updating a variable']
        },
        prediction: {
          question: 'What will this code print?\nhealth = 100\nhealth = 80\nprint(health)',
          codeSnippet: `health = 100\nhealth = 80\nprint(health)`,
          options: ['100', '80', '180', 'health'],
          correctIndex: 1,
          explanation: 'Variables hold only one current value. When health = 80 runs, the old value 100 is replaced by 80.'
        },
        practiceChallenge: {
          title: 'Create Your Pet Profile',
          prompt: 'Create a variable named pet_name set to "Mochi", and a variable named pet_age set to 3. Then print them using print(pet_name, "is", pet_age, "years old").',
          starterCode: '# Create your variables and print statement below:\n',
          solutionCode: `pet_name = "Mochi"
pet_age = 3
print(pet_name, "is", pet_age, "years old")`,
          hints: [
            'Put quotes around the name "Mochi".',
            'Do not put quotes around the number 3.',
            'Use pet_name and pet_age in your print statement.'
          ]
        },
        commonMistake: {
          title: 'Putting Spaces in Variable Names',
          badCode: 'player score = 50',
          whyItFails: 'Python sees two separate words and gets confused, raising a SyntaxError.',
          fixedCode: 'player_score = 50',
          tip: 'Use underscores instead of spaces: player_score, not player score.'
        },
        threeKeyTakeaways: [
          'A variable stores a value that your program can use and update.',
          'The single equals sign (=) assigns the right-hand value to the left-hand name.',
          'Use snake_case for variable names: words in lowercase separated by underscores.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q3-1',
        question: 'Which of the following is a valid Python variable name?',
        options: [
          '2nd_player',
          'player-name',
          'hero_score',
          'player name'
        ],
        correctIndex: 2,
        explanation: 'Variable names cannot start with numbers, cannot have hyphens, and cannot have spaces. hero_score uses valid letters and an underscore.',
        misconceptionHint: 'Python allows letters, numbers, and underscores, but no spaces or leading numbers.'
      },
      {
        id: 'q3-2',
        question: 'In Python, what does the statement coins = coins + 5 mean?',
        options: [
          'It is a mathematical impossibility because coins cannot equal itself plus 5.',
          'It takes the current value of coins, adds 5, and stores the new sum back into coins.',
          'It creates a new variable named coins5.',
          'It prints 5 coins on the screen.'
        ],
        correctIndex: 1,
        explanation: '= means assignment, not equality! It calculates the right side first, then updates the variable on the left.',
        misconceptionHint: 'Remember = in Python means "store this new result", not math equality.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch3',
      title: 'The Illegal Variable Name',
      scenario: 'Bugsy tried to name a variable with a number in front!',
      buggyCode: `1st_place = "Alex"
print(1st_place)`,
      fixedCode: `first_place = "Alex"
print(first_place)`,
      errorType: 'SyntaxError',
      hint1Line: 'Look at the very first character of the variable name on line 1.',
      hint2Concept: 'Python variable names cannot start with a digit (0-9).',
      hint3Fix: 'Change 1st_place to first_place or place_1.',
      explanation: 'Python variables must start with a letter or underscore. If a token starts with a digit, Python assumes it is a number and fails to parse the rest of the name.'
    },
    guidedProject: {
      id: 'proj-ch3',
      chapterNumber: 3,
      title: 'Character Profile Card',
      description: 'Store an adventurer\'s name, role, level, and active status in variables, then display them.',
      requirements: [
        'Create character_name = "Alex".',
        'Create character_role = "Mage".',
        'Create character_level = 5.',
        'Print a formatted 3-line card using those variables.'
      ],
      planningSteps: [
        'Step 1: Declare the variables.',
        'Step 2: Print character name and role.',
        'Step 3: Print character level.'
      ],
      pseudocode: 'SET character_name = "Alex"\nSET character_role = "Mage"\nSET character_level = 5\nPRINT "Adventurer:", character_name\nPRINT "Role:", character_role\nPRINT "Level:", character_level',
      starterCode: '# Define your variables and print your character profile below:\n',
      solutionCode: `character_name = "Alex"
character_role = "Mage"
character_level = 5

print("Adventurer:", character_name)
print("Role:", character_role)
print("Level:", character_level)`,
      verificationTips: [
        'Ensure variable names match exactly (case-sensitive!).',
        'Check that character_level is a number without quotes.'
      ]
    }
  },

  // CHAPTER 4
  {
    number: 4,
    act: 1,
    actTitle: 'Act 1: The First Spark',
    title: 'Numbers and Calculations',
    subtitle: 'Integers, floats, operators, and order of operations',
    tagline: 'Python is a lightning-fast calculator with rules of precedence.',
    icon: '⚡',
    summary: 'Master addition, subtraction, multiplication, division, modulo (%), integer floor division (//), exponents (**), and understand why floats have subtle decimal surprises.',
    lessons: [
      {
        id: 'ch4-l1',
        chapterNumber: 4,
        lessonNumber: 1,
        title: 'Python Arithmetic Operators',
        objective: 'Perform calculations using +, -, *, /, //, %, and **.',
        comicPanels: [
          {
            id: 'c4-p1',
            speaker: 'byte',
            mood: 'coding',
            dialogue: 'My math processor operates at 3.5 billion cycles per second! Feed me equations!',
            visualAction: 'Byte\'s eyes spin with plus and multiplication symbols.'
          },
          {
            id: 'c4-p2',
            speaker: 'alex',
            mood: 'thinking',
            dialogue: 'Wait, what is the difference between single slash / and double slash //?',
            visualAction: 'Alex points to two different slash keys on a keyboard.'
          },
          {
            id: 'c4-p3',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'Single slash / gives regular division with decimals (7 / 2 = 3.5). Double slash // is floor division: it cuts off the decimal and gives just the whole number (7 // 2 = 3)!',
            visualAction: 'Pip slices a pizza in half with a ruler.',
            soundFx: 'SLICE!',
            soundFxColor: '#10B981'
          }
        ],
        realLifeProblem: 'If you have 10 pieces of candy and 3 friends, how many full pieces does each friend get, and how many are left over? Floor division (//) gives the pieces, and modulo (%) gives the remainder!',
        analogy: {
          title: 'Dividing Candy Among Friends',
          description: '10 // 3 is 3 candies per friend. 10 % 3 is 1 candy left over in the bag. The percent sign (%) is called modulo!',
          icon: '🍬'
        },
        conceptText: 'Python has two main number types: integers (whole numbers like 5, -12, 1000) and floats (numbers with decimal points like 3.14, 0.5, -2.0). When you divide with /, Python always gives a float.',
        syntaxRules: [
          '+ (addition), - (subtraction), * (multiplication).',
          '/ (regular division, always produces a float).',
          '// (floor division, discards remainder).',
          '% (modulo, returns the remainder after division).',
          '** (exponent / power: 2 ** 3 means 2 cubed = 8).'
        ],
        workedExample: {
          id: 'ex-4-1',
          title: 'All the Math Operators in Action',
          code: `cookies = 10
friends = 3

each_gets = cookies // friends
leftover = cookies % friends

print("Each friend gets:", each_gets)
print("Leftover cookies:", leftover)`,
          expectedOutput: 'Each friend gets: 3\nLeftover cookies: 1',
          lineByLine: [
            { line: 1, code: 'cookies = 10', explanation: 'Creates variable cookies with integer 10.' },
            { line: 2, code: 'friends = 3', explanation: 'Creates variable friends with integer 3.' },
            { line: 4, code: 'each_gets = cookies // friends', explanation: '10 // 3 equals 3 (the whole number of candies each friend receives).' },
            { line: 5, code: 'leftover = cookies % friends', explanation: '10 % 3 equals 1 (the remainder candy).' },
            { line: 7, code: 'print("Each friend gets:", each_gets)', explanation: 'Prints the distributed count.' }
          ],
          newlyIntroduced: ['// (Floor division)', '% (Modulo remainder)', 'PEMDAS precedence']
        },
        prediction: {
          question: 'What is the output of print(2 + 3 * 4)?',
          codeSnippet: 'print(2 + 3 * 4)',
          options: ['20', '14', '24', 'SyntaxError'],
          correctIndex: 1,
          explanation: 'Python obeys standard mathematical order of operations (PEMDAS): multiplication happens before addition! 3 * 4 is 12, then 2 + 12 is 14.'
        },
        practiceChallenge: {
          title: 'Calculate the Quest Rewards',
          prompt: 'You have 25 gold coins to split equally among 4 adventurers. Write code that prints "Each gets:" followed by the floor division, and "Leftover:" followed by the remainder.',
          starterCode: `total_gold = 25\nadventurers = 4\n# Calculate and print below:\n`,
          solutionCode: `total_gold = 25
adventurers = 4

print("Each gets:", total_gold // adventurers)
print("Leftover:", total_gold % adventurers)`,
          hints: [
            'Use // for how much each adventurer gets.',
            'Use % for the leftover coins.',
            'Print both results with their labels.'
          ]
        },
        commonMistake: {
          title: 'Using ^ Instead of ** for Exponents',
          badCode: 'square = 5 ^ 2',
          whyItFails: 'In Python, ^ is a bitwise XOR operator, NOT exponentiation! 5 ^ 2 equals 7, not 25!',
          fixedCode: 'square = 5 ** 2',
          tip: 'Always use double asterisks (**) for powers: 2 ** 3 = 8.'
        },
        threeKeyTakeaways: [
          'Use // for integer division and % for the remainder.',
          'Division with / always gives a float (e.g. 4 / 2 = 2.0).',
          'Use parentheses () to force the order of operations you want.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q4-1',
        question: 'What is the result of 17 % 5 in Python?',
        options: ['3', '2', '3.4', '1'],
        correctIndex: 1,
        explanation: '5 goes into 17 three times (15), leaving a remainder of 2.',
        misconceptionHint: 'Modulo (%) calculates the leftover remainder after integer division.'
      },
      {
        id: 'q4-2',
        question: 'What is 2 ** 4 in Python?',
        options: ['8', '16', '6', '24'],
        correctIndex: 1,
        explanation: '** means 2 to the power of 4 (2 * 2 * 2 * 2 = 16).',
        misconceptionHint: '2 ** 4 is exponentiation, not multiplication.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch4',
      title: 'Order of Operations Trap',
      scenario: 'Alex tried to calculate the average of three quiz scores (80, 90, 100), but Python printed 223.33 instead of 90!',
      buggyCode: `score1 = 80
score2 = 90
score3 = 100

# Alex forgot parentheses!
average = score1 + score2 + score3 / 3
print("Average:", average)`,
      fixedCode: `score1 = 80
score2 = 90
score3 = 100

average = (score1 + score2 + score3) / 3
print("Average:", average)`,
      errorType: 'LogicError',
      hint1Line: 'Look at line 6 where average is calculated.',
      hint2Concept: 'Division happens before addition! So score3 / 3 was computed first.',
      hint3Fix: 'Wrap the sum in parentheses: (score1 + score2 + score3) / 3',
      explanation: 'Without parentheses, Python divided 100 by 3 first (33.33) and added 80 + 90 + 33.33. Parentheses force Python to add all three scores first before dividing.'
    },
    guidedProject: {
      id: 'proj-ch4',
      chapterNumber: 4,
      title: 'Shopping Bill Calculator with Tax and Tip',
      description: 'Write a program that takes item prices, sums them, calculates 10% sales tax, and prints the grand total.',
      requirements: [
        'Store book_price = 15 and pen_price = 5.',
        'Compute subtotal.',
        'Calculate tax as subtotal * 0.10.',
        'Calculate total as subtotal + tax.',
        'Print Subtotal, Tax, and Grand Total.'
      ],
      planningSteps: [
        'Step 1: Set up prices.',
        'Step 2: Add to get subtotal.',
        'Step 3: Multiply subtotal by 0.10 for tax.',
        'Step 4: Add tax to subtotal and print results.'
      ],
      pseudocode: 'subtotal = book_price + pen_price\ntax = subtotal * 0.10\ntotal = subtotal + tax\nPRINT "Subtotal:", subtotal\nPRINT "Tax:", tax\nPRINT "Total:", total',
      starterCode: '# Build your shopping bill calculator below:\nbook_price = 15\npen_price = 5\n',
      solutionCode: `book_price = 15
pen_price = 5

subtotal = book_price + pen_price
tax = subtotal * 0.10
total = subtotal + tax

print("Subtotal:", subtotal)
print("Tax:", tax)
print("Total:", total)`,
      verificationTips: [
        'Make sure tax uses 0.10 (not 10).',
        'Verify subtotal is 20 and total is 22.0.'
      ]
    }
  },

  // CHAPTER 5
  {
    number: 5,
    act: 1,
    actTitle: 'Act 1: The First Spark',
    title: 'Working with Text',
    subtitle: 'Strings, concatenation, slicing, methods, and f-strings',
    tagline: 'Text in Python is a sequence of characters you can mold like clay.',
    icon: '✨',
    summary: 'Discover string length with len(), character indexing starting at zero, slicing substrings, uppercase/lowercase methods, and the superpower of f-strings.',
    lessons: [
      {
        id: 'ch5-l1',
        chapterNumber: 5,
        lessonNumber: 1,
        title: 'Mastering Python Strings and f-strings',
        objective: 'Learn how to inspect strings, slice characters, and build formatted f-strings.',
        comicPanels: [
          {
            id: 'c5-p1',
            speaker: 'alex',
            mood: 'surprised',
            dialogue: 'Look Pip! If I do "Python"[0], it gives me "P"! But why zero instead of one?',
            visualAction: 'Alex examines the word "P-y-t-h-o-n" with index numbers below each letter.'
          },
          {
            id: 'c5-p2',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'Zero represents the distance from the very start! The first letter is 0 steps away. In Python, counting always begins at zero!',
            visualAction: 'Pip taps index 0 with his glasses.',
            soundFx: 'AHA!',
            soundFxColor: '#10B981'
          },
          {
            id: 'c5-p3',
            speaker: 'byte',
            mood: 'happy',
            dialogue: 'And f-strings are my favorite upgrade! Put an "f" before quotes, and you can inject variables inside curly braces: f"Hello {name}!"',
            visualAction: 'Byte projects a holographic text bubble with glowing variables.'
          }
        ],
        realLifeProblem: 'When an app welcomes you with "Welcome back, Sarah! You have 3 messages", it builds that text dynamically from variables. f-strings make this effortless!',
        analogy: {
          title: 'Train Cars on a Track',
          description: 'A string is like a train with connected passenger cars. Car 0 is the engine, Car 1 is next, and so on. You can unhook a section of cars using slicing [start:stop]!',
          icon: '🚂'
        },
        conceptText: 'Strings are sequences of text characters. Python provides powerful tools: len(s) counts characters, s[0] gets the first character, s[-1] gets the last character, and f-strings let you embed variables directly inside strings.',
        syntaxRules: [
          'len("text") returns the total number of characters (including spaces!).',
          'Indexing starts at 0: word[0] is the first character, word[-1] is the last.',
          'Slicing word[start:stop] gets characters from start up to (but not including) stop.',
          'f-strings: f"Hello, {name}! You have {coins} coins."'
        ],
        workedExample: {
          id: 'ex-5-1',
          title: 'String Methods and f-string Magic',
          code: `hero = "alex the brave"
level = 7

# String methods
print("Uppercase:", hero.upper())
print("Title Case:", hero.title())

# Modern f-string formatting
message = f"Welcome, {hero.title()}! You are Level {level}."
print(message)`,
          expectedOutput: 'Uppercase: ALEX THE BRAVE\nTitle Case: Alex The Brave\nWelcome, Alex The Brave! You are Level 7.',
          lineByLine: [
            { line: 1, code: 'hero = "alex the brave"', explanation: 'Creates a lowercase string.' },
            { line: 2, code: 'level = 7', explanation: 'Creates an integer variable.' },
            { line: 5, code: 'print("Uppercase:", hero.upper())', explanation: '.upper() converts all characters to uppercase.' },
            { line: 6, code: 'print("Title Case:", hero.title())', explanation: '.title() capitalizes the first letter of each word.' },
            { line: 9, code: 'message = f"Welcome, {hero.title()}! You are Level {level}."', explanation: 'The f-string evaluates {hero.title()} and {level} directly inside the text.' }
          ],
          newlyIntroduced: ['len()', 'Zero-indexing', 'String methods (.upper(), .title())', 'f-strings']
        },
        prediction: {
          question: 'What is the output of print("Python"[1:4])?',
          codeSnippet: 'print("Python"[1:4])',
          options: ['Pyt', 'yth', 'ytho', 'Pyth'],
          correctIndex: 1,
          explanation: 'Index 1 is "y", index 2 is "t", index 3 is "h". Slicing stops before index 4 ("o"), so the result is "yth".'
        },
        practiceChallenge: {
          title: 'Build a Personalized Greeting Card',
          prompt: 'Given player_name = "Alex" and quest = "Dragon Cave", use an f-string to print: "Brave Alex enters the Dragon Cave!"',
          starterCode: `player_name = "Alex"\nquest = "Dragon Cave"\n# Use an f-string to print the sentence below:\n`,
          solutionCode: `player_name = "Alex"
quest = "Dragon Cave"

print(f"Brave {player_name} enters the {quest}!")`,
          hints: [
            'Remember to prefix your string with the letter f: f"..."',
            'Place {player_name} and {quest} inside curly brackets.',
            'Do not forget the exclamation point at the end.'
          ]
        },
        commonMistake: {
          title: 'Forgetting the "f" on an f-string',
          badCode: 'name = "Alex"\nprint("Hello {name}!")',
          whyItFails: 'Without the leading "f", Python treats {name} as literal plain text and prints "Hello {name}!" instead of "Hello Alex!".',
          fixedCode: 'name = "Alex"\nprint(f"Hello {name}!")',
          tip: 'Always put the lowercase f immediately before the opening quotation mark.'
        },
        threeKeyTakeaways: [
          'Python strings start counting at index 0.',
          'String methods like .upper(), .lower(), and .strip() help clean and format text.',
          'f-strings are the cleanest, most modern way to combine text and variables.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q5-1',
        question: 'What does len("Code 123") return?',
        options: ['7', '8', '6', 'Error because numbers are included'],
        correctIndex: 1,
        explanation: 'len() counts every character, including the space! "C-o-d-e" (4) + " " (1) + "1-2-3" (3) = 8 characters.',
        misconceptionHint: 'Don\'t forget that spaces count as characters!'
      },
      {
        id: 'q5-2',
        question: 'What does "Hello".lower() do?',
        options: [
          'It returns "hello" in all lowercase letters.',
          'It deletes the string.',
          'It moves the string to the bottom of the screen.',
          'It checks if the string is lowercase and returns True.'
        ],
        correctIndex: 0,
        explanation: '.lower() returns a new string where all uppercase letters are converted to lowercase.',
        misconceptionHint: '.lower() transforms characters to lowercase.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch5',
      title: 'The Type Collision in String Concatenation',
      scenario: 'Bugsy tried to concatenate an integer directly to a string with + without using an f-string or str()!',
      buggyCode: `player = "Alex"
score = 99
print("Player: " + player + " | Score: " + score)`,
      fixedCode: `player = "Alex"
score = 99
print(f"Player: {player} | Score: {score}")`,
      errorType: 'TypeError',
      hint1Line: 'Look at "+ score" on line 3.',
      hint2Concept: 'In Python, you cannot glue a number to a string using +.',
      hint3Fix: 'Convert score with str(score) or switch to a modern f-string!',
      explanation: 'Python does not automatically convert numbers to text when using the + operator. Using an f-string handles number conversion automatically and cleanly.'
    },
    guidedProject: {
      id: 'proj-ch5',
      chapterNumber: 5,
      title: 'Personalized Greeting Generator',
      description: 'Create a greeting generator that formats a name in title case and displays their badge length and stats.',
      requirements: [
        'Define raw_name = "alexander".',
        'Convert raw_name to Title Case.',
        'Calculate name length with len().',
        'Use an f-string to print: "Hero Name: Alexander (Length: 9 letters)".'
      ],
      planningSteps: [
        'Step 1: Store raw name.',
        'Step 2: Apply .title() method.',
        'Step 3: Calculate length.',
        'Step 4: Format with an f-string.'
      ],
      pseudocode: 'name = "alexander"\nclean_name = name.title()\nlength = len(clean_name)\nPRINT f"Hero Name: {clean_name} (Length: {length} letters)"',
      starterCode: '# Build your greeting generator below:\nraw_name = "alexander"\n',
      solutionCode: `raw_name = "alexander"
clean_name = raw_name.title()
length = len(clean_name)

print(f"Hero Name: {clean_name} (Length: {length} letters)")`,
      verificationTips: [
        'Ensure clean_name has a capitalized first letter.',
        'Check that the f-string contains both {clean_name} and {length}.'
      ]
    }
  }
];
