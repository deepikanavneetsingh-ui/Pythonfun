import { Chapter, Lesson } from '../../types/curriculum';
import { ACT1_CHAPTERS } from './act1';
import { ACT2_CHAPTERS } from './act2';
import { ACT3_CHAPTERS } from './act3';
import { ACT4_CHAPTERS } from './act4';

export const ALL_CHAPTERS: Chapter[] = [
  ...ACT1_CHAPTERS,
  ...ACT2_CHAPTERS,
  ...ACT3_CHAPTERS,
  ...ACT4_CHAPTERS
];

export function getChapterByNumber(num: number): Chapter | undefined {
  return ALL_CHAPTERS.find((ch) => ch.number === num);
}

export function getLessonById(lessonId: string): { lesson: Lesson; chapter: Chapter } | undefined {
  for (const ch of ALL_CHAPTERS) {
    const lesson = ch.lessons.find((l) => l.id === lessonId);
    if (lesson) {
      return { lesson, chapter: ch };
    }
  }
  return undefined;
}

export function getAllLessons(): { lesson: Lesson; chapter: Chapter }[] {
  const result: { lesson: Lesson; chapter: Chapter }[] = [];
  for (const ch of ALL_CHAPTERS) {
    for (const l of ch.lessons) {
      result.push({ lesson: l, chapter: ch });
    }
  }
  return result;
}

export { ACT1_CHAPTERS, ACT2_CHAPTERS, ACT3_CHAPTERS, ACT4_CHAPTERS };
