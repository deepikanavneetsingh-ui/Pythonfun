import { Chapter } from '../../types/curriculum';

export const ACT3_CHAPTERS: Chapter[] = [
  // CHAPTER 10
  {
    number: 10,
    act: 3,
    actTitle: 'Act 3: Data & Structures',
    title: 'Lists and Collections',
    subtitle: 'Organizing ordered sequences of data with Python lists',
    tagline: 'When one variable is not enough, pack an inventory backpack.',
    icon: '🎒',
    summary: 'Discover Python lists: create ordered sequences, access elements by index starting at zero, append new items, remove old ones, sort, and iterate effortlessly.',
    lessons: [
      {
        id: 'ch10-l1',
        chapterNumber: 10,
        lessonNumber: 1,
        title: 'Creating and Modifying Lists',
        objective: 'Store multiple items in square brackets [ ] and manage them with .append() and .pop().',
        comicPanels: [
          {
            id: 'c10-p1',
            speaker: 'alex',
            mood: 'thinking',
            dialogue: 'My hero has a wooden sword, a health potion, a magic compass, and 5 torches. Do I need 4 separate variables?',
            visualAction: 'Alex juggles four different inventory items.'
          },
          {
            id: 'c10-p2',
            speaker: 'pip',
            mood: 'happy',
            dialogue: 'No way! In Python, you can pack them all into one list with square brackets: inventory = ["sword", "potion", "compass"]!',
            visualAction: 'Pip neatly packs all items into a magical adventurer backpack.',
            soundFx: 'ZIP!',
            soundFxColor: '#10B981'
          },
          {
            id: 'c10-p3',
            speaker: 'byte',
            mood: 'coding',
            dialogue: 'Memory mapping: inventory[0] accesses the first item. inventory.append("torch") adds to the end! Zero-indexed access confirmed!',
            visualAction: 'Byte projects slots 0, 1, 2 with glowing holographic icons.'
          }
        ],
        realLifeProblem: 'A grocery shopping list, a music playlist, or an online shopping cart all hold an ordered sequence of changing items. Lists are Python\'s ultimate dynamic container!',
        analogy: {
          title: 'The Multi-Slot Organizer Tray',
          description: 'A list is a tackle box with numbered slots starting at 0. Slot 0 holds the first item, Slot 1 holds the second. You can add more slots anytime with .append()!',
          icon: '🗂️'
        },
        conceptText: 'Lists are created with square brackets [item1, item2, item3]. Lists are mutable, meaning you can add items with .append(), remove items with .remove(), take the last item off with .pop(), and find how many items exist with len().',
        syntaxRules: [
          'Create a list: items = ["apple", "banana", "cherry"].',
          'Access item: items[0] is "apple", items[-1] is "cherry".',
          'Add to end: items.append("date").',
          'Loop through list: for item in items: print(item).'
        ],
        workedExample: {
          id: 'ex-10-1',
          title: 'Managing an Adventurer Inventory',
          code: `inventory = ["Wooden Sword", "Health Potion"]
print("Initial bag:", inventory)

# Found a treasure!
inventory.append("Golden Shield")
print("After finding shield:", inventory)
print(f"Total items in bag: {len(inventory)}")

# Print each item line by line
for item in inventory:
    print(f" - Ready: {item}")`,
          expectedOutput: 'Initial bag: [\'Wooden Sword\', \'Health Potion\']\nAfter finding shield: [\'Wooden Sword\', \'Health Potion\', \'Golden Shield\']\nTotal items in bag: 3\n - Ready: Wooden Sword\n - Ready: Health Potion\n - Ready: Golden Shield',
          lineByLine: [
            { line: 1, code: 'inventory = [...]', explanation: 'Creates a list containing 2 string items.' },
            { line: 5, code: 'inventory.append("Golden Shield")', explanation: '.append() adds a new item to the end of the list.' },
            { line: 7, code: 'len(inventory)', explanation: 'Returns the count of items in the list (3).' },
            { line: 10, code: 'for item in inventory:', explanation: 'Loops through every item in the list one by one.' }
          ],
          newlyIntroduced: ['List creation [ ]', '.append() method', 'len(list)', 'for item in list']
        },
        prediction: {
          question: 'What is the value of heroes[1] if heroes = ["Pip", "Alex", "Byte"]?',
          codeSnippet: `heroes = ["Pip", "Alex", "Byte"]\nprint(heroes[1])`,
          options: ['Pip', 'Alex', 'Byte', 'IndexError'],
          correctIndex: 1,
          explanation: 'Remember Python starts counting at 0! heroes[0] is "Pip", and heroes[1] is "Alex".'
        },
        practiceChallenge: {
          title: 'Party Quest Roster',
          prompt: 'Create a list party = ["Alex", "Pip"]. Add "Byte" using .append(). Then print: "Party members: {len(party)}".',
          starterCode: `party = ["Alex", "Pip"]\n# Append Byte and print length below:\n`,
          solutionCode: `party = ["Alex", "Pip"]
party.append("Byte")
print(f"Party members: {len(party)}")`,
          hints: [
            'Use party.append("Byte")',
            'Use len(party) inside an f-string.',
            'Check that party has 3 members.'
          ]
        },
        commonMistake: {
          title: 'Off-By-One IndexError',
          badCode: `fruits = ["apple", "pear", "peach"]\nprint(fruits[3])`,
          whyItFails: 'There are 3 items, so valid indexes are 0, 1, 2. fruits[3] causes IndexError: list index out of range!',
          fixedCode: `fruits = ["apple", "pear", "peach"]\nprint(fruits[2])  # or fruits[-1]`,
          tip: 'The last index of a list is always len(list) - 1, or use index -1.'
        },
        threeKeyTakeaways: [
          'Lists hold ordered collections of items using square brackets [].',
          'Access items by index starting at 0; negative indexes count from the end.',
          'Use .append() to add items and len() to count items.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q10-1',
        question: 'How do you add an item to the end of a list named pets?',
        options: ['pets.add("dog")', 'pets.append("dog")', 'pets.push("dog")', 'pets.insert_end("dog")'],
        correctIndex: 1,
        explanation: 'In Python, the list method to append an element to the end is .append().',
        misconceptionHint: 'Unlike JavaScript (push) or sets (add), Python lists use .append().'
      },
      {
        id: 'q10-2',
        question: 'What does animals[-1] return in Python?',
        options: [
          'A negative error',
          'The first animal in the list',
          'The very last animal in the list',
          'The animal at index 0'
        ],
        correctIndex: 2,
        explanation: 'Negative indexing counts backwards from the end. -1 is always the last item.',
        misconceptionHint: 'Negative indexes are a convenient Python shortcut to read backwards from the end.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch10',
      title: 'The Out-of-Bounds IndexError',
      scenario: 'Alex created a list with 3 quest rewards, but Bugsy tried to fetch index 3 and crashed the game!',
      buggyCode: `rewards = ["100 Gold", "Iron Helmet", "Magic Ring"]
# 3 items, but Bugsy asks for index 3!
print("Grand prize:", rewards[3])`,
      fixedCode: `rewards = ["100 Gold", "Iron Helmet", "Magic Ring"]
# Index 2 is the 3rd item!
print("Grand prize:", rewards[2])`,
      errorType: 'IndexError',
      hint1Line: 'Look at the index inside rewards[...] on line 3.',
      hint2Concept: 'Indexes are 0 ("100 Gold"), 1 ("Iron Helmet"), 2 ("Magic Ring"). Index 3 does not exist!',
      hint3Fix: 'Change rewards[3] to rewards[2] or rewards[-1].',
      explanation: 'Attempting to access an index beyond the bounds of a list raises an IndexError. For a 3-item list, the highest valid index is 2.'
    },
    guidedProject: {
      id: 'proj-ch10',
      chapterNumber: 10,
      title: 'Adventurer Shopping List Manager',
      description: 'Build an interactive shopping list that starts with standard supplies, adds new items, and prints a numbered summary.',
      requirements: [
        'Initialize supplies = ["Rope", "Lantern"].',
        'Append "Rations" and "Bedroll".',
        'Loop through supplies and print each item as: "Item 1: Rope", "Item 2: Lantern", etc.',
        'Print the total supply count.'
      ],
      planningSteps: [
        'Step 1: Create starting list.',
        'Step 2: Append two extra items.',
        'Step 3: Loop with counter and print formatted lines.',
        'Step 4: Print total count.'
      ],
      pseudocode: 'supplies = ["Rope", "Lantern"]\nsupplies.append("Rations")\nsupplies.append("Bedroll")\nFOR i IN range(len(supplies)):\n  PRINT f"Item {i+1}: {supplies[i]}"',
      starterCode: '# Build your shopping list manager below:\nsupplies = ["Rope", "Lantern"]\n',
      solutionCode: `supplies = ["Rope", "Lantern"]
supplies.append("Rations")
supplies.append("Bedroll")

for i in range(len(supplies)):
    print(f"Item {i + 1}: {supplies[i]}")

print(f"Total supplies packed: {len(supplies)}")`,
      verificationTips: [
        'Ensure 4 items are in supplies.',
        'Check that the numbers start at 1 for human readability (i + 1).'
      ]
    }
  },

  // CHAPTER 11
  {
    number: 11,
    act: 3,
    actTitle: 'Act 3: Data & Structures',
    title: 'Dictionaries, Tuples, and Sets',
    subtitle: 'Key-value maps, immutable coordinates, and unique sets',
    tagline: 'Label your data with meaningful names instead of index numbers.',
    icon: '📚',
    summary: 'Master key-value dictionaries {key: value}, discover immutable tuples (x, y), and use sets {1, 2, 3} for unique collections with zero duplicates.',
    lessons: [
      {
        id: 'ch11-l1',
        chapterNumber: 11,
        lessonNumber: 1,
        title: 'Key-Value Lookups with Dictionaries',
        objective: 'Store and retrieve data using descriptive string keys in curly braces { }.',
        comicPanels: [
          {
            id: 'c11-p1',
            speaker: 'alex',
            mood: 'thinking',
            dialogue: 'In a list, I have to remember that player[0] is name and player[1] is HP. What if I mix up the index numbers?',
            visualAction: 'Alex frowns at an index number chart.'
          },
          {
            id: 'c11-p2',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'That is where dictionaries shine! Instead of numbers, you label data with keys: hero["name"] = "Alex", hero["hp"] = 100!',
            visualAction: 'Pip opens a real dictionary book with glowing words and definitions.',
            soundFx: 'AHA!',
            soundFxColor: '#10B981'
          },
          {
            id: 'c11-p3',
            speaker: 'byte',
            mood: 'happy',
            dialogue: 'Key-value lookup confirmed! Searching by key operates with lightning speed! No scanning required!',
            visualAction: 'Byte retrieves a value in 0.0001 seconds.'
          }
        ],
        realLifeProblem: 'In a real-life phone contact book, you don\'t remember your best friend as "contact number 47" — you look them up by their name "Sam" to find their phone number!',
        analogy: {
          title: 'The Real-World Dictionary',
          description: 'A dictionary connects a word (the key) to its definition (the value). In Python, hero = {"name": "Alex", "class": "Wizard"} connects "name" directly to "Alex".',
          icon: '📖'
        },
        conceptText: 'Python dictionaries use curly braces {key: value}. Keys must be unique. You can access values with dict[key] or dict.get(key), add new keys with dict[new_key] = value, and delete keys with del dict[key]. Tuples (x, y) are fixed lists that cannot change, and sets {a, b} hold unique items.',
        syntaxRules: [
          'Create dict: hero = {"name": "Alex", "hp": 100}.',
          'Read value: print(hero["name"]).',
          'Add/update: hero["gold"] = 50.',
          'Tuple (immutable): coords = (10, 20).',
          'Set (no duplicates): unique_tags = {"fire", "ice", "fire"} becomes {"fire", "ice"}.'
        ],
        workedExample: {
          id: 'ex-11-1',
          title: 'Managing a Hero Profile with a Dictionary',
          code: `hero = {
    "name": "Alex",
    "level": 3,
    "hp": 95,
    "is_alive": True
}

print(f"Hero: {hero['name']} (Level {hero['level']})")

# Level up!
hero["level"] = 4
hero["weapon"] = "Silver Wand"

print("Updated stats:", hero)`,
          expectedOutput: 'Hero: Alex (Level 3)\nUpdated stats: {\'name\': \'Alex\', \'level\': 4, \'hp\': 95, \'is_alive\': True, \'weapon\': \'Silver Wand\'}',
          lineByLine: [
            { line: 1, code: 'hero = {...}', explanation: 'Creates a dictionary with 4 key-value pairs.' },
            { line: 8, code: 'hero["name"]', explanation: 'Retrieves the value associated with key "name".' },
            { line: 11, code: 'hero["level"] = 4', explanation: 'Updates the existing key "level" to 4.' },
            { line: 12, code: 'hero["weapon"] = "Silver Wand"', explanation: 'Creates a brand new key-value pair in the dictionary.' }
          ],
          newlyIntroduced: ['Dictionaries { }', 'Key-value pairs', 'Accessing by key hero["key"]', 'Adding new keys']
        },
        prediction: {
          question: 'What does this code print?\nfruit_prices = {"apple": 2, "banana": 1}\nprint(fruit_prices["banana"])',
          codeSnippet: `fruit_prices = {"apple": 2, "banana": 1}\nprint(fruit_prices["banana"])`,
          options: ['2', '1', 'banana', 'KeyError'],
          correctIndex: 1,
          explanation: 'Looking up the key "banana" returns its associated value: 1.'
        },
        practiceChallenge: {
          title: 'Build a Creature Bestiary Entry',
          prompt: 'Create a dictionary monster with "name": "Goblin", "hp": 30, and "attack": 8. Print: "{monster[\'name\']} attacks for {monster[\'attack\']} damage!".',
          starterCode: '# Create monster dictionary and print attack below:\n',
          solutionCode: `monster = {
    "name": "Goblin",
    "hp": 30,
    "attack": 8
}

print(f"{monster['name']} attacks for {monster['attack']} damage!")`,
          hints: [
            'Use curly braces { } with colons between keys and values.',
            'Access values using monster["name"] and monster["attack"].',
            'Notice that outside double quotes let you use single quotes inside: monster[\'name\'].'
          ]
        },
        commonMistake: {
          title: 'Accessing a Non-Existent Key',
          badCode: `user = {"name": "Alex"}\nprint(user["email"])`,
          whyItFails: 'If a key does not exist, Python crashes with a KeyError: \'email\'!',
          fixedCode: `user = {"name": "Alex"}\nprint(user.get("email", "No email provided"))`,
          tip: 'Use dict.get("key", default) to avoid KeyError crashes when keys might be missing.'
        },
        threeKeyTakeaways: [
          'Dictionaries store data as key-value pairs using curly braces {}.',
          'Tuples (parentheses) are ordered sequences that cannot be changed (immutable).',
          'Sets automatically eliminate duplicate items.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q11-1',
        question: 'Which bracket type is used to define a Python dictionary?',
        options: ['Square brackets [ ]', 'Curly braces { }', 'Parentheses ( )', 'Angle brackets < >'],
        correctIndex: 1,
        explanation: 'Curly braces { } are used for dictionaries (and sets). Lists use [ ] and tuples use ( ).',
        misconceptionHint: '{ } = dictionaries/sets, [ ] = lists, ( ) = tuples.'
      },
      {
        id: 'q11-2',
        question: 'What happens to duplicates in a set: colors = {"red", "blue", "red"} ?',
        options: [
          'Python raises an error.',
          'The duplicate "red" is automatically discarded, leaving {"red", "blue"}.',
          'The set keeps both "red" items.',
          'It turns into a list.'
        ],
        correctIndex: 1,
        explanation: 'Sets enforce uniqueness. Any duplicate value is automatically removed.',
        misconceptionHint: 'Sets only store unique elements.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch11',
      title: 'The Catastrophic KeyError',
      scenario: 'Bugsy tried to look up the "mana" key on Byte, but Byte only has "battery"!',
      buggyCode: `robot = {"name": "Byte", "battery": 100}
# Bugsy asks for "mana" which doesn't exist!
print("Mana points:", robot["mana"])`,
      fixedCode: `robot = {"name": "Byte", "battery": 100}
# Safe lookup with .get()
print("Mana points:", robot.get("mana", 0))`,
      errorType: 'KeyError',
      hint1Line: 'Look at line 3 where robot["mana"] is accessed.',
      hint2Concept: 'The dictionary has keys "name" and "battery", but no "mana".',
      hint3Fix: 'Use robot.get("mana", 0) or change "mana" to "battery".',
      explanation: 'Accessing a missing key with square brackets raises a KeyError. The safe .get() method returns a fallback default (like 0) instead of crashing.'
    },
    guidedProject: {
      id: 'proj-ch11',
      chapterNumber: 11,
      title: 'Digital Contact Directory',
      description: 'Build a contact directory dictionary that stores friends\' phone numbers, adds a new contact, and looks up contacts safely.',
      requirements: [
        'Create contacts with "Pip": "555-0101", "Alex": "555-0102".',
        'Add "Byte": "555-0103" to the dictionary.',
        'Print Pip\'s number using key access.',
        'Print total contacts using len(contacts).'
      ],
      planningSteps: [
        'Step 1: Declare starting contacts dictionary.',
        'Step 2: Add Byte.',
        'Step 3: Retrieve and print Pip\'s number.',
        'Step 4: Display total contacts count.'
      ],
      pseudocode: 'contacts = {"Pip": "555-0101", "Alex": "555-0102"}\ncontacts["Byte"] = "555-0103"\nPRINT f"Pip\'s Phone: {contacts[\'Pip\']}"\nPRINT f"Total contacts: {len(contacts)}"',
      starterCode: '# Build your contact directory below:\ncontacts = {"Pip": "555-0101", "Alex": "555-0102"}\n',
      solutionCode: `contacts = {"Pip": "555-0101", "Alex": "555-0102"}
contacts["Byte"] = "555-0103"

print(f"Pip's Phone: {contacts['Pip']}")
print(f"Total contacts: {len(contacts)}")`,
      verificationTips: [
        'Ensure phone numbers are strings (to preserve hyphens).',
        'Check that len(contacts) is 3.'
      ]
    }
  },

  // CHAPTER 12
  {
    number: 12,
    act: 3,
    actTitle: 'Act 3: Data & Structures',
    title: 'Functions and Reusable Code',
    subtitle: 'Parameters, arguments, return values, and modular design',
    tagline: 'Write once, test once, reuse a thousand times.',
    icon: '🧩',
    summary: 'Learn why functions are the building blocks of clean software: define your own with def, accept input parameters, return calculated outputs, and break big problems into small steps.',
    lessons: [
      {
        id: 'ch12-l1',
        chapterNumber: 12,
        lessonNumber: 1,
        title: 'Defining Functions with def and return',
        objective: 'Write custom reusable functions that accept parameters and return answers.',
        comicPanels: [
          {
            id: 'c12-p1',
            speaker: 'alex',
            mood: 'thinking',
            dialogue: 'I have the same 5 lines of math for calculating damage in 8 different places in my game. It is a messy copy-paste nightmare!',
            visualAction: 'Alex holds eight tangled duplicate code snippets.'
          },
          {
            id: 'c12-p2',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'That is why we use functions! Define it once with def calculate_damage(atk, defense): and give it a return value. Then just call it by name!',
            visualAction: 'Pip bundles the 8 messy snippets into a clean, glowing magic button.',
            soundFx: 'CLICK!',
            soundFxColor: '#10B981'
          },
          {
            id: 'c12-p3',
            speaker: 'byte',
            mood: 'coding',
            dialogue: 'Remember: def only defines the blueprint. The code will NOT run until you CALL it with parentheses: calculate_damage(10, 3)!',
            visualAction: 'Byte stamps an approved blueprint and presses the start button.'
          }
        ],
        realLifeProblem: 'Think of a coffee maker. You don\'t rebuild the coffee machine every morning. You just press the "Brew" button with your choice of water and coffee grounds!',
        analogy: {
          title: 'The Magic Vending Machine',
          description: 'A function is a vending machine. You drop in parameters (coins and selection), the machine executes its recipe inside, and it returns your product.',
          icon: '⚙️'
        },
        conceptText: 'Functions group code into reusable blocks. Use def function_name(param1, param2): to define it. The return statement sends a result back to whoever called the function. Without return, a function returns None by default.',
        syntaxRules: [
          'Define: def my_function(param):',
          'Return result: return result_value',
          'Call: output = my_function(argument_value)',
          'Variables created inside a function are local to that function (local scope).'
        ],
        workedExample: {
          id: 'ex-12-1',
          title: 'Damage Calculator Function',
          code: `def calculate_damage(attack, defense):
    """Calculates net damage after armor reduction."""
    net_damage = attack - defense
    if net_damage < 1:
        return 1  # Minimum 1 damage
    return net_damage

# Test our reusable function with different combatants!
strike1 = calculate_damage(15, 5)
strike2 = calculate_damage(5, 10)

print(f"Attack 1 dealt: {strike1} damage")
print(f"Attack 2 dealt: {strike2} damage")`,
          expectedOutput: 'Attack 1 dealt: 10 damage\nAttack 2 dealt: 1 damage',
          lineByLine: [
            { line: 1, code: 'def calculate_damage(attack, defense):', explanation: 'Declares function with two parameters: attack and defense.' },
            { line: 3, code: 'net_damage = attack - defense', explanation: 'Calculates raw damage inside local function scope.' },
            { line: 5, code: 'return 1', explanation: 'Returns 1 if armor completely absorbed the hit.' },
            { line: 6, code: 'return net_damage', explanation: 'Sends the calculated number back to the caller.' },
            { line: 9, code: 'strike1 = calculate_damage(15, 5)', explanation: 'Calls function: attack=15, defense=5. Returns 10!' }
          ],
          newlyIntroduced: ['def keyword', 'Parameters vs arguments', 'return statement', 'Local scope']
        },
        prediction: {
          question: 'What is the output of:\ndef add(a, b):\n    return a + b\nprint(add(3, 4))',
          codeSnippet: `def add(a, b):\n    return a + b\nprint(add(3, 4))`,
          options: ['7', '34', 'None', 'Error'],
          correctIndex: 0,
          explanation: '3 is passed to a, 4 is passed to b. a + b is 7, which is returned and printed.'
        },
        practiceChallenge: {
          title: 'Temperature Converter Function',
          prompt: 'Define a function celsius_to_fahrenheit(c) that returns (c * 9/5) + 32. Call it with 20 and print: "20C is {result}F".',
          starterCode: '# Define your temperature function below:\n',
          solutionCode: `def celsius_to_fahrenheit(c):
    return (c * 9/5) + 32

result = celsius_to_fahrenheit(20)
print(f"20C is {result}F")`,
          hints: [
            'Use def celsius_to_fahrenheit(c):',
            'Return (c * 9/5) + 32',
            'Call with celsius_to_fahrenheit(20)'
          ]
        },
        commonMistake: {
          title: 'Confusing print() with return',
          badCode: `def multiply(a, b):\n    print(a * b)\n\nanswer = multiply(4, 5)\nprint(answer + 2)`,
          whyItFails: 'multiply() printed the value but didn\'t return it! So answer is None, and None + 2 crashes with a TypeError!',
          fixedCode: `def multiply(a, b):\n    return a * b\n\nanswer = multiply(4, 5)\nprint(answer + 2)`,
          tip: 'Use return when you want the function to give back a value to be used elsewhere in code.'
        },
        threeKeyTakeaways: [
          'def defines a function; calling it with () executes it.',
          'Parameters allow you to pass custom data into a function.',
          'return hands the result back to the caller.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q12-1',
        question: 'What does a function return if it does not have a return statement?',
        options: ['0', '"" (empty string)', 'None', 'False'],
        correctIndex: 2,
        explanation: 'In Python, functions without an explicit return statement implicitly return None.',
        misconceptionHint: 'None is Python\'s special value representing the absence of a value.'
      },
      {
        id: 'q12-2',
        question: 'What is the difference between a parameter and an argument?',
        options: [
          'They are completely identical synonyms with no distinction.',
          'Parameters are variable placeholders in the function definition; arguments are the actual values passed in when called.',
          'Arguments are only for math functions.',
          'Parameters are only used in loops.'
        ],
        correctIndex: 1,
        explanation: 'Parameters are the named variables in the def line; arguments are the real values passed when calling.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch12',
      title: 'The Silent None Disaster',
      scenario: 'Alex wrote a function to calculate square footage, but forgot the return statement, causing total_area to be None!',
      buggyCode: `def get_area(width, height):
    area = width * height
    # Alex forgot to return area!

room = get_area(5, 4)
print("Room Area:", room)`,
      fixedCode: `def get_area(width, height):
    area = width * height
    return area

room = get_area(5, 4)
print("Room Area:", room)`,
      errorType: 'LogicError',
      hint1Line: 'Look inside get_area on line 2-3.',
      hint2Concept: 'area is calculated, but never handed back to the caller.',
      hint3Fix: 'Add return area inside the function.',
      explanation: 'Without a return statement, the calculated area is lost when the function finishes, returning None instead.'
    },
    guidedProject: {
      id: 'proj-ch12',
      chapterNumber: 12,
      title: 'Modular Quest Calculator',
      description: 'Build a reusable calculation module with functions for add, subtract, and calculate_xp, then call them to determine reward points.',
      requirements: [
        'Define add(a, b) returning a + b.',
        'Define calculate_xp(monsters_defeated, xp_per_monster) returning their product.',
        'Call calculate_xp(5, 100) and save to earned_xp.',
        'Print: "Earned XP: 500".'
      ],
      planningSteps: [
        'Step 1: Write add function.',
        'Step 2: Write calculate_xp function.',
        'Step 3: Call calculate_xp with 5 and 100.',
        'Step 4: Print formatted output.'
      ],
      pseudocode: 'DEF calculate_xp(monsters, xp_each):\n  RETURN monsters * xp_each\nearned = calculate_xp(5, 100)\nPRINT f"Earned XP: {earned}"',
      starterCode: '# Build your quest calculator functions below:\n',
      solutionCode: `def calculate_xp(monsters, xp_each):
    return monsters * xp_each

earned_xp = calculate_xp(5, 100)
print(f"Earned XP: {earned_xp}")`,
      verificationTips: [
        'Ensure calculate_xp returns the product.',
        'Verify output matches "Earned XP: 500".'
      ]
    }
  },

  // CHAPTER 13
  {
    number: 13,
    act: 3,
    actTitle: 'Act 3: Data & Structures',
    title: 'Modules and the Standard Library',
    subtitle: 'Importing superpowers from random, math, and beyond',
    tagline: 'Python comes with "batteries included".',
    icon: '📦',
    summary: 'Discover Python\'s standard library: import modules like random for dice rolls, math for square roots, and understand how packages work in Python.',
    lessons: [
      {
        id: 'ch13-l1',
        chapterNumber: 13,
        lessonNumber: 1,
        title: 'Rolling the Dice with the random Module',
        objective: 'Use import to bring standard library modules into your program.',
        comicPanels: [
          {
            id: 'c13-p1',
            speaker: 'alex',
            mood: 'thinking',
            dialogue: 'I want to build a tabletop RPG dice roller. Does Python know how to pick random numbers?',
            visualAction: 'Alex holds a twenty-sided gaming die.'
          },
          {
            id: 'c13-p2',
            speaker: 'pip',
            mood: 'explaining',
            dialogue: 'Python has hundreds of built-in toolboxes called modules! Just write import random, and you get access to randint(), choice(), and shuffle()!',
            visualAction: 'Pip pulls a toolbox labeled "Standard Library" off a shelf.',
            soundFx: 'TADA!',
            soundFxColor: '#10B981'
          },
          {
            id: 'c13-p3',
            speaker: 'byte',
            mood: 'happy',
            dialogue: 'Executing random.randint(1, 20)! Result: 20! Critical Hit! The monster is stunned!',
            visualAction: 'Byte celebrates with golden sparks shooting from antenna.'
          }
        ],
        realLifeProblem: 'Video games need unpredictable enemy spawns, music apps need shuffle buttons, and security apps need random tokens. Standard modules give you these features instantly without reinventing the wheel!',
        analogy: {
          title: 'The Specialty Tool Rental Shop',
          description: 'import is like borrowing a specialized laser tool from a workshop. Instead of building a laser from scratch, you import it and use its features.',
          icon: '🧰'
        },
        conceptText: 'A module is simply a Python file containing pre-written functions and variables. Python includes a vast collection called the Standard Library ("batteries included"). Common modules include random (dice, choices), math (pi, sqrt), and datetime (dates and clocks).',
        syntaxRules: [
          'import random brings in the random module.',
          'Call functions with module_name.function_name(): random.randint(1, 6).',
          'random.choice(["sword", "shield"]) randomly picks one element from a list.',
          'Always put import statements at the very top of your file.'
        ],
        workedExample: {
          id: 'ex-13-1',
          title: 'Rolling a 20-Sided Die and Choosing Loot',
          code: `import random

# Roll a 20-sided die
d20_roll = random.randint(1, 20)
print(f"You rolled a {d20_roll} on the D20!")

# Pick random loot from a chest
loot_table = ["Healing Salve", "Ruby Gem", "Rusty Key", "Legendary Bow"]
dropped_item = random.choice(loot_table)
print(f"The treasure chest dropped: {dropped_item}")`,
          expectedOutput: 'You rolled a 18 on the D20!\nThe treasure chest dropped: Legendary Bow',
          lineByLine: [
            { line: 1, code: 'import random', explanation: 'Loads Python\'s built-in random number module.' },
            { line: 4, code: 'random.randint(1, 20)', explanation: 'Generates a random integer between 1 and 20 (both included).' },
            { line: 8, code: 'random.choice(loot_table)', explanation: 'Randomly selects one element from the list.' }
          ],
          newlyIntroduced: ['import keyword', 'random.randint()', 'random.choice()']
        },
        prediction: {
          question: 'What is the possible range of numbers from random.randint(1, 6)?',
          codeSnippet: `import random\nroll = random.randint(1, 6)`,
          options: ['0, 1, 2, 3, 4, 5', '1, 2, 3, 4, 5', '1, 2, 3, 4, 5, 6', '1 to 5.999'],
          correctIndex: 2,
          explanation: 'Unlike range(), randint(a, b) includes BOTH endpoints: 1 and 6 are both possible.'
        },
        practiceChallenge: {
          title: 'Coin Flipper Simulator',
          prompt: 'Import random, define coin = ["Heads", "Tails"], pick a random side with random.choice(), and print: "Coin landed on: {side}".',
          starterCode: '# Import random and flip a coin below:\n',
          solutionCode: `import random

coin = ["Heads", "Tails"]
side = random.choice(coin)
print(f"Coin landed on: {side}")`,
          hints: [
            'Start with import random',
            'Use random.choice(coin)',
            'Print the result with an f-string.'
          ]
        },
        commonMistake: {
          title: 'Forgetting the Module Prefix',
          badCode: `import random\nroll = randint(1, 6)`,
          whyItFails: 'Python does not know what "randint" is on its own! It raises NameError: name \'randint\' is not defined.',
          fixedCode: `import random\nroll = random.randint(1, 6)`,
          tip: 'Always prefix the function with the module name: random.randint().'
        },
        threeKeyTakeaways: [
          'Modules are pre-written code packages you load with import.',
          'random.randint(a, b) generates random integers including both bounds.',
          'Python\'s standard library has thousands of tested functions ready to use.'
        ]
      }
    ],
    quiz: [
      {
        id: 'q13-1',
        question: 'Where should import statements normally be placed in a Python file?',
        options: [
          'At the very bottom of the file',
          'At the very top of the file',
          'Inside an if statement',
          'Inside a print statement'
        ],
        correctIndex: 1,
        explanation: 'According to Python PEP 8 style guidelines, imports should always be placed at the top of the file.',
        misconceptionHint: 'Top of file makes dependencies clear to anyone reading the code.'
      },
      {
        id: 'q13-2',
        question: 'What does math.sqrt(25) return?',
        options: ['5.0', '12.5', '625', 'Error'],
        correctIndex: 0,
        explanation: 'math.sqrt() calculates the square root of a number. The square root of 25 is 5.0.',
        misconceptionHint: 'sqrt stands for SQuare RooT.'
      }
    ],
    debugChallenge: {
      id: 'debug-ch13',
      title: 'The Forgotten Import',
      scenario: 'Bugsy erased the import statement, causing Python to panic when trying to roll a die!',
      buggyCode: `# Bugsy removed line 1!
roll = random.randint(1, 6)
print("Die roll:", roll)`,
      fixedCode: `import random

roll = random.randint(1, 6)
print("Die roll:", roll)`,
      errorType: 'NameError',
      hint1Line: 'Look at line 1 before the code starts.',
      hint2Concept: 'Python does not know what random is until you import it.',
      hint3Fix: 'Add import random as the first line of code.',
      explanation: 'Before using any module from the standard library, you must tell Python to load it using the import keyword.'
    },
    guidedProject: {
      id: 'proj-ch13',
      chapterNumber: 13,
      title: 'Number Guessing Mini-Game',
      description: 'Build a number guessing game where the computer picks a secret number between 1 and 5, compares it to user guess, and declares win or lose.',
      requirements: [
        'Import random.',
        'Generate secret = random.randint(1, 5).',
        'Set user_guess = 3.',
        'If user_guess == secret: print "Jackpot! You guessed correctly!".',
        'Else: print f"Nice try! Secret was {secret}."'
      ],
      planningSteps: [
        'Step 1: Import random.',
        'Step 2: Generate secret number.',
        'Step 3: Define guess.',
        'Step 4: Branch on match.'
      ],
      pseudocode: 'IMPORT random\nsecret = random.randint(1, 5)\nguess = 3\nIF guess == secret: PRINT win\nELSE: PRINT reveal',
      starterCode: '# Build your number guessing game below:\n',
      solutionCode: `import random

secret = random.randint(1, 5)
guess = 3

if guess == secret:
    print("Jackpot! You guessed correctly!")
else:
    print(f"Nice try! Secret was {secret}.")`,
      verificationTips: [
        'Test both outcomes by running multiple times.',
        'Check that the secret is between 1 and 5.'
      ]
    }
  }
];
