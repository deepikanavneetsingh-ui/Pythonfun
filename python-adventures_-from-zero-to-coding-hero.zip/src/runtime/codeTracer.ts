/**
 * Code Replay Execution Tracer
 * Instrumenting and stepping through Python 3 code line-by-line,
 * capturing variable memory snapshots, console output diffs, and character explanations.
 */

export interface VariableInfo {
  name: string;
  value: any;
  type: string;
  formattedValue: string;
  isNew?: boolean;
  isChanged?: boolean;
}

export interface ExecutionStep {
  stepIndex: number;
  lineNumber: number;
  lineContent: string;
  actionType: 'assignment' | 'print' | 'condition' | 'loop' | 'function' | 'input' | 'append' | 'statement' | 'error';
  variables: Record<string, VariableInfo>;
  changedVariables: string[];
  outputSoFar: string;
  stepOutput?: string;
  explanation: string;
  speaker: 'pip' | 'byte' | 'alex' | 'bugsy';
  isError?: boolean;
}

export interface ReplayTraceResult {
  steps: ExecutionStep[];
  totalSteps: number;
  finalOutput: string;
  error?: string;
  errorLine?: number;
  beginnerTip?: string;
}

class CodeTracer {
  private formatValue(val: any): { type: string; formatted: string } {
    if (val === null) return { type: 'None', formatted: 'None' };
    if (val === undefined) return { type: 'None', formatted: 'None' };
    if (typeof val === 'boolean') return { type: 'bool', formatted: val ? 'True' : 'False' };
    if (typeof val === 'number') {
      return Number.isInteger(val)
        ? { type: 'int', formatted: String(val) }
        : { type: 'float', formatted: String(val) };
    }
    if (typeof val === 'string') return { type: 'str', formatted: `"${val}"` };
    if (Array.isArray(val)) {
      try {
        const items = val.map((item) => {
          if (typeof item === 'string') return `"${item}"`;
          return String(item);
        });
        return { type: 'list', formatted: `[${items.join(', ')}]` };
      } catch {
        return { type: 'list', formatted: '[...]' };
      }
    }
    if (typeof val === 'object') {
      try {
        return { type: 'dict', formatted: JSON.stringify(val).replace(/"/g, "'") };
      } catch {
        return { type: 'dict', formatted: '{...}' };
      }
    }
    return { type: typeof val, formatted: String(val) };
  }

  private extractCandidateVariables(code: string): string[] {
    const vars = new Set<string>();
    const lines = code.split('\n');

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;

      // Assignment: x = ..., x += ...
      const assignMatch = trimmed.match(/^([a-zA-Z_]\w*)\s*(\+|-|\*|\/)?=/);
      if (assignMatch && assignMatch[1] !== 'return') {
        vars.add(assignMatch[1]);
      }

      // Multiple assignment: a, b = ...
      const multiMatch = trimmed.match(/^([a-zA-Z_]\w*)\s*,\s*([a-zA-Z_]\w*)\s*=/);
      if (multiMatch) {
        vars.add(multiMatch[1]);
        vars.add(multiMatch[2]);
      }

      // For loops: for x in ...
      const forMatch = trimmed.match(/^for\s+([a-zA-Z_]\w*)\s+in/);
      if (forMatch) {
        vars.add(forMatch[1]);
      }

      // Functions: def func(a, b)
      const defMatch = trimmed.match(/^def\s+([a-zA-Z_]\w*)\s*\((.*?)\)/);
      if (defMatch) {
        const params = defMatch[2].split(',').map((p) => p.trim()).filter(Boolean);
        for (const p of params) {
          vars.add(p);
        }
      }
    }

    return Array.from(vars);
  }

  private generateExplanation(
    lineContent: string,
    actionType: ExecutionStep['actionType'],
    changedVars: string[],
    stepOutput: string | undefined,
    vars: Record<string, VariableInfo>
  ): { text: string; speaker: 'pip' | 'byte' | 'alex' | 'bugsy' } {
    const trimmed = lineContent.trim();

    if (actionType === 'print') {
      if (stepOutput) {
        return {
          text: `Byte sent data to the console output: "${stepOutput}"`,
          speaker: 'byte'
        };
      }
      return {
        text: 'Byte is executing the print statement to display text on screen.',
        speaker: 'byte'
      };
    }

    if (actionType === 'input') {
      return {
        text: `Alex received input from the user and stored the string response in memory.`,
        speaker: 'alex'
      };
    }

    if (actionType === 'condition') {
      if (trimmed.startsWith('if ')) {
        return {
          text: `Pip is testing the "if" condition to determine which branch of code to follow.`,
          speaker: 'pip'
        };
      }
      if (trimmed.startsWith('elif ')) {
        return {
          text: `Pip is checking this "elif" alternative branch condition.`,
          speaker: 'pip'
        };
      }
      return {
        text: `Pip took the "else" default fallback branch because previous tests were False.`,
        speaker: 'pip'
      };
    }

    if (actionType === 'loop') {
      const forVar = trimmed.match(/^for\s+(\w+)/);
      if (forVar && vars[forVar[1]]) {
        return {
          text: `Loop iteration running: loop variable "${forVar[1]}" is currently set to ${vars[forVar[1]].formattedValue}.`,
          speaker: 'alex'
        };
      }
      return {
        text: 'Repeating the loop body for the next sequence item.',
        speaker: 'alex'
      };
    }

    if (actionType === 'append') {
      return {
        text: 'Added a new element to the list in memory.',
        speaker: 'byte'
      };
    }

    if (actionType === 'function') {
      return {
        text: 'Pip defined this custom function and stored its recipe in computer memory.',
        speaker: 'pip'
      };
    }

    if (actionType === 'assignment') {
      if (changedVars.length > 0) {
        const v = changedVars[0];
        const val = vars[v]?.formattedValue ?? 'value';
        return {
          text: `Byte updated memory: variable "${v}" now holds ${val}.`,
          speaker: 'byte'
        };
      }
      return {
        text: 'Byte allocated variable storage and computed the result.',
        speaker: 'byte'
      };
    }

    return {
      text: `Python executed line: "${trimmed}".`,
      speaker: 'pip'
    };
  }

  public async trace(code: string, simulatedInputs: string[] = ['Adventurer', '25', 'hero']): Promise<ReplayTraceResult> {
    const candidateVars = this.extractCandidateVariables(code);
    const steps: ExecutionStep[] = [];
    const stdoutLines: string[] = [];
    let prevStepOutputCount = 0;
    let previousVars: Record<string, any> = {};
    let inputIndex = 0;
    const maxSteps = 160;
    const startTime = Date.now();
    const timeoutMs = 3000;

    // Helper for stepping
    const recordStep = (
      lineNum: number,
      rawLine: string,
      action: ExecutionStep['actionType'],
      varGetter: () => Record<string, any>
    ) => {
      if (steps.length >= maxSteps) return;
      if (Date.now() - startTime > timeoutMs) {
        throw new Error('TimeoutError: Replay exceeded maximum time limit.');
      }

      const rawVars = varGetter();
      const currentVars: Record<string, VariableInfo> = {};
      const changedVarNames: string[] = [];

      for (const [k, v] of Object.entries(rawVars)) {
        const formatted = this.formatValue(v);
        const isNew = previousVars[k] === undefined;
        const isChanged = !isNew && JSON.stringify(previousVars[k]) !== JSON.stringify(v);

        if (isNew || isChanged) {
          changedVarNames.push(k);
        }

        currentVars[k] = {
          name: k,
          value: v,
          type: formatted.type,
          formattedValue: formatted.formatted,
          isNew,
          isChanged
        };
      }

      // Check if new output was printed on this step
      let stepOutputStr: string | undefined = undefined;
      if (stdoutLines.length > prevStepOutputCount) {
        stepOutputStr = stdoutLines.slice(prevStepOutputCount).join('\n');
        prevStepOutputCount = stdoutLines.length;
      }

      const commentary = this.generateExplanation(
        rawLine,
        action,
        changedVarNames,
        stepOutputStr,
        currentVars
      );

      steps.push({
        stepIndex: steps.length,
        lineNumber: lineNum,
        lineContent: rawLine,
        actionType: action,
        variables: currentVars,
        changedVariables: changedVarNames,
        outputSoFar: stdoutLines.join('\n'),
        stepOutput: stepOutputStr,
        explanation: commentary.text,
        speaker: commentary.speaker
      });

      // Update previous variables copy
      previousVars = { ...rawVars };
    };

    // Custom print & input in sandbox
    const customPrint = (...args: any[]) => {
      const formatted = args
        .map((arg) => {
          if (typeof arg === 'object' && arg !== null) {
            try {
              return JSON.stringify(arg).replace(/"/g, "'");
            } catch {
              return String(arg);
            }
          }
          return String(arg);
        })
        .join(' ');
      stdoutLines.push(formatted);
    };

    const customInput = async (promptMsg: string = ''): Promise<string> => {
      if (promptMsg) {
        stdoutLines.push(promptMsg);
      }
      const val = simulatedInputs[inputIndex] || 'Alex';
      inputIndex++;
      return val;
    };

    // Build instrumented JavaScript code
    const lines = code.split('\n');
    const jsLines: string[] = [];
    const indentStack: number[] = [0];

    // Helper to generate variable getter string
    const genVarGetter = () => {
      const checks = candidateVars.map((v) => `try { if (typeof ${v} !== 'undefined' && typeof ${v} !== 'function') _res['${v}'] = Array.isArray(${v}) ? [...${v}] : (typeof ${v} === 'object' && ${v} !== null ? {...${v}} : ${v}); } catch {}`);
      return `(() => { const _res = {}; ${checks.join(' ')} return _res; })`;
    };

    const varGetterStr = genVarGetter();

    for (let i = 0; i < lines.length; i++) {
      const rawLine = lines[i];
      const trimmed = rawLine.trim();
      const lineNum = i + 1;

      if (!trimmed || trimmed.startsWith('#')) {
        continue;
      }

      const indent = rawLine.search(/\S/);

      // Handle dedents
      while (indent < indentStack[indentStack.length - 1]) {
        indentStack.pop();
        jsLines.push('}');
      }

      let transformed = trimmed;

      // Handle f-strings
      transformed = transformed.replace(/f"([^"]*)"/g, (_, content) => {
        const jsTemplate = content.replace(/\{([^}]+)\}/g, '${$1}');
        return `\`${jsTemplate}\``;
      });
      transformed = transformed.replace(/f'([^']*)'/g, (_, content) => {
        const jsTemplate = content.replace(/\{([^}]+)\}/g, '${$1}');
        return `\`${jsTemplate}\``;
      });

      // Replace operators
      transformed = transformed.replace(/\band\b/g, '&&');
      transformed = transformed.replace(/\bor\b/g, '||');
      transformed = transformed.replace(/\bnot\b/g, '!');
      transformed = transformed.replace(/\bTrue\b/g, 'true');
      transformed = transformed.replace(/\bFalse\b/g, 'false');
      transformed = transformed.replace(/\bNone\b/g, 'null');

      // Functions: def func(...)
      const defMatch = transformed.match(/^def\s+([a-zA-Z_]\w*)\s*\((.*?)\)\s*:/);
      if (defMatch) {
        const fnName = defMatch[1];
        const fnArgs = defMatch[2];
        jsLines.push(
          `__step(${lineNum}, ${JSON.stringify(rawLine)}, 'function', ${varGetterStr});`
        );
        jsLines.push(`async function ${fnName}(${fnArgs}) {`);
        indentStack.push(indent + 4);
        continue;
      }

      // If / Elif / Else
      const ifMatch = transformed.match(/^if\s+(.*?)\s*:/);
      if (ifMatch) {
        jsLines.push(
          `__step(${lineNum}, ${JSON.stringify(rawLine)}, 'condition', ${varGetterStr});`
        );
        jsLines.push(`if (${ifMatch[1]}) {`);
        indentStack.push(indent + 4);
        continue;
      }

      const elifMatch = transformed.match(/^elif\s+(.*?)\s*:/);
      if (elifMatch) {
        jsLines.push(
          `__step(${lineNum}, ${JSON.stringify(rawLine)}, 'condition', ${varGetterStr});`
        );
        jsLines.push(`else if (${elifMatch[1]}) {`);
        indentStack.push(indent + 4);
        continue;
      }

      const elseMatch = transformed.match(/^else\s*:/);
      if (elseMatch) {
        jsLines.push(
          `__step(${lineNum}, ${JSON.stringify(rawLine)}, 'condition', ${varGetterStr});`
        );
        jsLines.push('else {');
        indentStack.push(indent + 4);
        continue;
      }

      // For loop
      const forMatch = transformed.match(/^for\s+([a-zA-Z_]\w*)\s+in\s+(.*?)\s*:/);
      if (forMatch) {
        const loopVar = forMatch[1];
        const iterable = forMatch[2];
        jsLines.push(`for (let ${loopVar} of (${iterable})) {`);
        jsLines.push(
          `__step(${lineNum}, ${JSON.stringify(rawLine)}, 'loop', ${varGetterStr});`
        );
        indentStack.push(indent + 4);
        continue;
      }

      // While loop
      const whileMatch = transformed.match(/^while\s+(.*?)\s*:/);
      if (whileMatch) {
        jsLines.push(
          `__step(${lineNum}, ${JSON.stringify(rawLine)}, 'loop', ${varGetterStr});`
        );
        jsLines.push(`while (${whileMatch[1]}) {`);
        indentStack.push(indent + 4);
        continue;
      }

      // Print calls
      if (transformed.startsWith('print(') || transformed.startsWith('print ')) {
        const cleanedPrint = transformed.replace(/\bprint\s*\(/g, 'print(');
        jsLines.push(`${cleanedPrint};`);
        jsLines.push(
          `__step(${lineNum}, ${JSON.stringify(rawLine)}, 'print', ${varGetterStr});`
        );
        continue;
      }

      // List .append()
      if (transformed.includes('.append(')) {
        const pushForm = transformed.replace(/\.append\(/g, '.push(');
        jsLines.push(`${pushForm};`);
        jsLines.push(
          `__step(${lineNum}, ${JSON.stringify(rawLine)}, 'append', ${varGetterStr});`
        );
        continue;
      }

      // Input prompt
      if (transformed.includes('input(')) {
        transformed = transformed.replace(/\binput\s*\(/g, 'await input(');
        const assignVar = transformed.match(/^([a-zA-Z_]\w*)\s*=\s*/);
        if (assignVar) {
          const varName = assignVar[1];
          jsLines.push(`if (typeof ${varName} === 'undefined') var ${varName};`);
        }
        jsLines.push(`${transformed};`);
        jsLines.push(
          `__step(${lineNum}, ${JSON.stringify(rawLine)}, 'input', ${varGetterStr});`
        );
        continue;
      }

      // Assignments
      if (/^[a-zA-Z_]\w*\s*(\+|-|\*|\/)?=\s*/.test(transformed) && !transformed.startsWith('return')) {
        const varName = transformed.split(/\s*(\+|-|\*|\/)?=/)[0].trim();
        jsLines.push(`if (typeof ${varName} === 'undefined') var ${varName};`);
        jsLines.push(`${transformed};`);
        jsLines.push(
          `__step(${lineNum}, ${JSON.stringify(rawLine)}, 'assignment', ${varGetterStr});`
        );
        continue;
      }

      // Return statements
      if (transformed.startsWith('return ') || transformed === 'return') {
        jsLines.push(
          `__step(${lineNum}, ${JSON.stringify(rawLine)}, 'statement', ${varGetterStr});`
        );
        jsLines.push(`${transformed};`);
        continue;
      }

      // Regular statement
      jsLines.push(`${transformed};`);
      jsLines.push(
        `__step(${lineNum}, ${JSON.stringify(rawLine)}, 'statement', ${varGetterStr});`
      );
    }

    // Close open blocks
    while (indentStack.length > 1) {
      indentStack.pop();
      jsLines.push('}');
    }

    // Prepare scope
    const scope: Record<string, any> = {
      __step: recordStep,
      print: customPrint,
      input: customInput,
      range: (start: number, stop?: number, step: number = 1) => {
        if (stop === undefined) {
          stop = start;
          start = 0;
        }
        const arr: number[] = [];
        if (step > 0) {
          for (let i = start; i < stop; i += step) arr.push(i);
        } else {
          for (let i = start; i > stop; i += step) arr.push(i);
        }
        return arr;
      },
      len: (obj: any) => (obj !== undefined && obj !== null ? (obj.length !== undefined ? obj.length : Object.keys(obj).length) : 0),
      int: (val: any) => parseInt(val, 10) || 0,
      float: (val: any) => parseFloat(val) || 0.0,
      str: (val: any) => String(val),
      type: (val: any) => `<class '${typeof val}'>`,
      sum: (arr: number[]) => arr.reduce((a, b) => a + b, 0),
      max: (...args: any[]) => Math.max(...(args.length === 1 && Array.isArray(args[0]) ? args[0] : args)),
      min: (...args: any[]) => Math.min(...(args.length === 1 && Array.isArray(args[0]) ? args[0] : args)),
      round: (v: number, d: number = 0) => Math.round(v * Math.pow(10, d)) / Math.pow(10, d),
      abs: (v: number) => Math.abs(v),
      random: {
        randint: (a: number, b: number) => Math.floor(Math.random() * (b - a + 1)) + a,
        choice: (list: any[]) => list[Math.floor(Math.random() * list.length)]
      },
      math: {
        pi: Math.PI,
        sqrt: Math.sqrt,
        floor: Math.floor,
        ceil: Math.ceil
      },
      True: true,
      False: false,
      None: null
    };

    try {
      const keys = Object.keys(scope);
      const values = Object.values(scope);
      const scriptBody = jsLines.join('\n');
      const runner = new Function(...keys, `return (async () => { ${scriptBody} })();`);
      await runner(...values);

      return {
        steps,
        totalSteps: steps.length,
        finalOutput: stdoutLines.join('\n') || '(Program completed with no output)'
      };
    } catch (err: any) {
      const errMsg = String(err?.message || err);
      // Try to detect error line
      let errLine = 1;
      const match = errMsg.match(/line (\d+)/i);
      if (match) {
        errLine = parseInt(match[1], 10);
      } else if (steps.length > 0) {
        errLine = steps[steps.length - 1].lineNumber;
      }

      // Add an error step to show in the replay
      steps.push({
        stepIndex: steps.length,
        lineNumber: errLine,
        lineContent: lines[errLine - 1] || 'Error point',
        actionType: 'error',
        variables: previousVars,
        changedVariables: [],
        outputSoFar: stdoutLines.join('\n'),
        explanation: `Bugsy noticed a problem here! ${errMsg}`,
        speaker: 'bugsy',
        isError: true
      });

      return {
        steps,
        totalSteps: steps.length,
        finalOutput: stdoutLines.join('\n'),
        error: errMsg,
        errorLine: errLine,
        beginnerTip: "Bugsy is checking this line: make sure syntax, variable names, and data types match!"
      };
    }
  }
}

export const codeTracer = new CodeTracer();
