/**
 * Python In-Browser Execution Engine
 * Provides dual execution: Pyodide (when available online) + In-Browser Python 3 Interpreter
 * Supports real Python execution, print(), input() prompting, loops, functions, lists, dicts, and error diagnostics.
 */

export interface RunResult {
  output: string;
  error?: string;
  beginnerTip?: string;
  executionTimeMs: number;
}

export type InputPromptHandler = (promptText: string) => Promise<string>;

class PythonRunner {
  private pyodideLoaded: boolean = false;
  private pyodideInstance: any = null;
  private isInitializing: boolean = false;

  constructor() {
    this.initPyodide();
  }

  private async initPyodide() {
    if (typeof window === 'undefined' || this.isInitializing || this.pyodideLoaded) return;
    this.isInitializing = true;

    try {
      // Check if pyodide is already on window
      if ((window as any).loadPyodide) {
        this.pyodideInstance = await (window as any).loadPyodide();
        this.pyodideLoaded = true;
        return;
      }

      // Try dynamically loading pyodide script
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js';
      script.async = true;
      script.onload = async () => {
        try {
          if ((window as any).loadPyodide) {
            this.pyodideInstance = await (window as any).loadPyodide();
            this.pyodideLoaded = true;
          }
        } catch {
          // Fall back gracefully
        }
      };
      script.onerror = () => {
        // Will use built-in engine
      };
      document.head.appendChild(script);
    } catch {
      // Graceful fallback
    } finally {
      this.isInitializing = false;
    }
  }

  /**
   * Run Python code with support for custom input prompts
   */
  public async execute(code: string, onPromptInput?: InputPromptHandler): Promise<RunResult> {
    const startTime = performance.now();

    // 1. Try Pyodide if loaded and no interactive input is needed, or run through our sandbox
    if (this.pyodideLoaded && this.pyodideInstance && !code.includes('input(')) {
      try {
        let stdout = '';
        this.pyodideInstance.setStdout({
          batched: (str: string) => {
            stdout += str + '\n';
          }
        });
        await this.pyodideInstance.runPythonAsync(code);
        const duration = Math.round(performance.now() - startTime);
        return {
          output: stdout.trimEnd() || '(Program completed with no output)',
          executionTimeMs: duration
        };
      } catch (err: any) {
        const errorMsg = String(err?.message || err);
        return {
          output: '',
          error: errorMsg,
          beginnerTip: this.diagnoseError(errorMsg, code),
          executionTimeMs: Math.round(performance.now() - startTime)
        };
      }
    }

    // 2. High-performance In-Browser Python 3 Interpreter with asynchronous input() support
    try {
      const output = await this.runInterpretedPython(code, onPromptInput);
      const duration = Math.round(performance.now() - startTime);
      return {
        output: output || '(Program completed with no output)',
        executionTimeMs: duration
      };
    } catch (err: any) {
      const errorMsg = String(err?.message || err);
      return {
        output: '',
        error: errorMsg,
        beginnerTip: this.diagnoseError(errorMsg, code),
        executionTimeMs: Math.round(performance.now() - startTime)
      };
    }
  }

  /**
   * Safe, beginner-friendly Python 3 runtime supporting variables, print, input, loops, lists, dicts, math
   */
  private async runInterpretedPython(code: string, onPromptInput?: InputPromptHandler): Promise<string> {
    const outputLines: string[] = [];
    const timeoutThreshold = 4000;
    const startExec = Date.now();

    // Custom print implementation
    const customPrint = (...args: any[]) => {
      const formatted = args.map(arg => {
        if (typeof arg === 'object' && arg !== null) {
          try {
            return JSON.stringify(arg).replace(/"/g, "'");
          } catch {
            return String(arg);
          }
        }
        return String(arg);
      }).join(' ');
      outputLines.push(formatted);
    };

    // Custom input implementation
    const customInput = async (promptMsg: string = ''): Promise<string> => {
      if (promptMsg) {
        outputLines.push(promptMsg);
      }
      if (onPromptInput) {
        const result = await onPromptInput(promptMsg);
        return result;
      }
      return 'User';
    };

    // Check basic indentation or syntax
    this.checkBasicSyntax(code);

    // Transform Python code into executable JS for common beginner patterns
    const jsCode = this.transpilePythonToJS(code);

    // Context sandbox
    const scope: Record<string, any> = {
      print: customPrint,
      input: customInput,
      range: (start: number, stop?: number, step: number = 1) => {
        if (stop === undefined) {
          stop = start;
          start = 0;
        }
        const arr: number[] = [];
        if (step > 0) {
          for (let i = start; i < stop; i += step) arr.push(i);
        } else {
          for (let i = start; i > stop; i += step) arr.push(i);
        }
        return arr;
      },
      len: (obj: any) => {
        if (obj === undefined || obj === null) throw new Error("TypeError: object of type 'NoneType' has no len()");
        return obj.length !== undefined ? obj.length : Object.keys(obj).length;
      },
      int: (val: any) => {
        const parsed = parseInt(val, 10);
        if (isNaN(parsed)) throw new Error(`ValueError: invalid literal for int() with base 10: '${val}'`);
        return parsed;
      },
      float: (val: any) => {
        const parsed = parseFloat(val);
        if (isNaN(parsed)) throw new Error(`ValueError: could not convert string to float: '${val}'`);
        return parsed;
      },
      str: (val: any) => String(val),
      type: (val: any) => {
        if (typeof val === 'number') return Number.isInteger(val) ? "<class 'int'>" : "<class 'float'>";
        if (typeof val === 'string') return "<class 'str'>";
        if (typeof val === 'boolean') return "<class 'bool'>";
        if (Array.isArray(val)) return "<class 'list'>";
        if (typeof val === 'object') return "<class 'dict'>";
        return "<class 'object'>";
      },
      sum: (list: number[]) => list.reduce((a, b) => a + b, 0),
      max: (...args: any[]) => {
        const items = args.length === 1 && Array.isArray(args[0]) ? args[0] : args;
        return Math.max(...items);
      },
      min: (...args: any[]) => {
        const items = args.length === 1 && Array.isArray(args[0]) ? args[0] : args;
        return Math.min(...items);
      },
      round: (val: number, digits: number = 0) => {
        const factor = Math.pow(10, digits);
        return Math.round(val * factor) / factor;
      },
      abs: (val: number) => Math.abs(val),
      random: {
        randint: (a: number, b: number) => Math.floor(Math.random() * (b - a + 1)) + a,
        choice: (list: any[]) => list[Math.floor(Math.random() * list.length)]
      },
      math: {
        pi: Math.PI,
        sqrt: (x: number) => Math.sqrt(x),
        floor: (x: number) => Math.floor(x),
        ceil: (x: number) => Math.ceil(x)
      },
      True: true,
      False: false,
      None: null,
      __checkLoop: () => {
        if (Date.now() - startExec > timeoutThreshold) {
          throw new Error('TimeoutError: Execution exceeded 4 seconds. You might have an infinite while loop without an exit condition!');
        }
      }
    };

    // Execute with async function wrapper
    const keys = Object.keys(scope);
    const values = Object.values(scope);
    const runnerFn = new Function(...keys, `return (async () => { ${jsCode} })();`);
    await runnerFn(...values);

    return outputLines.join('\n');
  }

  private checkBasicSyntax(code: string) {
    const lines = code.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;

      // Check missing colon on control flow
      if (/^(if|elif|else|for|while|def|class|try|except|finally)\b/.test(trimmed)) {
        if (!trimmed.endsWith(':') && !trimmed.includes('#')) {
          throw new Error(`SyntaxError: expected ':' at end of line ${i + 1}\n  --> ${line}`);
        }
      }

      // Check unbalanced parentheses
      let openParen = 0;
      for (const ch of line) {
        if (ch === '(') openParen++;
        if (ch === ')') openParen--;
      }
      if (openParen > 0 && !line.includes('"""') && !line.includes("'''")) {
        // If unclosed on this single line
        if (i === lines.length - 1 || (!lines[i + 1].trim().startsWith(')') && !lines[i + 1].includes(')'))) {
          throw new Error(`SyntaxError: unexpected EOF while parsing or unclosed parenthesis on line ${i + 1}\n  --> ${line}`);
        }
      }
    }
  }

  private transpilePythonToJS(code: string): string {
    const lines = code.split('\n');
    const jsLines: string[] = [];
    const indentStack: number[] = [0];

    for (let i = 0; i < lines.length; i++) {
      const rawLine = lines[i];
      const trimmed = rawLine.trim();

      if (!trimmed || trimmed.startsWith('#')) {
        continue;
      }

      const indent = rawLine.search(/\S/);

      // Handle dedents
      while (indent < indentStack[indentStack.length - 1]) {
        indentStack.pop();
        jsLines.push('}');
      }

      let transformed = trimmed;

      // Replace Python f-strings: f"Hello {name}" -> `Hello ${name}`
      transformed = transformed.replace(/f"([^"]*)"/g, (_, content) => {
        const jsTemplate = content.replace(/\{([^}]+)\}/g, '${$1}');
        return `\`${jsTemplate}\``;
      });
      transformed = transformed.replace(/f'([^']*)'/g, (_, content) => {
        const jsTemplate = content.replace(/\{([^}]+)\}/g, '${$1}');
        return `\`${jsTemplate}\``;
      });

      // Replace operators
      transformed = transformed.replace(/\band\b/g, '&&');
      transformed = transformed.replace(/\bor\b/g, '||');
      transformed = transformed.replace(/\bnot\b/g, '!');
      transformed = transformed.replace(/\bTrue\b/g, 'true');
      transformed = transformed.replace(/\bFalse\b/g, 'false');
      transformed = transformed.replace(/\bNone\b/g, 'null');

      // Replace print() calls to await safe print
      transformed = transformed.replace(/\bprint\s*\(/g, 'print(');

      // Replace input() calls with await input()
      transformed = transformed.replace(/\binput\s*\(/g, 'await input(');

      // Handle def function_name(args):
      const defMatch = transformed.match(/^def\s+([a-zA-Z_]\w*)\s*\((.*?)\)\s*:/);
      if (defMatch) {
        const fnName = defMatch[1];
        const fnArgs = defMatch[2];
        jsLines.push(`async function ${fnName}(${fnArgs}) {`);
        indentStack.push(indent + 4);
        continue;
      }

      // Handle if / elif / else:
      const ifMatch = transformed.match(/^if\s+(.*?)\s*:/);
      if (ifMatch) {
        jsLines.push(`if (${ifMatch[1]}) {`);
        indentStack.push(indent + 4);
        continue;
      }
      const elifMatch = transformed.match(/^elif\s+(.*?)\s*:/);
      if (elifMatch) {
        jsLines.push(`else if (${elifMatch[1]}) {`);
        indentStack.push(indent + 4);
        continue;
      }
      const elseMatch = transformed.match(/^else\s*:/);
      if (elseMatch) {
        jsLines.push('else {');
        indentStack.push(indent + 4);
        continue;
      }

      // Handle for item in list_or_range:
      const forMatch = transformed.match(/^for\s+([a-zA-Z_]\w*)\s+in\s+(.*?)\s*:/);
      if (forMatch) {
        const loopVar = forMatch[1];
        const iterable = forMatch[2];
        jsLines.push(`for (let ${loopVar} of (${iterable})) { __checkLoop();`);
        indentStack.push(indent + 4);
        continue;
      }

      // Handle while condition:
      const whileMatch = transformed.match(/^while\s+(.*?)\s*:/);
      if (whileMatch) {
        jsLines.push(`while (${whileMatch[1]}) { __checkLoop();`);
        indentStack.push(indent + 4);
        continue;
      }

      // Handle variable assignment: var_name = ...
      if (/^[a-zA-Z_]\w*\s*(\+|-|\*|\/)?=\s*/.test(transformed) && !transformed.startsWith('return')) {
        const varName = transformed.split(/\s*(\+|-|\*|\/)?=/)[0].trim();
        // Check if list append: list.append(x) -> list.push(x)
        if (transformed.includes('.append(')) {
          transformed = transformed.replace(/\.append\(/g, '.push(');
        }
        jsLines.push(`if (typeof ${varName} === 'undefined') var ${varName}; ${transformed};`);
        continue;
      }

      // Handle .append() statement directly
      if (transformed.includes('.append(')) {
        transformed = transformed.replace(/\.append\(/g, '.push(');
      }

      // Return statement
      if (transformed.startsWith('return ') || transformed === 'return') {
        jsLines.push(`${transformed};`);
        continue;
      }

      // Standard expression or statement
      jsLines.push(`${transformed};`);
    }

    // Close remaining open blocks
    while (indentStack.length > 1) {
      indentStack.pop();
      jsLines.push('}');
    }

    return jsLines.join('\n');
  }

  /**
   * Diagnostic helper translating scary Python error messages into friendly advice from Bugsy & Pip
   */
  public diagnoseError(errorMsg: string, code: string): string {
    if (errorMsg.includes('SyntaxError') && errorMsg.includes(':')) {
      return "Bugsy spotted a missing colon! In Python, statements like 'if', 'elif', 'else', 'for', 'while', and 'def' must end with a colon (:).";
    }
    if (errorMsg.includes('unclosed parenthesis') || errorMsg.includes('unexpected EOF')) {
      return "Pip noticed an unmatched parenthesis '(' or quote '\"'. Make sure every opening bracket or quote has a matching partner!";
    }
    if (errorMsg.includes('NameError') || errorMsg.includes('is not defined')) {
      const match = errorMsg.match(/name '(\w+)' is not defined/) || errorMsg.match(/(\w+) is not defined/);
      const name = match ? match[1] : 'that variable';
      return `Alex is wondering: did you create '${name}' before using it? Remember that Python is case-sensitive: 'Name' and 'name' are two different things!`;
    }
    if (errorMsg.includes('TypeError') && (errorMsg.includes('concatenate') || errorMsg.includes('string to float'))) {
      return "Byte was confused by mixed data types! You cannot glue a number directly to a string with '+'. Use str(number) or an f-string like f\"Score: {score}\"!";
    }
    if (errorMsg.includes('IndexError') || errorMsg.includes('out of range')) {
      return "Pip says: Remember Python lists start at index 0! If a list has 3 items, their indexes are 0, 1, and 2. Trying to access index 3 goes off the edge.";
    }
    if (errorMsg.includes('TimeoutError')) {
      return "Byte got caught in a loop! Your 'while' loop didn't stop. Double check that your loop variable changes inside the loop so the condition eventually becomes False.";
    }
    return "Bugsy loves this puzzle! Read the error message carefully to find the line number, and check spelling, indentation, or quotation marks.";
  }
}

export const pythonRunner = new PythonRunner();
