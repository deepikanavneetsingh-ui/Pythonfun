import React from 'react';
import { ALL_CHAPTERS } from '../data/chapters';
import { Printer, ArrowLeft, BookOpen, CheckCircle2 } from 'lucide-react';
import { soundFX } from '../utils/soundEffects';

interface PrintBookViewProps {
  onBack: () => void;
}

export const PrintBookView: React.FC<PrintBookViewProps> = ({ onBack }) => {
  const handlePrint = () => {
    soundFX.playPop();
    window.print();
  };

  return (
    <div className="bg-white min-h-screen text-slate-900 font-serif">
      {/* Non-printed Toolbar */}
      <div className="no-print sticky top-0 z-40 bg-[#1E293B] text-white px-6 py-3.5 flex items-center justify-between border-b-4 border-amber-400 shadow-md">
        <button
          onClick={onBack}
          className="comic-button px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer"
        >
          <ArrowLeft size={16} /> Back to Interactive App
        </button>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-300 hidden sm:inline">
            Print-friendly layout formatted for standard A4 / US Letter pages.
          </span>
          <button
            onClick={handlePrint}
            className="comic-button px-5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-900 font-extrabold text-xs rounded-xl flex items-center gap-2 cursor-pointer shadow-sm"
          >
            <Printer size={15} /> Print / Save as PDF
          </button>
        </div>
      </div>

      {/* Book Cover Page */}
      <div className="max-w-4xl mx-auto p-8 sm:p-14 space-y-12 text-center py-20 border-b border-slate-300">
        <div className="inline-block p-2 px-4 rounded-full border-2 border-slate-900 text-xs font-mono font-bold uppercase tracking-widest bg-amber-100 text-amber-900 mb-4">
          Complete Interactive Curriculum • Reference Edition
        </div>
        <h1 className="font-comic text-4xl sm:text-6xl text-slate-900 tracking-wide">
          PYTHON ADVENTURES
        </h1>
        <div className="text-xl sm:text-2xl text-amber-800 font-sans font-bold">
          From Zero to Coding Hero
        </div>
        <p className="text-base text-slate-600 max-w-lg mx-auto font-sans leading-relaxed">
          Learn Python from Scratch Through Stories, Comic Dialogues, Real-Life Analogies,
          Step-by-Step Code Walkthroughs, and Practical Projects.
        </p>
        <div className="pt-10 text-xs text-slate-500 font-sans">
          Created with Google AI Studio Build • Original Cast: Pip, Alex, Byte & Bugsy
        </div>
      </div>

      {/* Table of Contents */}
      <div className="max-w-4xl mx-auto p-8 sm:p-14 print-page-break">
        <h2 className="font-comic text-2xl sm:text-3xl text-slate-900 mb-6 border-b-2 border-slate-900 pb-2">
          Table of Contents
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-sans text-xs">
          {ALL_CHAPTERS.map((ch) => (
            <div
              key={ch.number}
              className="p-3 border border-slate-200 rounded-lg flex items-start gap-2.5"
            >
              <span className="font-bold font-mono text-amber-700 shrink-0">Ch {ch.number}.</span>
              <div>
                <div className="font-bold text-slate-900">{ch.title}</div>
                <div className="text-slate-500 text-[11px]">{ch.subtitle}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 20 Chapters Content */}
      <div className="max-w-4xl mx-auto p-8 sm:p-14 space-y-16">
        {ALL_CHAPTERS.map((ch) => (
          <section key={ch.number} className="print-page-break space-y-6 pt-8 border-t-2 border-slate-300">
            {/* Chapter Header */}
            <div>
              <div className="text-xs font-mono font-bold text-amber-700 uppercase tracking-widest">
                {ch.actTitle}
              </div>
              <h2 className="font-comic text-2xl sm:text-3xl text-slate-900 mt-1">
                Chapter {ch.number}: {ch.title}
              </h2>
              <h3 className="font-sans text-sm font-bold text-slate-600 mt-0.5">
                {ch.subtitle}
              </h3>
              <p className="font-sans text-xs text-slate-500 italic mt-1">
                "{ch.tagline}"
              </p>
            </div>

            {/* Lessons in Chapter */}
            {ch.lessons.map((lesson) => (
              <div key={lesson.id} className="space-y-4 font-sans text-xs sm:text-sm">
                <h3 className="font-comic text-lg text-slate-900 border-b border-slate-200 pb-1">
                  Lesson {lesson.lessonNumber}: {lesson.title}
                </h3>
                <div className="text-slate-700 font-medium">
                  <strong>Objective:</strong> {lesson.objective}
                </div>

                {/* Comic Dialogue Transcript */}
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-300 space-y-2">
                  <div className="text-[11px] font-bold uppercase text-slate-500 font-mono">
                    Comic Scene Transcript:
                  </div>
                  {lesson.comicPanels.map((p, pIdx) => (
                    <div key={p.id} className="text-xs">
                      <span className="font-bold uppercase text-amber-800">
                        {p.speaker.toUpperCase()}:
                      </span>{' '}
                      <span className="italic">"{p.dialogue}"</span>
                      {p.soundFx && (
                        <span className="ml-2 font-mono font-bold text-orange-600">
                          [{p.soundFx}]
                        </span>
                      )}
                    </div>
                  ))}
                </div>

                {/* Analogy & Concept */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-amber-50 rounded border border-amber-200">
                    <strong className="text-amber-900">Analogy: {lesson.analogy.title}</strong>
                    <p className="mt-1 text-slate-700">{lesson.analogy.description}</p>
                  </div>
                  <div className="p-3 bg-teal-50 rounded border border-teal-200">
                    <strong className="text-teal-900">Real-Life Problem:</strong>
                    <p className="mt-1 text-slate-700">{lesson.realLifeProblem}</p>
                  </div>
                </div>

                {/* Concept text */}
                <p className="leading-relaxed text-slate-800">{lesson.conceptText}</p>

                {/* Worked Code Example */}
                <div className="border border-slate-300 rounded-lg overflow-hidden font-mono text-xs">
                  <div className="bg-slate-100 p-2 font-bold text-slate-700 border-b border-slate-300">
                    Example: {lesson.workedExample.title}
                  </div>
                  <pre className="p-3 bg-slate-50 whitespace-pre-wrap text-slate-900">
                    {lesson.workedExample.code}
                  </pre>
                  <div className="p-2.5 bg-slate-100 border-t border-slate-300 text-[11px]">
                    <strong>Expected Output:</strong>
                    <pre className="mt-1 whitespace-pre-wrap">{lesson.workedExample.expectedOutput}</pre>
                  </div>
                </div>

                {/* 3 Key Takeaways */}
                <div className="p-3 bg-slate-100 rounded-lg border border-slate-200 text-xs">
                  <strong className="text-slate-900 block mb-1">Key Takeaways:</strong>
                  <ul className="list-disc list-inside space-y-0.5 text-slate-700">
                    {lesson.threeKeyTakeaways.map((takeaway, tIdx) => (
                      <li key={tIdx}>{takeaway}</li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}

            {/* Guided Project Brief */}
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-300 font-sans text-xs space-y-2">
              <strong className="font-comic text-sm text-slate-900 block">
                Chapter Project: {ch.guidedProject.title}
              </strong>
              <p className="text-slate-700">{ch.guidedProject.description}</p>
              <div className="font-mono text-[11px] p-2 bg-white rounded border border-slate-200">
                <strong>Solution Code:</strong>
                <pre className="mt-1 whitespace-pre-wrap">{ch.guidedProject.solutionCode}</pre>
              </div>
            </div>
          </section>
        ))}

        {/* Complete Answer Key Section */}
        <section className="print-page-break pt-8 border-t-4 border-slate-900 font-sans space-y-6">
          <h2 className="font-comic text-2xl sm:text-3xl text-slate-900 border-b-2 border-slate-900 pb-2">
            Complete Curriculum Answer Key & Solutions
          </h2>
          <div className="space-y-4 text-xs">
            {ALL_CHAPTERS.map((ch) => (
              <div key={ch.number} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                <div className="font-bold text-sm text-slate-900 mb-2">
                  Chapter {ch.number} Assessment Answers:
                </div>
                <div className="space-y-2">
                  {ch.quiz.map((q, qIdx) => (
                    <div key={q.id}>
                      <span className="font-bold">Q{qIdx + 1}:</span> {q.question}
                      <div className="text-emerald-800 font-semibold pl-4">
                        ✓ Correct Answer: {q.options[q.correctIndex]}
                      </div>
                      <div className="text-slate-600 text-[11px] pl-4">{q.explanation}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
