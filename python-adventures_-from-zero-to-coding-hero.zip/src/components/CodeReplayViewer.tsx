import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  RotateCcw,
  Volume2,
  Square,
  Sparkles,
  Cpu,
  Terminal,
  X,
  AlertCircle,
  HelpCircle,
  CheckCircle2,
  Clock,
  ChevronRight
} from 'lucide-react';
import { ExecutionStep, ReplayTraceResult, VariableInfo } from '../runtime/codeTracer';
import { PipCharacter, AlexCharacter, ByteCharacter, BugsyCharacter } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';
import { speechService } from '../utils/speechService';

interface CodeReplayViewerProps {
  code: string;
  traceResult: ReplayTraceResult;
  onCloseReplay: () => void;
}

export const CodeReplayViewer: React.FC<CodeReplayViewerProps> = ({
  code,
  traceResult,
  onCloseReplay
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1); // 0.5, 1, 1.5, 2
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const playTimerRef = useRef<any>(null);
  const codeLinesContainerRef = useRef<HTMLDivElement>(null);

  const steps = traceResult.steps || [];
  const totalSteps = steps.length;
  const currentStep: ExecutionStep | undefined = steps[currentStepIndex];

  // Stop speech when component unmounts
  useEffect(() => {
    return () => {
      speechService.stop();
      if (playTimerRef.current) clearInterval(playTimerRef.current);
    };
  }, []);

  // Playback timer loop
  useEffect(() => {
    if (isPlaying) {
      const intervalMs = Math.round(1600 / playbackSpeed);
      playTimerRef.current = setInterval(() => {
        setCurrentStepIndex((prev) => {
          if (prev >= totalSteps - 1) {
            setIsPlaying(false);
            return prev;
          }
          soundFX.playPop();
          return prev + 1;
        });
      }, intervalMs);
    } else {
      if (playTimerRef.current) clearInterval(playTimerRef.current);
    }

    return () => {
      if (playTimerRef.current) clearInterval(playTimerRef.current);
    };
  }, [isPlaying, playbackSpeed, totalSteps]);

  // Auto-scroll active line into view in the code editor
  useEffect(() => {
    if (!currentStep) return;
    const lineEl = document.getElementById(`replay-line-${currentStep.lineNumber}`);
    if (lineEl && codeLinesContainerRef.current) {
      lineEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, [currentStepIndex, currentStep]);

  const handleStepChange = (newIndex: number) => {
    speechService.stop();
    setIsSpeaking(false);
    soundFX.playPop();
    const clamped = Math.max(0, Math.min(newIndex, totalSteps - 1));
    setCurrentStepIndex(clamped);
  };

  const togglePlay = () => {
    speechService.stop();
    setIsSpeaking(false);
    soundFX.playPop();
    if (currentStepIndex >= totalSteps - 1 && !isPlaying) {
      setCurrentStepIndex(0);
    }
    setIsPlaying((prev) => !prev);
  };

  const handleSpeakCurrentStep = () => {
    if (!currentStep) return;

    if (isSpeaking) {
      speechService.stop();
      setIsSpeaking(false);
      return;
    }

    soundFX.playPop();
    setIsSpeaking(true);

    const speechText = `${currentStep.explanation}. Code on line ${currentStep.lineNumber}: ${currentStep.lineContent.trim()}`;
    speechService.speak(
      speechText,
      currentStep.speaker,
      `replay-step-${currentStepIndex}`,
      () => setIsSpeaking(true),
      () => setIsSpeaking(false),
      () => setIsSpeaking(false)
    );
  };

  const renderCharacterAvatar = (speaker: 'pip' | 'byte' | 'alex' | 'bugsy', size = 52) => {
    switch (speaker) {
      case 'byte':
        return <ByteCharacter mood={isSpeaking ? 'coding' : 'happy'} size={size} isSpeaking={isSpeaking} />;
      case 'alex':
        return <AlexCharacter mood={isSpeaking ? 'explaining' : 'thinking'} size={size} isSpeaking={isSpeaking} />;
      case 'bugsy':
        return <BugsyCharacter mood="thinking" size={size} isSpeaking={isSpeaking} />;
      case 'pip':
      default:
        return <PipCharacter mood={isSpeaking ? 'explaining' : 'happy'} size={size} isSpeaking={isSpeaking} />;
    }
  };

  const getSpeakerLabel = (speaker: string) => {
    switch (speaker) {
      case 'byte':
        return 'Byte the CPU Robot';
      case 'alex':
        return 'Alex the Learner';
      case 'bugsy':
        return 'Bugsy Detective';
      case 'pip':
      default:
        return 'Pip the Python Instructor';
    }
  };

  const codeLines = code.split('\n');

  if (totalSteps === 0) {
    return (
      <div className="p-8 text-center flex flex-col items-center justify-center space-y-4 bg-slate-900 text-white min-h-[400px]">
        <BugsyCharacter mood="surprised" size={80} />
        <h3 className="font-comic text-xl text-amber-400">No Executable Steps Found</h3>
        <p className="text-sm text-slate-300 max-w-md">
          {traceResult.error || "Type some Python statements like variable assignments or print() calls to replay them!"}
        </p>
        <button
          onClick={onCloseReplay}
          className="comic-button px-5 py-2 bg-amber-400 text-slate-900 font-bold rounded-xl text-xs cursor-pointer"
        >
          Return to Code Editor
        </button>
      </div>
    );
  }

  const activeLineNumber = currentStep?.lineNumber ?? 1;
  const variablesList: VariableInfo[] = currentStep ? Object.values(currentStep.variables) : [];

  return (
    <div className="flex flex-col h-full bg-[#1E293B] text-slate-100 overflow-hidden">
      {/* Top Replay Bar */}
      <div className="bg-[#0F172A] px-4 py-3 border-b border-slate-700 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-amber-400 text-slate-900">
            <Sparkles size={16} className="stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-comic text-sm text-amber-300 tracking-wider">
                Code Replay Studio
              </span>
              <span className="bg-slate-800 text-emerald-400 px-2 py-0.5 rounded text-[10px] font-mono border border-slate-700">
                Step {currentStepIndex + 1} of {totalSteps}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Watch line-by-line execution, memory allocations, and console stream in real time.
            </p>
          </div>
        </div>

        {/* Playback Controls */}
        <div className="flex items-center gap-2">
          {/* Speed selector */}
          <div className="flex items-center bg-slate-800 rounded-lg p-0.5 border border-slate-700 text-[11px] font-bold">
            {[0.5, 1, 1.5, 2].map((spd) => (
              <button
                key={spd}
                onClick={() => setPlaybackSpeed(spd)}
                className={`px-2 py-1 rounded-md transition-colors cursor-pointer ${
                  playbackSpeed === spd
                    ? 'bg-amber-400 text-slate-900 font-extrabold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title={`Playback speed: ${spd}x`}
              >
                {spd}x
              </button>
            ))}
          </div>

          {/* Stepping buttons */}
          <button
            onClick={() => handleStepChange(0)}
            disabled={currentStepIndex === 0}
            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 cursor-pointer"
            title="Jump to Start"
          >
            <RotateCcw size={15} />
          </button>

          <button
            onClick={() => handleStepChange(currentStepIndex - 1)}
            disabled={currentStepIndex === 0}
            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 cursor-pointer"
            title="Previous Step (Line)"
          >
            <SkipBack size={16} />
          </button>

          <button
            onClick={togglePlay}
            className={`comic-button px-3.5 py-1.5 rounded-lg font-bold flex items-center gap-1.5 cursor-pointer shadow-sm ${
              isPlaying
                ? 'bg-rose-500 hover:bg-rose-600 text-white'
                : 'bg-emerald-500 hover:bg-emerald-400 text-white'
            }`}
            title={isPlaying ? 'Pause replay' : 'Play replay'}
          >
            {isPlaying ? <Pause size={14} className="fill-white" /> : <Play size={14} className="fill-white" />}
            <span>{isPlaying ? 'Pause' : 'Play'}</span>
          </button>

          <button
            onClick={() => handleStepChange(currentStepIndex + 1)}
            disabled={currentStepIndex >= totalSteps - 1}
            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 cursor-pointer"
            title="Next Step (Line)"
          >
            <SkipForward size={16} />
          </button>

          <button
            onClick={onCloseReplay}
            className="ml-2 px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white font-bold flex items-center gap-1 cursor-pointer"
            title="Exit Replay mode and edit code"
          >
            <X size={15} />
            <span>Exit Replay</span>
          </button>
        </div>
      </div>

      {/* Scrubber Progress Slider */}
      <div className="bg-[#0F172A]/80 px-4 py-2 border-b border-slate-800 flex items-center gap-3">
        <span className="text-[10px] font-mono text-slate-400">Step 1</span>
        <input
          type="range"
          min={0}
          max={totalSteps - 1}
          value={currentStepIndex}
          onChange={(e) => handleStepChange(parseInt(e.target.value, 10))}
          className="flex-1 accent-amber-400 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
        />
        <span className="text-[10px] font-mono text-slate-400">Step {totalSteps}</span>
      </div>

      {/* Main Split: Code Viewer on Left, Visual Trace Inspector on Right */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-700 overflow-hidden">
        {/* Left: Code Line-by-Line Highlight Editor (7 Columns) */}
        <div className="lg:col-span-7 flex flex-col bg-[#1E293B] overflow-hidden">
          <div className="bg-[#111827] px-4 py-2 border-b border-slate-700 flex items-center justify-between text-xs text-slate-300 font-mono">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping"></span>
              <span>main.py (Executing Line {activeLineNumber})</span>
            </div>
            <span className="text-[10px] text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-800">
              Action: {currentStep?.actionType.toUpperCase()}
            </span>
          </div>

          {/* Line by line display */}
          <div
            ref={codeLinesContainerRef}
            className="flex-1 overflow-y-auto font-mono text-sm leading-relaxed p-3 space-y-1 select-none"
          >
            {codeLines.map((line, idx) => {
              const lineNum = idx + 1;
              const isActive = lineNum === activeLineNumber;
              const isError = currentStep?.isError && isActive;

              return (
                <div
                  key={idx}
                  id={`replay-line-${lineNum}`}
                  onClick={() => {
                    // Jump to first step matching this line
                    const matchIndex = steps.findIndex((s) => s.lineNumber === lineNum);
                    if (matchIndex !== -1) handleStepChange(matchIndex);
                  }}
                  className={`flex items-start rounded-md transition-all cursor-pointer ${
                    isError
                      ? 'bg-rose-950/80 border-2 border-rose-500 text-rose-200 shadow-md ring-2 ring-rose-500/30'
                      : isActive
                      ? 'bg-amber-400/20 border-2 border-amber-400 text-amber-100 shadow-lg ring-2 ring-amber-400/30 font-bold'
                      : 'hover:bg-slate-800/60 text-slate-300'
                  }`}
                >
                  {/* Line Number */}
                  <div
                    className={`py-1.5 px-3 text-right text-xs font-mono select-none min-w-[42px] border-r ${
                      isError
                        ? 'bg-rose-900/60 text-rose-300 border-rose-700'
                        : isActive
                        ? 'bg-amber-500 text-slate-900 font-black border-amber-400'
                        : 'text-slate-500 border-slate-700/60'
                    }`}
                  >
                    {lineNum}
                  </div>

                  {/* Active Indicator & Line Content */}
                  <div className="py-1.5 px-3 flex-1 flex items-center justify-between font-mono overflow-x-auto">
                    <span className="whitespace-pre">
                      {line || ' '}
                    </span>
                    {isActive && (
                      <span className="ml-2 text-[10px] shrink-0 font-comic uppercase tracking-wider px-2 py-0.5 rounded bg-amber-400 text-slate-900 font-extrabold flex items-center gap-1 shadow-sm">
                        <ChevronRight size={12} className="stroke-[3]" /> Running
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: State Inspector (Narrator Bubble + Variables + Output Console) (5 Columns) */}
        <div className="lg:col-span-5 flex flex-col bg-[#0F172A] overflow-y-auto divide-y divide-slate-800">
          {/* 1. Character Narrative & Speech Bubble */}
          <div className="p-4 bg-gradient-to-b from-[#1E293B] to-[#0F172A] space-y-3">
            <div className="flex items-start gap-3">
              <div
                onClick={handleSpeakCurrentStep}
                className="cursor-pointer shrink-0 hover:scale-105 transition-transform"
                title="Click character to hear explanation in Indian English"
              >
                {renderCharacterAvatar(currentStep?.speaker || 'byte', 56)}
              </div>

              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] font-comic uppercase tracking-wider text-amber-400 font-bold">
                    {getSpeakerLabel(currentStep?.speaker || 'byte')}
                  </span>
                  <button
                    onClick={handleSpeakCurrentStep}
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                      isSpeaking
                        ? 'bg-rose-500 text-white animate-pulse'
                        : 'bg-amber-400/20 text-amber-300 border border-amber-400/40 hover:bg-amber-400/30'
                    }`}
                    title="Click to hear explanation in native Indian English"
                  >
                    {isSpeaking ? <Square size={10} className="fill-white" /> : <Volume2 size={10} />}
                    <span>{isSpeaking ? 'Stop Voice' : 'Hear Pip/Byte 🇮🇳'}</span>
                  </button>
                </div>

                <div className="comic-panel p-3 bg-white text-slate-900 text-xs rounded-xl shadow-md border-2 border-slate-900 relative speech-bubble-bottom">
                  <p className="font-medium leading-relaxed font-sans">
                    {currentStep?.explanation}
                  </p>
                  {isSpeaking && (
                    <div className="mt-2 flex items-center gap-1 text-[10px] text-amber-800 font-mono font-bold">
                      <span className="w-1 bg-amber-600 rounded-full animate-eq-1" />
                      <span className="w-1 bg-amber-600 rounded-full animate-eq-2" />
                      <span className="w-1 bg-amber-600 rounded-full animate-eq-3" />
                      <span className="ml-1">Speaking with Indian native dialect...</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* 2. Variables & Memory Inspector */}
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span className="flex items-center gap-1.5 text-sky-400 font-comic uppercase tracking-wider text-[11px]">
                <Cpu size={14} /> Computer Memory (Variables)
              </span>
              <span className="text-[10px] font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                {variablesList.length} Allocated
              </span>
            </div>

            {variablesList.length === 0 ? (
              <div className="p-4 rounded-xl border border-dashed border-slate-700 text-center text-xs text-slate-500 bg-slate-900/40">
                Memory Empty • Variables will appear here as lines assign them!
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {variablesList.map((varItem) => {
                  const isChanged = currentStep?.changedVariables.includes(varItem.name);

                  let typeBg = 'bg-slate-800 text-slate-300 border-slate-700';
                  if (varItem.type === 'str') typeBg = 'bg-emerald-950/80 text-emerald-300 border-emerald-700';
                  else if (varItem.type === 'int' || varItem.type === 'float') typeBg = 'bg-amber-950/80 text-amber-300 border-amber-700';
                  else if (varItem.type === 'list') typeBg = 'bg-purple-950/80 text-purple-300 border-purple-700';
                  else if (varItem.type === 'bool') typeBg = 'bg-sky-950/80 text-sky-300 border-sky-700';

                  return (
                    <div
                      key={varItem.name}
                      className={`p-2.5 rounded-xl border font-mono transition-all ${
                        isChanged
                          ? 'bg-amber-400/15 border-amber-400 ring-2 ring-amber-400/40 shadow-md animate-pulse'
                          : 'bg-slate-800/80 border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[11px] mb-1">
                        <span className="font-bold text-white flex items-center gap-1">
                          {varItem.name}
                        </span>
                        <span className={`text-[9px] px-1.5 py-0.2 rounded uppercase font-bold border ${typeBg}`}>
                          {varItem.type}
                        </span>
                      </div>
                      <div className="text-xs text-amber-200 truncate font-mono font-semibold" title={varItem.formattedValue}>
                        {varItem.formattedValue}
                      </div>
                      {isChanged && (
                        <div className="mt-1 text-[9px] font-bold text-amber-400 uppercase tracking-widest flex items-center gap-0.5">
                          <CheckCircle2 size={10} /> Updated this line
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* 3. Output Stream Console */}
          <div className="p-4 flex-1 flex flex-col space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span className="flex items-center gap-1.5 text-emerald-400 font-comic uppercase tracking-wider text-[11px]">
                <Terminal size={14} /> Console Output Stream
              </span>
              {currentStep?.stepOutput && (
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                  New Output
                </span>
              )}
            </div>

            <div className="flex-1 min-h-[120px] bg-black/60 border border-slate-800 rounded-xl p-3 font-mono text-xs text-emerald-400 leading-relaxed overflow-y-auto">
              {currentStep?.outputSoFar ? (
                <pre className="whitespace-pre-wrap">{currentStep.outputSoFar}</pre>
              ) : (
                <span className="text-slate-600 italic">No output produced yet...</span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
