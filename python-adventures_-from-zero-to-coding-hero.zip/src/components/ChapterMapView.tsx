import React, { useState, useMemo } from 'react';
import { Chapter } from '../types/curriculum';
import { UserProgress } from '../types/curriculum';
import { PipCharacter, AlexCharacter, ByteCharacter } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';
import {
  CheckCircle2,
  BookOpen,
  HelpCircle,
  ShieldAlert,
  Hammer,
  Sparkles,
  ArrowRight,
  Flame,
  Award,
  Lock,
  UserPlus
} from 'lucide-react';

interface ChapterMapProps {
  chapters: Chapter[];
  progress: UserProgress;
  isAuthenticated: boolean;
  onSelectChapter: (chapterNumber: number) => void;
  onOpenQuiz: (chapterNumber: number) => void;
  onOpenDebugLab: (chapterNumber: number) => void;
  onOpenProject: (chapterNumber: number) => void;
  onRequireAuth: (chapterNumber: number) => void;
}

export const ChapterMapView: React.FC<ChapterMapProps> = ({
  chapters,
  progress,
  isAuthenticated,
  onSelectChapter,
  onOpenQuiz,
  onOpenDebugLab,
  onOpenProject,
  onRequireAuth
}) => {
  const [selectedAct, setSelectedAct] = useState<number>(0); // 0 = all, 1..4 = specific act

  const acts = useMemo(() => [
    { number: 0, title: 'All Chapters (1 - 20)' },
    { number: 1, title: 'Act 1: The First Spark (Ch 1 - 5)' },
    { number: 2, title: 'Act 2: Logic & Control (Ch 6 - 9)' },
    { number: 3, title: 'Act 3: Data & Structures (Ch 10 - 13)' },
    { number: 4, title: 'Act 4: Real-World Mastery (Ch 14 - 20)' }
  ], []);

  const filteredChapters = useMemo(() => {
    return selectedAct === 0 ? chapters : chapters.filter((c) => c.act === selectedAct);
  }, [chapters, selectedAct]);

  const completedCount = progress.completedChapters.length;
  const progressPercent = Math.round((completedCount / 20) * 100);

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-16">
      {/* Hero Header & Progress Summary */}
      <div className="comic-panel p-6 sm:p-8 bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-200 border-slate-900 shadow-xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold font-comic text-slate-800 uppercase tracking-widest">
              <span>Python Adventures World Map</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Flame size={14} className="text-orange-600" /> {progress.streakCount} Day Streak
              </span>
            </div>
            <h1 className="font-comic text-3xl sm:text-4xl text-slate-900 mt-1">
              Curriculum Roadmap
            </h1>
            <p className="text-xs sm:text-sm text-slate-700 mt-1 max-w-xl font-medium">
              Explore all 20 chapters across 4 epic story acts. Chapter 1 is open for public usage; Chapters 2 to 20 unlock post-registration!
            </p>
          </div>

          {/* Character Cluster */}
          <div className="flex items-end gap-2 bg-white/70 backdrop-blur-xs p-3 rounded-2xl border-2 border-slate-900 shadow-md">
            <PipCharacter mood="happy" size={56} />
            <AlexCharacter mood="coding" size={56} />
            <ByteCharacter mood="happy" size={56} />
          </div>
        </div>

        {/* Master Progress Bar */}
        <div className="mt-6 pt-5 border-t border-slate-900/20">
          <div className="flex items-center justify-between text-xs font-bold text-slate-800 mb-2">
            <span>Overall Python Mastery Progress</span>
            <span>
              {completedCount} of 20 Chapters Mastered ({progressPercent}%)
            </span>
          </div>
          <div className="w-full bg-slate-900/20 h-4 rounded-full border border-slate-900 overflow-hidden p-0.5">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-500 shadow-inner"
              style={{ width: `${Math.max(progressPercent, 4)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Public vs Locked Chapters Banner if Guest */}
      {!isAuthenticated && (
        <div className="comic-panel p-4 bg-gradient-to-r from-amber-50 via-yellow-50 to-amber-100 border-2 border-amber-500 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
          <div className="flex items-center gap-3 text-center sm:text-left">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold shrink-0 border border-slate-900">
              <Lock size={20} />
            </div>
            <div>
              <div className="font-comic text-sm text-slate-900 flex items-center gap-1.5 justify-center sm:justify-start">
                <span>Chapter 1 is Publicly Free • Chapters 2–20 Locked</span>
              </div>
              <div className="text-xs text-slate-600">
                You can complete Chapter 1 right now! Create a free student account on the homepage to unlock Chapters 2 to 20.
              </div>
            </div>
          </div>

          <button
            onClick={() => onRequireAuth(2)}
            className="shrink-0 comic-button px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <UserPlus size={14} />
            <span>Register Free to Unlock</span>
          </button>
        </div>
      )}

      {/* Act Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar text-xs">
        {acts.map((act) => (
          <button
            key={act.number}
            onClick={() => {
              soundFX.playPop();
              setSelectedAct(act.number);
            }}
            className={`comic-button px-4 py-2 rounded-xl font-bold whitespace-nowrap cursor-pointer transition-all ${
              selectedAct === act.number
                ? 'bg-[#1E293B] text-white'
                : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300'
            }`}
          >
            {act.title}
          </button>
        ))}
      </div>

      {/* Chapters Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredChapters.map((ch) => {
          const isCompleted = progress.completedChapters.includes(ch.number);
          const quizResult = progress.quizScores[ch.number];
          const isDebugSolved = progress.solvedDebugs.includes(ch.debugChallenge.id);
          const isProjectDone = progress.completedProjects.includes(ch.guidedProject.id);

          const isPublic = ch.number === 1;
          const isLocked = !isAuthenticated && !isPublic;

          return (
            <div
              key={ch.number}
              className={`comic-panel p-6 flex flex-col justify-between transition-all hover:-translate-y-1 ${
                isCompleted
                  ? 'border-emerald-600 bg-emerald-50/20'
                  : isLocked
                  ? 'border-slate-400 bg-slate-50/70 opacity-95'
                  : 'border-slate-900 bg-white'
              }`}
            >
              <div>
                {/* Chapter Top Badge */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className={`w-8 h-8 rounded-lg font-comic font-black text-xs flex items-center justify-center border border-slate-900 shadow-xs ${
                      isLocked ? 'bg-slate-300 text-slate-700' : 'bg-amber-400 text-slate-900'
                    }`}>
                      {ch.number}
                    </span>
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                      {ch.actTitle}
                    </span>
                  </div>

                  {isCompleted ? (
                    <span className="flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-full border border-emerald-400">
                      <CheckCircle2 size={14} /> Mastered
                    </span>
                  ) : isPublic ? (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full border border-emerald-300">
                      🌟 Public Free Access
                    </span>
                  ) : isLocked ? (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-amber-900 bg-amber-100 px-2 py-0.5 rounded-full border border-amber-300">
                      <Lock size={12} /> Post-Registration Only
                    </span>
                  ) : null}
                </div>

                <h2 className="font-comic text-xl text-slate-900 flex items-center gap-2">
                  <span>{ch.icon}</span>
                  <span>{ch.title}</span>
                  {isLocked && <Lock size={16} className="text-amber-600 inline ml-1" />}
                </h2>
                <h3 className="text-xs font-bold text-amber-800 mt-0.5">{ch.subtitle}</h3>

                <p className="text-xs text-slate-600 mt-2 leading-relaxed">{ch.summary}</p>

                {/* Chapter Tagline */}
                <div className="mt-3 p-2 bg-slate-100/70 rounded-lg border border-slate-200 text-[11px] italic text-slate-600 font-serif">
                  "{ch.tagline}"
                </div>
              </div>

              {/* Sub-activities status badges */}
              <div className="mt-5 pt-4 border-t border-slate-200 space-y-3">
                <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
                  {/* Quiz status */}
                  <button
                    onClick={() => {
                      if (isLocked) {
                        onRequireAuth(ch.number);
                      } else {
                        onOpenQuiz(ch.number);
                      }
                    }}
                    className={`p-2 rounded-lg border font-bold transition-colors cursor-pointer ${
                      isLocked
                        ? 'bg-slate-100 border-slate-300 text-slate-500 hover:bg-amber-50 hover:text-amber-900'
                        : quizResult
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-800 hover:bg-emerald-100'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {isLocked ? <Lock size={13} className="mx-auto mb-0.5 text-slate-400" /> : <HelpCircle size={13} className="mx-auto mb-0.5" />}
                    <span>{isLocked ? 'Quiz 🔒' : quizResult ? `Quiz: ${quizResult.score}/${quizResult.total}` : 'Quiz'}</span>
                  </button>

                  {/* Debug Lab status */}
                  <button
                    onClick={() => {
                      if (isLocked) {
                        onRequireAuth(ch.number);
                      } else {
                        onOpenDebugLab(ch.number);
                      }
                    }}
                    className={`p-2 rounded-lg border font-bold transition-colors cursor-pointer ${
                      isLocked
                        ? 'bg-slate-100 border-slate-300 text-slate-500 hover:bg-amber-50 hover:text-amber-900'
                        : isDebugSolved
                        ? 'bg-purple-50 border-purple-300 text-purple-800 hover:bg-purple-100'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {isLocked ? <Lock size={13} className="mx-auto mb-0.5 text-slate-400" /> : <ShieldAlert size={13} className="mx-auto mb-0.5" />}
                    <span>{isLocked ? 'Debug 🔒' : isDebugSolved ? 'Debug Fixed' : 'Debug Lab'}</span>
                  </button>

                  {/* Guided Project status */}
                  <button
                    onClick={() => {
                      if (isLocked) {
                        onRequireAuth(ch.number);
                      } else {
                        onOpenProject(ch.number);
                      }
                    }}
                    className={`p-2 rounded-lg border font-bold transition-colors cursor-pointer ${
                      isLocked
                        ? 'bg-slate-100 border-slate-300 text-slate-500 hover:bg-amber-50 hover:text-amber-900'
                        : isProjectDone
                        ? 'bg-amber-50 border-amber-300 text-amber-800 hover:bg-amber-100'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {isLocked ? <Lock size={13} className="mx-auto mb-0.5 text-slate-400" /> : <Hammer size={13} className="mx-auto mb-0.5" />}
                    <span>{isLocked ? 'Project 🔒' : isProjectDone ? 'Project Done' : 'Project'}</span>
                  </button>
                </div>

                {/* Primary CTA */}
                {isLocked ? (
                  <button
                    onClick={() => {
                      soundFX.playPop();
                      onRequireAuth(ch.number);
                    }}
                    className="w-full comic-button py-2.5 bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 text-slate-950 font-comic font-black text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-sm border-2 border-slate-900"
                  >
                    <Lock size={14} className="text-slate-950" />
                    <span>Register Free to Unlock Chapter {ch.number}</span>
                    <ArrowRight size={14} />
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      soundFX.playPop();
                      onSelectChapter(ch.number);
                    }}
                    className="w-full comic-button py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-900 font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                  >
                    <BookOpen size={15} />
                    <span>Read Comic & Lessons</span>
                    <ArrowRight size={15} />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
