import React, { useState, useMemo } from 'react';
import { UserProgress } from '../types/curriculum';
import { ALL_ACHIEVEMENTS } from '../data/achievementsData';
import { ALL_CHAPTERS } from '../data/chapters';
import { PipCharacter, AlexCharacter, ByteCharacter, BugsyCharacter } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';
import { speechService } from '../utils/speechService';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  ReferenceLine
} from 'recharts';
import {
  Flame,
  Award,
  CheckCircle2,
  BookOpen,
  ShieldAlert,
  Hammer,
  RotateCcw,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Bookmark,
  Lock,
  Trophy,
  Star,
  Volume2,
  Square
} from 'lucide-react';

interface DashboardProps {
  progress: UserProgress;
  onResumeLastLesson: () => void;
  onSelectChapter: (chapterNumber: number) => void;
  onResetProgress: () => void;
  onOpenCertificate: () => void;
}

export const DashboardView: React.FC<DashboardProps> = ({
  progress,
  onResumeLastLesson,
  onSelectChapter,
  onResetProgress,
  onOpenCertificate
}) => {
  const [confirmReset, setConfirmReset] = useState<boolean>(false);
  const [badgeFilter, setBadgeFilter] = useState<'all' | 'unlocked' | 'milestones'>('all');
  const [isByteSpeaking, setIsByteSpeaking] = useState<boolean>(false);

  const speakByte = (text: string) => {
    if (isByteSpeaking) {
      speechService.stop();
      setIsByteSpeaking(false);
      return;
    }
    soundFX.playPop();
    setIsByteSpeaking(true);
    speechService.speak(
      text,
      'byte',
      'dashboard-byte',
      () => setIsByteSpeaking(true),
      () => setIsByteSpeaking(false),
      () => setIsByteSpeaking(false)
    );
  };

  const completedChapterCount = progress.completedChapters.length;
  const first5ChaptersCount = [1, 2, 3, 4, 5].filter((ch) =>
    progress.completedChapters.includes(ch)
  ).length;
  const totalChapters = 20;
  const chapterPercent = Math.round((completedChapterCount / totalChapters) * 100);

  const totalQuizzesTaken = Object.keys(progress.quizScores).length;
  const avgQuizScore =
    totalQuizzesTaken > 0
      ? Math.round(
          (Object.values(progress.quizScores).reduce(
            (acc, curr) => acc + (curr.score / curr.total) * 100,
            0
          ) /
            totalQuizzesTaken)
        )
      : 0;

  // Find last chapter object
  const lastChapter =
    ALL_CHAPTERS.find((c) => c.number === progress.lastVisitedChapter) || ALL_CHAPTERS[0];

  // 7-Day progress data for Recharts
  const sevenDayData = useMemo(() => {
    const dailyMap = progress.dailyLessonsCompleted || {};
    const totalCompleted = progress.completedLessons.length;
    const result = [];
    const now = new Date();

    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayLabel = d.toLocaleDateString('en-US', { weekday: 'short' });
      const monthDay = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      const isToday = i === 0;

      let count = dailyMap[dateStr] || 0;
      // If user has completed lessons but daily tracking started today, populate today with completed count
      if (count === 0 && totalCompleted > 0 && isToday) {
        count = totalCompleted;
      }

      result.push({
        dateStr,
        dayLabel,
        monthDay,
        lessons: count,
        isToday,
        goal: 2
      });
    }
    return result;
  }, [progress.dailyLessonsCompleted, progress.completedLessons.length]);

  const weeklyLessonSum = sevenDayData.reduce((acc, curr) => acc + curr.lessons, 0);

  const CustomChartTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="comic-panel p-3 bg-white border-2 border-slate-900 shadow-md text-xs">
          <div className="font-bold text-slate-900">
            {data.dayLabel} ({data.monthDay}) {data.isToday ? '• Today' : ''}
          </div>
          <div className="text-emerald-700 font-extrabold font-comic mt-1 text-sm">
            {data.lessons} {data.lessons === 1 ? 'Lesson' : 'Lessons'}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">
            {data.lessons >= data.goal
              ? '🎯 Daily Target Met!'
              : `${data.goal - data.lessons} more to hit daily target`}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-16">
      {/* 1. Welcome Hero & Quick Jump */}
      <div className="comic-panel p-6 sm:p-8 bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-200 border-slate-900 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold font-comic text-slate-800 uppercase tracking-widest">
            <span>Hero Headquarters</span>
            <span>•</span>
            <span className="flex items-center gap-1 text-orange-700">
              <Flame size={14} className="fill-orange-600" /> {progress.streakCount} Day Learning Streak
            </span>
          </div>
          <h1 className="font-comic text-3xl sm:text-4xl text-slate-900 mt-1">
            Welcome, {progress.userName}!
          </h1>
          <p className="text-xs sm:text-sm text-slate-700 font-medium mt-1 max-w-lg">
            Track your Python achievements, quiz performances, debugging cases, and mastered concepts.
          </p>

          <div className="mt-5 flex items-center gap-3">
            <button
              onClick={() => {
                soundFX.playPop();
                onResumeLastLesson();
              }}
              className="comic-button px-5 py-2.5 bg-[#1E293B] hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl flex items-center gap-2 shadow-md cursor-pointer"
            >
              <BookOpen size={15} />
              <span>Resume: Ch {lastChapter.number} ({lastChapter.title})</span>
              <ArrowRight size={14} />
            </button>

            {completedChapterCount >= 1 && (
              <button
                onClick={() => {
                  soundFX.playFanfare();
                  onOpenCertificate();
                }}
                className="comic-button px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-900 font-extrabold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Award size={15} className="text-amber-500" />
                <span>View Diploma</span>
              </button>
            )}
          </div>
        </div>

        <div className="flex items-end gap-2 bg-white/80 backdrop-blur-xs p-4 rounded-2xl border-2 border-slate-900 shadow-md self-start md:self-auto">
          <PipCharacter mood="happy" size={70} />
          <AlexCharacter mood="coding" size={70} />
        </div>
      </div>

      {/* 2. Key Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Chapters */}
        <div className="comic-panel p-5 bg-white border-slate-900">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between">
            <span>Chapters</span>
            <BookOpen size={16} className="text-amber-500" />
          </div>
          <div className="font-comic text-2xl sm:text-3xl text-slate-900 mt-2">
            {completedChapterCount} / {totalChapters}
          </div>
          <div className="text-[11px] font-bold text-emerald-600 mt-1">
            {chapterPercent}% of Course
          </div>
        </div>

        {/* Lessons Mastered */}
        <div className="comic-panel p-5 bg-white border-slate-900">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between">
            <span>Lessons</span>
            <CheckCircle2 size={16} className="text-emerald-500" />
          </div>
          <div className="font-comic text-2xl sm:text-3xl text-slate-900 mt-2">
            {progress.completedLessons.length}
          </div>
          <div className="text-[11px] font-bold text-slate-500 mt-1">Lessons Completed</div>
        </div>

        {/* Quizzes Average */}
        <div className="comic-panel p-5 bg-white border-slate-900">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between">
            <span>Quiz Mastery</span>
            <Award size={16} className="text-amber-500" />
          </div>
          <div className="font-comic text-2xl sm:text-3xl text-slate-900 mt-2">
            {avgQuizScore}%
          </div>
          <div className="text-[11px] font-bold text-slate-500 mt-1">
            Across {totalQuizzesTaken} Quizzes
          </div>
        </div>

        {/* Debugs Solved */}
        <div className="comic-panel p-5 bg-white border-slate-900">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between">
            <span>Bugs Solved</span>
            <ShieldAlert size={16} className="text-purple-500" />
          </div>
          <div className="font-comic text-2xl sm:text-3xl text-slate-900 mt-2">
            {progress.solvedDebugs.length}
          </div>
          <div className="text-[11px] font-bold text-purple-700 mt-1">Laboratory Puzzles</div>
        </div>
      </div>

      {/* 3. 7-Day Learning Activity Chart (Recharts) */}
      <div className="comic-panel p-6 sm:p-7 bg-white border-slate-900 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-comic uppercase tracking-wider text-amber-700">
              <TrendingUp size={15} /> 7-Day Consistency Tracker
            </div>
            <h2 className="font-comic text-xl text-slate-900 mt-0.5">
              Weekly Learning Velocity
            </h2>
            <p className="text-xs text-slate-600 mt-0.5">
              Number of lessons mastered each day over the past 7 days.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-2.5 px-3 bg-amber-50 rounded-xl border border-amber-300 text-center">
              <div className="text-[10px] font-bold text-amber-800 uppercase tracking-wider">
                Past 7 Days
              </div>
              <div className="font-comic text-lg text-slate-900">{weeklyLessonSum} Lessons</div>
            </div>
            <div className="p-2.5 px-3 bg-emerald-50 rounded-xl border border-emerald-300 text-center">
              <div className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">
                Daily Target
              </div>
              <div className="font-comic text-lg text-emerald-700">2 / day</div>
            </div>
          </div>
        </div>

        {/* Recharts BarChart */}
        <div className="w-full h-64 sm:h-72 pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={sevenDayData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
              <XAxis
                dataKey="dayLabel"
                stroke="#64748B"
                fontSize={12}
                fontWeight={700}
                tickLine={false}
              />
              <YAxis
                stroke="#64748B"
                fontSize={11}
                allowDecimals={false}
                tickLine={false}
                axisLine={false}
              />
              <Tooltip content={<CustomChartTooltip />} />
              <ReferenceLine
                y={2}
                stroke="#F59E0B"
                strokeDasharray="4 4"
                label={{ value: 'Target: 2', fill: '#D97706', fontSize: 10, position: 'insideTopRight' }}
              />
              <Bar dataKey="lessons" radius={[8, 8, 0, 0]} maxBarSize={48}>
                {sevenDayData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.isToday ? '#10B981' : entry.lessons > 0 ? '#F59E0B' : '#CBD5E1'}
                    stroke="#1E293B"
                    strokeWidth={2}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Byte Motivation Callout */}
        {(() => {
          const byteMessage =
            weeklyLessonSum >= 7
              ? "Incredible momentum! You are outpacing 95% of self-taught programmers this week. Keep that fire burning!"
              : weeklyLessonSum > 0
              ? "Every single lesson builds compounding knowledge! Finish one or two more lessons today to keep your streak glowing!"
              : "A journey of one thousand lines starts with one print statement! Jump into any chapter to light up your first bar today!";

          return (
            <div
              onClick={() => speakByte(byteMessage)}
              className={`p-3.5 rounded-xl border-2 border-slate-900 flex items-center justify-between gap-3 cursor-pointer transition-all ${
                isByteSpeaking
                  ? 'bg-gradient-to-r from-sky-100 via-amber-100 to-emerald-100 ring-4 ring-sky-300 border-sky-600 shadow-md'
                  : 'bg-gradient-to-r from-sky-50 via-amber-50 to-emerald-50 hover:border-sky-500'
              }`}
              title="Click to hear Byte speak his motivation protocol in Indian English"
            >
              <div className="flex items-center gap-3">
                <ByteCharacter mood="happy" size={52} isSpeaking={isByteSpeaking} className="shrink-0" />
                <div className="text-xs text-slate-800 leading-relaxed">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="font-comic font-black text-sky-900">BYTE'S MOTIVATION PROTOCOL:</span>
                    {isByteSpeaking && (
                      <span className="text-[10px] font-mono text-sky-800 bg-sky-200/80 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <span className="w-1 bg-sky-600 rounded-full animate-eq-1" />
                        <span className="w-1 bg-sky-600 rounded-full animate-eq-2" />
                        <span className="w-1 bg-sky-600 rounded-full animate-eq-3" />
                        Speaking 🇮🇳
                      </span>
                    )}
                  </div>
                  <span>{byteMessage}</span>
                </div>
              </div>

              <button
                className={`comic-button px-2.5 py-1.5 rounded-lg text-xs font-bold shrink-0 flex items-center gap-1 ${
                  isByteSpeaking ? 'bg-rose-500 text-white' : 'bg-sky-400 hover:bg-sky-300 text-slate-900'
                }`}
              >
                {isByteSpeaking ? <Square size={12} className="fill-white" /> : <Volume2 size={13} />}
                <span className="text-[11px] hidden sm:inline">{isByteSpeaking ? 'Stop' : 'Hear Byte 🇮🇳'}</span>
              </button>
            </div>
          );
        })()}
      </div>

      {/* 4. Badges & Milestones Section */}
      <div className="comic-panel p-6 sm:p-7 bg-white border-slate-900 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-comic uppercase tracking-wider text-amber-700">
              <Trophy size={16} className="text-amber-500" /> Hero Badges & Milestones
            </div>
            <h2 className="font-comic text-2xl text-slate-900 mt-0.5">
              Badges Collection
            </h2>
            <p className="text-xs text-slate-600 mt-0.5">
              Earn distinctive badges by maintaining streaks, conquering acts, and solving debugging puzzles.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-2.5 px-4 bg-amber-50 rounded-xl border border-amber-300 text-center">
              <div className="text-[10px] font-bold text-amber-800 uppercase tracking-wider">
                Badges Unlocked
              </div>
              <div className="font-comic text-lg text-slate-900">
                {progress.unlockedAchievements.length} / {ALL_ACHIEVEMENTS.length}
              </div>
            </div>
            <ByteCharacter mood="happy" size={48} className="shrink-0" />
          </div>
        </div>

        {/* Milestone Spotlight Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Milestone 1: 7 Day Streak */}
          {(() => {
            const isStreakUnlocked =
              progress.streakCount >= 7 || progress.unlockedAchievements.includes('seven_day_streak');
            const streakPercent = Math.min(Math.round((progress.streakCount / 7) * 100), 100);

            return (
              <div
                className={`comic-panel p-4.5 rounded-2xl border-2 transition-all flex flex-col justify-between ${
                  isStreakUnlocked
                    ? 'bg-gradient-to-br from-amber-50 via-orange-50 to-amber-100/60 border-amber-500 shadow-md'
                    : 'bg-slate-50 border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shrink-0 border-2 border-slate-900 shadow-sm ${
                        isStreakUnlocked
                          ? 'bg-gradient-to-tr from-orange-400 to-amber-300 animate-pulse'
                          : 'bg-slate-200 grayscale'
                      }`}
                    >
                      🔥
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-comic text-base text-slate-900">7 Day Streak</h4>
                        {isStreakUnlocked ? (
                          <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-400 flex items-center gap-1">
                            <CheckCircle2 size={11} /> Unlocked
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-slate-200 text-slate-600 flex items-center gap-1">
                            <Lock size={10} /> In Progress
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-600 mt-0.5">
                        Code for 7 consecutive days to build unbreakable programming habits.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="mt-4 pt-3 border-t border-slate-900/10 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-700">
                    <span>Streak Milestone</span>
                    <span>{progress.streakCount} of 7 Days ({streakPercent}%)</span>
                  </div>
                  <div className="w-full bg-slate-200 h-2.5 rounded-full border border-slate-900/30 overflow-hidden p-0.5">
                    <div
                      className="bg-gradient-to-r from-orange-500 to-amber-400 h-full rounded-full transition-all duration-500"
                      style={{ width: `${streakPercent}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Milestone 2: Completed First 5 Chapters */}
          {(() => {
            const isFirst5Unlocked =
              first5ChaptersCount === 5 || progress.unlockedAchievements.includes('first_5_chapters');
            const chaptersPercent = Math.round((first5ChaptersCount / 5) * 100);

            return (
              <div
                className={`comic-panel p-4.5 rounded-2xl border-2 transition-all flex flex-col justify-between ${
                  isFirst5Unlocked
                    ? 'bg-gradient-to-br from-amber-50 via-yellow-50 to-amber-100/60 border-amber-500 shadow-md'
                    : 'bg-slate-50 border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shrink-0 border-2 border-slate-900 shadow-sm ${
                        isFirst5Unlocked
                          ? 'bg-gradient-to-tr from-amber-400 to-yellow-300'
                          : 'bg-slate-200 grayscale'
                      }`}
                    >
                      🌟
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-comic text-base text-slate-900">Completed First 5 Chapters</h4>
                        {isFirst5Unlocked ? (
                          <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-400 flex items-center gap-1">
                            <CheckCircle2 size={11} /> Unlocked
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-slate-200 text-slate-600 flex items-center gap-1">
                            <Lock size={10} /> In Progress
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-600 mt-0.5">
                        Master Act 1: The First Spark (Chapters 1 through 5 fundamentals).
                      </p>
                    </div>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="mt-4 pt-3 border-t border-slate-900/10 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-700">
                    <span>Act 1 Milestone</span>
                    <span>{first5ChaptersCount} of 5 Chapters ({chaptersPercent}%)</span>
                  </div>
                  <div className="w-full bg-slate-200 h-2.5 rounded-full border border-slate-900/30 overflow-hidden p-0.5">
                    <div
                      className="bg-gradient-to-r from-amber-500 to-emerald-400 h-full rounded-full transition-all duration-500"
                      style={{ width: `${chaptersPercent}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })()}
        </div>

        {/* Filter Pills Bar */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-200">
          <button
            onClick={() => {
              soundFX.playPop();
              setBadgeFilter('all');
            }}
            className={`comic-button px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              badgeFilter === 'all'
                ? 'bg-[#1E293B] text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            All Badges ({ALL_ACHIEVEMENTS.length})
          </button>

          <button
            onClick={() => {
              soundFX.playPop();
              setBadgeFilter('unlocked');
            }}
            className={`comic-button px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
              badgeFilter === 'unlocked'
                ? 'bg-amber-400 text-slate-900 shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <Sparkles size={13} className="text-amber-600" />
            <span>Unlocked ({progress.unlockedAchievements.length})</span>
          </button>

          <button
            onClick={() => {
              soundFX.playPop();
              setBadgeFilter('milestones');
            }}
            className={`comic-button px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
              badgeFilter === 'milestones'
                ? 'bg-orange-500 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <Star size={13} />
            <span>Milestones</span>
          </button>
        </div>

        {/* Complete Badges Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
          {ALL_ACHIEVEMENTS.filter((badge) => {
            if (badgeFilter === 'unlocked') {
              return progress.unlockedAchievements.includes(badge.id);
            }
            if (badgeFilter === 'milestones') {
              return badge.category === 'milestone' || badge.category === 'hero';
            }
            return true;
          }).map((badge) => {
            const isUnlocked = progress.unlockedAchievements.includes(badge.id);
            return (
              <div
                key={badge.id}
                className={`p-3.5 rounded-xl border-2 transition-all flex items-start gap-3 relative ${
                  isUnlocked
                    ? 'bg-gradient-to-br from-amber-50 to-amber-100/50 border-amber-400 text-slate-900 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-500 opacity-70'
                }`}
              >
                {/* Badge Icon with Unlocked/Locked Badge */}
                <div className="relative shrink-0">
                  <div
                    className={`w-11 h-11 rounded-xl flex items-center justify-center text-2xl border border-slate-900 shadow-xs ${
                      isUnlocked
                        ? 'bg-gradient-to-tr from-amber-400 to-yellow-300'
                        : 'bg-slate-200 grayscale opacity-80'
                    }`}
                  >
                    {badge.icon}
                  </div>
                  {!isUnlocked && (
                    <div className="absolute -bottom-1 -right-1 bg-slate-700 text-white p-0.5 rounded-full">
                      <Lock size={10} />
                    </div>
                  )}
                </div>

                <div className="space-y-0.5 flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-bold text-xs truncate text-slate-900">
                      {badge.title}
                    </span>
                    {isUnlocked && (
                      <span className="text-[9px] font-black uppercase tracking-wider text-emerald-800 bg-emerald-100 px-1.5 py-0.2 rounded shrink-0 flex items-center gap-0.5">
                        <CheckCircle2 size={10} /> Earned
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] leading-snug text-slate-600 line-clamp-2">
                    {badge.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Bookmarks & Revision Checklist */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bookmarks */}
        <div className="comic-panel p-5 bg-white border-slate-900">
          <h3 className="font-comic text-sm uppercase tracking-wider text-slate-900 mb-3 flex items-center gap-2">
            <Bookmark size={16} className="text-amber-500" /> Bookmarked Lessons (
            {progress.bookmarks.length})
          </h3>
          {progress.bookmarks.length === 0 ? (
            <p className="text-xs text-slate-500 italic p-4 text-center">
              No bookmarks yet! Click the bookmark ribbon icon on any lesson to save it here for fast revision.
            </p>
          ) : (
            <div className="space-y-2">
              {progress.bookmarks.map((bmId) => (
                <div
                  key={bmId}
                  className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between text-xs font-bold text-slate-800"
                >
                  <span>Lesson ID: {bmId}</span>
                  <button
                    onClick={() => {
                      const match = bmId.match(/ch(\d+)/);
                      if (match) onSelectChapter(parseInt(match[1], 10));
                    }}
                    className="text-amber-700 hover:text-amber-900 text-xs font-bold"
                  >
                    Open
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick Revision Concepts */}
        <div className="comic-panel p-5 bg-white border-slate-900">
          <h3 className="font-comic text-sm uppercase tracking-wider text-slate-900 mb-3 flex items-center gap-2">
            <Sparkles size={16} className="text-emerald-500" /> Core Python Syntax Cheat Sheet
          </h3>
          <div className="space-y-2 text-xs">
            <div className="p-2 bg-slate-50 rounded border border-slate-200 font-mono text-slate-800">
              <span className="text-amber-700 font-bold">print()</span> & <span className="text-amber-700 font-bold">{'f"Hello {name}"'}</span>: Output and formatted text
            </div>
            <div className="p-2 bg-slate-50 rounded border border-slate-200 font-mono text-slate-800">
              <span className="text-amber-700 font-bold">if / elif / else:</span>: Conditional decision branches (use == for equality)
            </div>
            <div className="p-2 bg-slate-50 rounded border border-slate-200 font-mono text-slate-800">
              <span className="text-amber-700 font-bold">for i in range(n):</span>: Definite loops and item iteration
            </div>
            <div className="p-2 bg-slate-50 rounded border border-slate-200 font-mono text-slate-800">
              <span className="text-amber-700 font-bold">def fn(arg): return</span>: Modular reusable functions
            </div>
          </div>
        </div>
      </div>

      {/* 5. Danger Zone: Reset Progress */}
      <div className="comic-panel p-5 bg-rose-50/50 border-rose-300 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h4 className="font-bold text-xs text-rose-900 uppercase tracking-wider">
            Reset Progress
          </h4>
          <p className="text-xs text-rose-700 mt-0.5">
            Clear all saved lessons, quiz scores, and achievements from this browser session.
          </p>
        </div>

        {!confirmReset ? (
          <button
            onClick={() => setConfirmReset(true)}
            className="comic-button px-4 py-2 bg-white hover:bg-rose-100 text-rose-700 border-rose-400 text-xs font-bold rounded-xl"
          >
            Reset Progress
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onResetProgress();
                setConfirmReset(false);
              }}
              className="comic-button px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl"
            >
              Confirm Reset
            </button>
            <button
              onClick={() => setConfirmReset(false)}
              className="text-xs text-slate-600 hover:text-slate-900 px-2"
            >
              Cancel
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
