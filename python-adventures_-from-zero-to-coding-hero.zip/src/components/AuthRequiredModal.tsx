import React from 'react';
import { PipCharacter, AlexCharacter } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';
import {
  Lock,
  Sparkles,
  ArrowRight,
  UserPlus,
  LogIn,
  CheckCircle2,
  X,
  BookOpen,
  Award
} from 'lucide-react';

interface AuthRequiredModalProps {
  targetChapter: number;
  chapterTitle?: string;
  onClose: () => void;
  onGoToRegister: () => void;
  onGoToLogin: () => void;
}

export const AuthRequiredModal: React.FC<AuthRequiredModalProps> = ({
  targetChapter,
  chapterTitle,
  onClose,
  onGoToRegister,
  onGoToLogin
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-fadeIn">
      <div className="comic-panel bg-white border-4 border-slate-900 shadow-2xl rounded-3xl max-w-lg w-full overflow-hidden animate-scaleUp">
        {/* Top Header Banner */}
        <div className="bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-200 p-5 border-b-4 border-slate-900 flex items-center justify-between text-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-slate-900 text-amber-300 rounded-xl flex items-center justify-center shadow-md border border-slate-900">
              <Lock size={20} className="text-amber-400" />
            </div>
            <div>
              <div className="text-[10px] font-comic font-black uppercase tracking-wider text-slate-900 flex items-center gap-1">
                <Sparkles size={12} className="text-amber-700" />
                <span>Chapter {targetChapter} is Locked</span>
              </div>
              <h3 className="font-comic text-lg sm:text-xl text-slate-950 leading-tight">
                {chapterTitle || `Chapter ${targetChapter}`}
              </h3>
            </div>
          </div>

          <button
            onClick={() => {
              soundFX.playPop();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-slate-900 text-white hover:bg-slate-800 transition-colors cursor-pointer border border-slate-900"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5">
          {/* Character Callout */}
          <div className="flex items-center gap-3 p-3.5 bg-amber-50 rounded-2xl border-2 border-slate-900">
            <div className="shrink-0">
              <PipCharacter mood="happy" size={48} />
            </div>
            <div className="text-xs text-slate-800 font-medium leading-relaxed">
              <span className="font-bold text-amber-950 font-comic">Pip says: </span>
              "Chapter 1 is our 100% free gift to the world! To unlock Chapter {targetChapter} and the remaining 19 chapters, create your free student account."
            </div>
          </div>

          {/* Value Props Checklist */}
          <div className="space-y-2 text-xs text-slate-700">
            <div className="font-comic font-black text-slate-900 uppercase tracking-wide text-[11px]">
              What You Unlock With Free Registration:
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200">
                <CheckCircle2 size={15} className="text-emerald-600 shrink-0" />
                <span>All 20 Chapters Unlocked</span>
              </div>
              <div className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200">
                <CheckCircle2 size={15} className="text-emerald-600 shrink-0" />
                <span>Save Code & Progress</span>
              </div>
              <div className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200">
                <CheckCircle2 size={15} className="text-emerald-600 shrink-0" />
                <span>Quizzes & Debug Labs</span>
              </div>
              <div className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200">
                <CheckCircle2 size={15} className="text-emerald-600 shrink-0" />
                <span>Graduation Diploma</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2.5 pt-2">
            <button
              onClick={() => {
                soundFX.playFanfare();
                onGoToRegister();
              }}
              className="w-full comic-button py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-comic font-black text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 shadow-md cursor-pointer border-2 border-slate-900"
            >
              <UserPlus size={16} />
              <span>Create Free Account (10 Seconds)</span>
              <ArrowRight size={16} />
            </button>

            <div className="flex items-center justify-between gap-2 pt-1">
              <button
                onClick={() => {
                  soundFX.playPop();
                  onGoToLogin();
                }}
                className="text-xs font-bold text-slate-600 hover:text-slate-900 underline flex items-center gap-1 cursor-pointer"
              >
                <LogIn size={13} />
                <span>Already have an account? Sign In</span>
              </button>

              <button
                onClick={() => {
                  soundFX.playPop();
                  onClose();
                }}
                className="text-xs font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                Stay on Chapter 1
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
