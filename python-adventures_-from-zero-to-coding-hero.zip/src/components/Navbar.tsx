import React, { useState } from 'react';
import { PipCharacter } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';
import {
  Compass,
  Map,
  BookOpen,
  Terminal,
  Award,
  Printer,
  Volume2,
  VolumeX,
  Flame,
  Menu,
  X,
  Sparkles,
  ShieldCheck,
  LogIn,
  LogOut,
  User
} from 'lucide-react';

import { UserAccount } from '../types/auth';

export type NavTab =
  | 'landing'
  | 'chapter_map'
  | 'comic_reader'
  | 'lesson_detail'
  | 'dashboard'
  | 'print_view';

interface NavbarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenPlayground: () => void;
  onOpenCertificate: () => void;
  onOpenBranchingAdventure: () => void;
  streakCount: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  currentChapterNumber: number;
  currentUser: UserAccount | null;
  onOpenAdminConsole: () => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onSelectTab,
  onOpenPlayground,
  onOpenCertificate,
  onOpenBranchingAdventure,
  streakCount,
  soundEnabled,
  onToggleSound,
  currentChapterNumber,
  currentUser,
  onOpenAdminConsole,
  onLogout
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  const handleTab = (tab: NavTab) => {
    soundFX.playPop();
    onSelectTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="no-print sticky top-0 z-40 bg-[#1E293B] text-white border-b-4 border-amber-400 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand Lockup */}
        <button
          onClick={() => handleTab('landing')}
          className="flex items-center gap-3 text-left cursor-pointer group"
        >
          <div className="bg-amber-400 p-1 rounded-xl border border-slate-900 group-hover:scale-105 transition-transform shrink-0">
            <PipCharacter mood="happy" size={32} />
          </div>
          <div>
            <div className="font-comic text-base sm:text-lg tracking-wide text-white flex items-center gap-1.5">
              <span>PYTHON ADVENTURES</span>
            </div>
            <div className="text-[10px] text-amber-300 font-mono -mt-0.5 hidden sm:block">
              From Zero to Coding Hero
            </div>
          </div>
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 text-xs font-bold">
          <button
            onClick={() => handleTab('chapter_map')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'chapter_map'
                ? 'bg-amber-400 text-slate-900 shadow-xs'
                : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Map size={14} />
            <span>Map (20 Ch)</span>
          </button>

          <button
            onClick={() => handleTab('comic_reader')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'comic_reader' || activeTab === 'lesson_detail'
                ? 'bg-amber-400 text-slate-900 shadow-xs'
                : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <BookOpen size={14} />
            <span>Ch {currentChapterNumber}</span>
          </button>

          <button
            onClick={() => {
              soundFX.playPop();
              onOpenPlayground();
            }}
            className="px-3 py-1.5 rounded-lg text-emerald-400 hover:bg-slate-800 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Terminal size={14} />
            <span>Playground</span>
          </button>

          <button
            onClick={() => {
              soundFX.playPop();
              onOpenBranchingAdventure();
            }}
            className="px-3 py-1.5 rounded-lg text-amber-300 hover:bg-slate-800 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Compass size={14} />
            <span>RPG Adventure</span>
          </button>

          <button
            onClick={() => handleTab('dashboard')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'dashboard'
                ? 'bg-amber-400 text-slate-900 shadow-xs'
                : 'text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Award size={14} />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => handleTab('print_view')}
            className="px-3 py-1.5 rounded-lg text-slate-300 hover:bg-slate-800 flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Open print-ready edition"
          >
            <Printer size={14} />
            <span>Print View</span>
          </button>
        </nav>

        {/* Right Utility Cluster: Admin Badge, Streak, Sound, Diploma, User Profile */}
        <div className="flex items-center gap-2">
          {/* Admin Access Badge & Console Trigger (if admin) */}
          {currentUser?.role === 'admin' && (
            <button
              onClick={() => {
                soundFX.playFanfare();
                onOpenAdminConsole();
              }}
              className="comic-button px-2.5 sm:px-3 py-1.5 bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 text-slate-950 font-black text-xs rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs border border-slate-900"
              title="Open Admin Management Console"
            >
              <ShieldCheck size={14} className="text-slate-950" />
              <span className="hidden sm:inline">Admin Console</span>
              <span className="sm:hidden">Admin</span>
            </button>
          )}

          {/* Learning Streak Pill */}
          <div
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800 border border-slate-700 text-xs font-bold text-amber-300"
            title="Consecutive learning days"
          >
            <Flame size={14} className="fill-orange-500 text-orange-500" />
            <span>{streakCount}d</span>
          </div>

          {/* Sound Toggle Button */}
          <button
            onClick={onToggleSound}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
            title={soundEnabled ? 'Mute sound effects' : 'Enable sound effects'}
            aria-label="Toggle sound effects"
          >
            {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>

          {/* Diploma Trigger */}
          <button
            onClick={() => {
              soundFX.playFanfare();
              onOpenCertificate();
            }}
            className="hidden md:flex comic-button px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-900 font-extrabold text-xs rounded-lg items-center gap-1 cursor-pointer shadow-xs"
          >
            <Sparkles size={13} />
            <span>Diploma</span>
          </button>

          {/* User Profile Pill or Homepage Login Trigger */}
          {currentUser ? (
            <div className="hidden sm:flex items-center gap-1.5 pl-1.5 py-1 pr-2 rounded-lg bg-slate-800 border border-slate-700 text-xs">
              <span className="w-6 h-6 rounded-md bg-amber-400 text-slate-950 flex items-center justify-center font-bold text-[11px]">
                {currentUser.name.charAt(0).toUpperCase()}
              </span>
              <span className="font-bold text-slate-200 max-w-[90px] truncate" title={currentUser.name}>
                {currentUser.name.split(' ')[0]}
              </span>
              <button
                onClick={() => {
                  soundFX.playPop();
                  onLogout();
                }}
                className="text-slate-400 hover:text-rose-400 p-0.5 ml-0.5 cursor-pointer"
                title="Log Out"
              >
                <LogOut size={13} />
              </button>
            </div>
          ) : (
            <button
              onClick={() => handleTab('landing')}
              className="hidden sm:flex px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs items-center gap-1 cursor-pointer border border-slate-700"
              title="Sign In / Register on Homepage"
            >
              <LogIn size={13} />
              <span>Sign In</span>
            </button>
          )}

          {/* Mobile Menu Hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg bg-slate-800 text-slate-200"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0F172A] border-t border-slate-700 px-4 py-4 space-y-2 text-sm font-bold animate-in slide-in-from-top-2">
          <button
            onClick={() => handleTab('landing')}
            className="w-full text-left p-2.5 rounded-lg hover:bg-slate-800 text-slate-200"
          >
            Home & Overview
          </button>
          <button
            onClick={() => handleTab('chapter_map')}
            className="w-full text-left p-2.5 rounded-lg hover:bg-slate-800 text-slate-200 flex items-center justify-between"
          >
            <span>Curriculum Map (All 20 Chapters)</span>
            <Map size={16} />
          </button>
          <button
            onClick={() => handleTab('comic_reader')}
            className="w-full text-left p-2.5 rounded-lg hover:bg-slate-800 text-slate-200 flex items-center justify-between"
          >
            <span>Read Comic & Lessons (Ch {currentChapterNumber})</span>
            <BookOpen size={16} />
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenPlayground();
            }}
            className="w-full text-left p-2.5 rounded-lg hover:bg-slate-800 text-emerald-400 flex items-center justify-between"
          >
            <span>Live Python Playground</span>
            <Terminal size={16} />
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenBranchingAdventure();
            }}
            className="w-full text-left p-2.5 rounded-lg hover:bg-slate-800 text-amber-300 flex items-center justify-between"
          >
            <span>Branching RPG Adventure</span>
            <Compass size={16} />
          </button>
          <button
            onClick={() => handleTab('dashboard')}
            className="w-full text-left p-2.5 rounded-lg hover:bg-slate-800 text-slate-200 flex items-center justify-between"
          >
            <span>My Progress & Achievements</span>
            <Award size={16} />
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenCertificate();
            }}
            className="w-full text-left p-2.5 rounded-lg hover:bg-slate-800 text-amber-400 flex items-center justify-between"
          >
            <span>Graduation Certificate</span>
            <Sparkles size={16} />
          </button>
          {currentUser?.role === 'admin' && (
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAdminConsole();
              }}
              className="w-full text-left p-2.5 rounded-lg bg-amber-400 text-slate-950 font-black flex items-center justify-between"
            >
              <span>🛡️ Admin Management Console</span>
              <ShieldCheck size={16} />
            </button>
          )}

          {currentUser ? (
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onLogout();
              }}
              className="w-full text-left p-2.5 rounded-lg hover:bg-rose-900/40 text-rose-300 flex items-center justify-between"
            >
              <span>Sign Out ({currentUser.name})</span>
              <LogOut size={16} />
            </button>
          ) : (
            <button
              onClick={() => handleTab('landing')}
              className="w-full text-left p-2.5 rounded-lg bg-slate-800 text-amber-300 flex items-center justify-between"
            >
              <span>Sign In / Register (on Homepage)</span>
              <LogIn size={16} />
            </button>
          )}
        </div>
      )}
    </header>
  );
};
