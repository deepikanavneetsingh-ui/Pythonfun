import React, { useState } from 'react';
import { Award, Printer, X, CheckCircle2, Sparkles } from 'lucide-react';
import { PipCharacter } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';

interface CertificateModalProps {
  userName: string;
  onUpdateUserName: (name: string) => void;
  onClose: () => void;
  chaptersCompletedCount: number;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({
  userName,
  onUpdateUserName,
  onClose,
  chaptersCompletedCount
}) => {
  const [name, setName] = useState<string>(userName || 'Python Adventurer');
  const [isEditing, setIsEditing] = useState<boolean>(false);

  const issueDate = new Intl.DateTimeFormat('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  }).format(new Date());

  const handlePrint = () => {
    soundFX.playPop();
    window.print();
  };

  const saveName = () => {
    setIsEditing(false);
    onUpdateUserName(name);
    soundFX.playPop();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in">
      <div className="w-full max-w-4xl max-h-[95vh] comic-panel shadow-2xl flex flex-col bg-white overflow-hidden">
        {/* Modal Controls Bar (Hidden during print) */}
        <div className="no-print bg-[#1E293B] text-white px-5 py-3 flex items-center justify-between border-b-4 border-amber-400">
          <div className="flex items-center gap-2">
            <Award size={20} className="text-amber-400" />
            <span className="font-comic text-sm tracking-wide">
              Official Python Hero Diploma & Certificate
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="comic-button px-4 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-900 font-extrabold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Printer size={14} /> Print / Save PDF
            </button>
            <button
              onClick={() => {
                soundFX.playPop();
                onClose();
              }}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Certificate Display Area */}
        <div className="p-6 sm:p-10 overflow-y-auto flex items-center justify-center bg-[#FFFDF9]">
          <div className="w-full max-w-3xl border-8 border-double border-amber-800 p-8 sm:p-12 rounded-3xl bg-[#FFFDF7] shadow-xl text-center relative overflow-hidden">
            {/* Corner Filigrees */}
            <div className="absolute top-3 left-3 text-amber-700 font-serif text-2xl select-none">
              ❖
            </div>
            <div className="absolute top-3 right-3 text-amber-700 font-serif text-2xl select-none">
              ❖
            </div>
            <div className="absolute bottom-3 left-3 text-amber-700 font-serif text-2xl select-none">
              ❖
            </div>
            <div className="absolute bottom-3 right-3 text-amber-700 font-serif text-2xl select-none">
              ❖
            </div>

            {/* Top Emblem */}
            <div className="flex items-center justify-center gap-3 mb-4">
              <PipCharacter mood="happy" size={54} />
              <div className="text-amber-600 font-comic uppercase tracking-widest text-xs font-bold">
                Python Adventures Academy
              </div>
            </div>

            <h1 className="font-comic text-3xl sm:text-4xl text-slate-900 tracking-wide uppercase">
              Certificate of Mastery
            </h1>
            <p className="font-serif italic text-sm text-slate-600 mt-1">
              This official diploma is proudly conferred upon:
            </p>

            {/* Recipient Name (Editable on click) */}
            <div className="my-5">
              {!isEditing ? (
                <div
                  onClick={() => setIsEditing(true)}
                  className="font-comic text-2xl sm:text-3xl text-amber-900 underline decoration-amber-400 decoration-wavy cursor-pointer hover:text-amber-700 transition-colors inline-block"
                  title="Click to change your name"
                >
                  {name}
                </div>
              ) : (
                <div className="flex items-center justify-center gap-2 max-w-sm mx-auto">
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="border-2 border-amber-500 rounded-lg px-3 py-1 text-center font-comic text-xl text-slate-900 w-full focus:outline-none"
                    autoFocus
                  />
                  <button
                    onClick={saveName}
                    className="px-3 py-1 bg-amber-500 text-white font-bold rounded-lg text-xs"
                  >
                    Save
                  </button>
                </div>
              )}
            </div>

            <p className="text-xs sm:text-sm text-slate-700 max-w-xl mx-auto leading-relaxed">
              For demonstrating exceptional curiosity, computational problem-solving, and successfully
              conquering programming fundamentals including variables, logic, loops, collections,
              modular functions, error debugging, and practical applications.
            </p>

            {/* Competency Badges List */}
            <div className="my-6 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-bold text-slate-800">
              <div className="p-2 bg-amber-100/60 rounded-lg border border-amber-300 flex items-center justify-center gap-1">
                <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                <span>Syntax & Variables</span>
              </div>
              <div className="p-2 bg-amber-100/60 rounded-lg border border-amber-300 flex items-center justify-center gap-1">
                <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                <span>Conditionals & Logic</span>
              </div>
              <div className="p-2 bg-amber-100/60 rounded-lg border border-amber-300 flex items-center justify-center gap-1">
                <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                <span>Loops & Lists</span>
              </div>
              <div className="p-2 bg-amber-100/60 rounded-lg border border-amber-300 flex items-center justify-center gap-1">
                <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                <span>Functions & OOP</span>
              </div>
            </div>

            {/* Seal & Signatures */}
            <div className="mt-8 pt-6 border-t-2 border-amber-200 flex items-end justify-between px-2 sm:px-6">
              <div className="text-left space-y-1">
                <div className="font-comic text-xs text-slate-800">Pip the Python</div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider">
                  Lead Educational Mascot
                </div>
                <div className="text-[11px] font-mono text-slate-700">{issueDate}</div>
              </div>

              {/* Gold Ribbon Seal */}
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-tr from-amber-600 to-amber-300 p-1 flex items-center justify-center border-2 border-slate-900 shadow-md">
                <div className="w-full h-full rounded-full border border-amber-800 flex flex-col items-center justify-center text-slate-900 font-comic text-[9px] sm:text-[10px] uppercase leading-tight font-black">
                  <span>★ GOLD ★</span>
                  <span>VERIFIED</span>
                </div>
              </div>

              <div className="text-right space-y-1">
                <div className="font-comic text-xs text-slate-800">Byte & Bugsy</div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider">
                  Quality & Logic Inspection
                </div>
                <div className="text-[11px] font-mono text-emerald-700 font-bold">
                  PASS: 100% Verified
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
