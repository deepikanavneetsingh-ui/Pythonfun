import React, { useState } from 'react';
import { UserAccount } from '../types/auth';
import { authService, DEFAULT_ADMIN } from '../services/authService';
import { PipCharacter, AlexCharacter, ByteCharacter, BugsyCharacter } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';
import { speechService } from '../utils/speechService';
import {
  ShieldCheck,
  UserCheck,
  LogIn,
  UserPlus,
  KeyRound,
  Mail,
  User,
  Sparkles,
  LogOut,
  AlertCircle,
  CheckCircle2,
  Lock,
  Volume2,
  ExternalLink,
  BookOpen,
  Settings
} from 'lucide-react';

interface AuthWindowProps {
  currentUser: UserAccount | null;
  onLoginSuccess: (user: UserAccount) => void;
  onLogout: () => void;
  onOpenAdminConsole: () => void;
  onStartAdventure: () => void;
}

export const AuthWindow: React.FC<AuthWindowProps> = ({
  currentUser,
  onLoginSuccess,
  onLogout,
  onOpenAdminConsole,
  onStartAdventure
}) => {
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Login form state
  const [loginEmail, setLoginEmail] = useState<string>('');
  const [loginPassword, setLoginPassword] = useState<string>('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginSuccessMsg, setLoginSuccessMsg] = useState<string | null>(null);

  // Register form state
  const [regName, setRegName] = useState<string>('');
  const [regEmail, setRegEmail] = useState<string>('');
  const [regPassword, setRegPassword] = useState<string>('');
  const [regConfirmPassword, setRegConfirmPassword] = useState<string>('');
  const [regGrade, setRegGrade] = useState<string>('Middle School (Grade 6-8)');
  const [regAvatar, setRegAvatar] = useState<'pip' | 'alex' | 'byte' | 'bugsy'>('alex');
  const [regError, setRegError] = useState<string | null>(null);
  const [regSuccessMsg, setRegSuccessMsg] = useState<string | null>(null);

  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  // Fill in Admin Credentials for testing
  const handleQuickFillAdmin = () => {
    soundFX.playPop();
    setAuthMode('login');
    setLoginEmail(DEFAULT_ADMIN.email);
    setLoginPassword(DEFAULT_ADMIN.password);
    setLoginError(null);
  };

  const handleSpeakGreeting = () => {
    if (isSpeaking) {
      speechService.stop();
      setIsSpeaking(false);
      return;
    }
    soundFX.playPop();
    setIsSpeaking(true);

    const message = currentUser
      ? currentUser.role === 'admin'
        ? `Welcome Administrator Deepika! You have master access to inspect students and oversee curriculum progression.`
        : `Welcome back ${currentUser.name}! Your Python journey continues. Click start adventure to begin coding!`
      : `Welcome to Python Adventures! Sign in with your account or create a new student account to save your 20-chapter progress. Admin access is also pre-configured!`;

    speechService.speak(
      message,
      'pip',
      'auth-announcement',
      () => setIsSpeaking(true),
      () => setIsSpeaking(false),
      () => setIsSpeaking(false)
    );
  };

  // Submit Login
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoginSuccessMsg(null);

    const result = authService.login(loginEmail, loginPassword);
    if (!result.success || !result.user) {
      soundFX.playError();
      setLoginError(result.error || 'Failed to log in. Please check your credentials.');
      return;
    }

    soundFX.playFanfare();
    setLoginSuccessMsg(`Welcome, ${result.user.name}!`);
    setTimeout(() => {
      onLoginSuccess(result.user!);
    }, 400);
  };

  // Submit Registration
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);
    setRegSuccessMsg(null);

    if (regPassword !== regConfirmPassword) {
      soundFX.playError();
      setRegError('Passwords do not match. Please ensure both passwords match.');
      return;
    }

    const result = authService.register({
      name: regName,
      email: regEmail,
      password: regPassword,
      avatarCharacter: regAvatar,
      gradeOrLevel: regGrade
    });

    if (!result.success || !result.user) {
      soundFX.playError();
      setRegError(result.error || 'Registration failed.');
      return;
    }

    soundFX.playFanfare();
    setRegSuccessMsg(`Account created successfully! Welcome to the adventure, ${result.user.name}!`);
    setTimeout(() => {
      onLoginSuccess(result.user!);
    }, 400);
  };

  // RENDER: If user is logged in
  if (currentUser) {
    const isAdmin = currentUser.role === 'admin';

    return (
      <div className="comic-panel bg-white border-4 border-slate-900 shadow-2xl p-6 sm:p-8 relative overflow-hidden">
        {/* Decorative background grid */}
        <div
          className="absolute inset-0 opacity-5 pointer-events-none"
          style={{
            backgroundImage: 'radial-gradient(#1E293B 1.5px, transparent 1.5px)',
            backgroundSize: '20px 20px'
          }}
        />

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Left Avatar & Identity */}
          <div className="flex items-center gap-4 text-center sm:text-left">
            <div className={`p-3 rounded-2xl border-2 border-slate-900 shadow-md ${
              isAdmin ? 'bg-amber-100 ring-4 ring-amber-400' : 'bg-emerald-100'
            }`}>
              {currentUser.avatarCharacter === 'pip' ? (
                <PipCharacter mood="happy" size={54} />
              ) : currentUser.avatarCharacter === 'byte' ? (
                <ByteCharacter mood="happy" size={54} />
              ) : currentUser.avatarCharacter === 'bugsy' ? (
                <BugsyCharacter mood="happy" size={54} />
              ) : (
                <AlexCharacter mood="coding" size={54} />
              )}
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-comic font-black tracking-wider uppercase border ${
                  isAdmin
                    ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-xs'
                    : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                }`}>
                  {isAdmin ? <ShieldCheck size={13} className="text-slate-950" /> : <UserCheck size={13} />}
                  <span>{isAdmin ? '🛡️ Administrator' : '🎓 Enrolled Student'}</span>
                </span>
                <button
                  onClick={handleSpeakGreeting}
                  className="p-1 rounded-full text-slate-500 hover:text-amber-600 transition-colors cursor-pointer"
                  title="Pip Audio Greeting"
                >
                  <Volume2 size={16} />
                </button>
              </div>

              <h3 className="font-comic text-xl text-slate-900">
                {currentUser.name}
              </h3>
              <div className="text-xs text-slate-500 font-mono">
                {currentUser.email}
              </div>
            </div>
          </div>

          {/* Right Action Cluster */}
          <div className="flex flex-wrap items-center justify-center gap-3">
            {isAdmin && (
              <button
                onClick={() => {
                  soundFX.playPop();
                  onOpenAdminConsole();
                }}
                className="comic-button px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-extrabold text-xs sm:text-sm rounded-xl flex items-center gap-2 shadow-md cursor-pointer border-2 border-slate-900"
              >
                <Settings size={16} />
                <span>Admin Console</span>
              </button>
            )}

            <button
              onClick={() => {
                soundFX.playPop();
                onStartAdventure();
              }}
              className="comic-button px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs sm:text-sm rounded-xl flex items-center gap-2 shadow-md cursor-pointer"
            >
              <BookOpen size={16} />
              <span>Continue Learning</span>
            </button>

            <button
              onClick={() => {
                soundFX.playPop();
                authService.logout();
                onLogout();
              }}
              className="px-4 py-2.5 rounded-xl border-2 border-slate-300 hover:border-rose-400 hover:bg-rose-50 text-slate-700 hover:text-rose-700 font-bold text-xs sm:text-sm flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <LogOut size={15} />
              <span>Sign Out</span>
            </button>
          </div>
        </div>

        {/* Admin Quick Helper Banner if Admin */}
        {isAdmin && (
          <div className="mt-4 pt-4 border-t-2 border-amber-200/60 flex flex-wrap items-center justify-between text-xs text-slate-600 gap-2">
            <span className="flex items-center gap-1.5 font-medium text-amber-900">
              <Sparkles size={14} className="text-amber-500" />
              Full administrative privileges granted for <strong>deepikanavneetsingh@gmail.com</strong>
            </span>
            <span className="font-mono text-[11px] bg-amber-50 px-2 py-0.5 rounded border border-amber-300 text-amber-800">
              Role: System Administrator • Access: Unrestricted
            </span>
          </div>
        )}
      </div>
    );
  }

  // RENDER: When NOT logged in (Login & Register Window visible on homepage)
  return (
    <div className="comic-panel bg-white border-4 border-slate-900 shadow-2xl p-6 sm:p-8 relative">
      {/* Top Header & Speech Pill */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b-2 border-slate-100">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 border border-amber-300 text-xs font-comic text-amber-900 font-bold">
            <Sparkles size={14} className="text-amber-600" />
            <span>Learner Portal & Admin Gateway</span>
          </div>
          <h2 className="font-comic text-2xl sm:text-3xl text-slate-900">
            {authMode === 'login' ? 'Welcome Back, Hero!' : 'Join the Python Adventure!'}
          </h2>
          <p className="text-xs text-slate-500">
            {authMode === 'login'
              ? 'Log in to sync your chapter badges, code playground history, and certificates.'
              : 'Create your free learner account to track progress across all 20 interactive chapters.'}
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center p-1 bg-slate-100 rounded-xl border-2 border-slate-900 shrink-0 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => {
              soundFX.playPop();
              setAuthMode('login');
              setLoginError(null);
            }}
            className={`px-4 py-2 rounded-lg text-xs font-comic font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              authMode === 'login'
                ? 'bg-amber-400 text-slate-950 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <LogIn size={14} />
            <span>Sign In</span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundFX.playPop();
              setAuthMode('register');
              setRegError(null);
            }}
            className={`px-4 py-2 rounded-lg text-xs font-comic font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              authMode === 'register'
                ? 'bg-amber-400 text-slate-950 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserPlus size={14} />
            <span>Create Account</span>
          </button>
        </div>
      </div>

      {/* Admin Fast-Fill Callout Bar */}
      <div className="mt-4 p-3.5 bg-gradient-to-r from-amber-50 to-yellow-50 rounded-xl border-2 border-amber-400/80 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-2.5 text-xs text-slate-800">
          <div className="w-7 h-7 rounded-lg bg-amber-400 flex items-center justify-center text-slate-900 font-bold shrink-0">
            🛡️
          </div>
          <div>
            <div className="font-comic font-black text-amber-950 uppercase tracking-wide text-[11px]">
              Pre-Configured Administrator Credentials
            </div>
            <div className="text-[11px] text-slate-600">
              Email: <code className="font-mono font-bold text-slate-900 bg-white/70 px-1 py-0.5 rounded border border-amber-300">deepikanavneetsingh@gmail.com</code> | Password: <code className="font-mono font-bold text-slate-900 bg-white/70 px-1 py-0.5 rounded border border-amber-300">India@1234</code>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={handleQuickFillAdmin}
          className="shrink-0 comic-button px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-900 font-extrabold text-[11px] rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs border border-slate-900"
          title="Click to auto-fill Admin credentials into the login form"
        >
          <KeyRound size={13} />
          <span>⚡ Quick Fill Admin</span>
        </button>
      </div>

      {/* TAB 1: LOGIN FORM */}
      {authMode === 'login' && (
        <form onSubmit={handleLoginSubmit} className="mt-6 space-y-4">
          {loginError && (
            <div className="p-3 bg-rose-50 border-2 border-rose-300 rounded-xl text-rose-800 text-xs flex items-center gap-2 animate-shake">
              <AlertCircle size={16} className="text-rose-600 shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          {loginSuccessMsg && (
            <div className="p-3 bg-emerald-50 border-2 border-emerald-300 rounded-xl text-emerald-800 text-xs flex items-center gap-2">
              <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
              <span>{loginSuccessMsg}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-comic font-black uppercase text-slate-700 tracking-wider">
                Email Address
              </label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="email"
                  required
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  placeholder="e.g. deepikanavneetsingh@gmail.com"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border-2 border-slate-300 focus:border-slate-900 focus:outline-hidden text-xs sm:text-sm font-medium bg-white"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-comic font-black uppercase text-slate-700 tracking-wider">
                Password
              </label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="password"
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border-2 border-slate-300 focus:border-slate-900 focus:outline-hidden text-xs sm:text-sm font-medium bg-white"
                />
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
            <div className="text-xs text-slate-500 text-center sm:text-left">
              New to Python Adventures?{' '}
              <button
                type="button"
                onClick={() => {
                  soundFX.playPop();
                  setAuthMode('register');
                }}
                className="font-bold text-amber-700 hover:underline cursor-pointer"
              >
                Create a student profile here
              </button>
            </div>

            <button
              type="submit"
              className="w-full sm:w-auto comic-button px-7 py-3 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-sm rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              <LogIn size={16} />
              <span>Sign In to Python Adventures</span>
            </button>
          </div>
        </form>
      )}

      {/* TAB 2: REGISTRATION FORM */}
      {authMode === 'register' && (
        <form onSubmit={handleRegisterSubmit} className="mt-6 space-y-4">
          {regError && (
            <div className="p-3 bg-rose-50 border-2 border-rose-300 rounded-xl text-rose-800 text-xs flex items-center gap-2 animate-shake">
              <AlertCircle size={16} className="text-rose-600 shrink-0" />
              <span>{regError}</span>
            </div>
          )}

          {regSuccessMsg && (
            <div className="p-3 bg-emerald-50 border-2 border-emerald-300 rounded-xl text-emerald-800 text-xs flex items-center gap-2">
              <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
              <span>{regSuccessMsg}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-comic font-black uppercase text-slate-700 tracking-wider">
                Full Name
              </label>
              <div className="relative">
                <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  required
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="e.g. Ananya Sharma"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border-2 border-slate-300 focus:border-slate-900 focus:outline-hidden text-xs sm:text-sm font-medium bg-white"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-comic font-black uppercase text-slate-700 tracking-wider">
                Email Address
              </label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="email"
                  required
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  placeholder="ananya@example.com"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border-2 border-slate-300 focus:border-slate-900 focus:outline-hidden text-xs sm:text-sm font-medium bg-white"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-comic font-black uppercase text-slate-700 tracking-wider">
                Create Password
              </label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="password"
                  required
                  minLength={6}
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  placeholder="Minimum 6 characters"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border-2 border-slate-300 focus:border-slate-900 focus:outline-hidden text-xs sm:text-sm font-medium bg-white"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-comic font-black uppercase text-slate-700 tracking-wider">
                Confirm Password
              </label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="password"
                  required
                  minLength={6}
                  value={regConfirmPassword}
                  onChange={(e) => setRegConfirmPassword(e.target.value)}
                  placeholder="Re-enter password"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border-2 border-slate-300 focus:border-slate-900 focus:outline-hidden text-xs sm:text-sm font-medium bg-white"
                />
              </div>
            </div>
          </div>

          {/* Avatar Character Selection */}
          <div className="space-y-1.5 pt-1">
            <label className="block text-xs font-comic font-black uppercase text-slate-700 tracking-wider">
              Choose Your Companion Mascot
            </label>
            <div className="grid grid-cols-4 gap-3">
              {[
                { id: 'alex', label: 'Alex', desc: 'The Curious Learner' },
                { id: 'pip', label: 'Pip', desc: 'The Wise Instructor' },
                { id: 'byte', label: 'Byte', desc: 'The Robot Helper' },
                { id: 'bugsy', label: 'Bugsy', desc: 'The Detective Bug' }
              ].map((mascot) => {
                const isSelected = regAvatar === mascot.id;
                return (
                  <button
                    key={mascot.id}
                    type="button"
                    onClick={() => {
                      soundFX.playPop();
                      setRegAvatar(mascot.id as any);
                    }}
                    className={`p-2.5 rounded-xl border-2 text-center transition-all cursor-pointer flex flex-col items-center gap-1 ${
                      isSelected
                        ? 'border-slate-900 bg-amber-50 ring-2 ring-amber-400 scale-102 shadow-xs'
                        : 'border-slate-200 bg-white hover:border-slate-400'
                    }`}
                  >
                    {mascot.id === 'alex' && <AlexCharacter mood="happy" size={38} />}
                    {mascot.id === 'pip' && <PipCharacter mood="happy" size={38} />}
                    {mascot.id === 'byte' && <ByteCharacter mood="happy" size={38} />}
                    {mascot.id === 'bugsy' && <BugsyCharacter mood="happy" size={38} />}
                    <span className="text-xs font-comic font-bold text-slate-900">
                      {mascot.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3">
            <div className="text-xs text-slate-500 text-center sm:text-left">
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  soundFX.playPop();
                  setAuthMode('login');
                }}
                className="font-bold text-amber-700 hover:underline cursor-pointer"
              >
                Sign in here
              </button>
            </div>

            <button
              type="submit"
              className="w-full sm:w-auto comic-button px-7 py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-sm rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-md border-2 border-slate-900"
            >
              <UserPlus size={16} />
              <span>Create Account & Start</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
