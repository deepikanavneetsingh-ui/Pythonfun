import React, { useState, useEffect } from 'react';
import { QuizQuestion } from '../types/curriculum';
import { PipCharacter, AlexCharacter } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';
import { speechService } from '../utils/speechService';
import { CheckCircle2, XCircle, Award, RotateCcw, X, ArrowRight, BookOpen, Volume2, Square } from 'lucide-react';
import confetti from 'canvas-confetti';

interface QuizModalProps {
  chapterNumber: number;
  chapterTitle: string;
  questions: QuizQuestion[];
  onClose: () => void;
  onSaveScore: (chapterNum: number, score: number, total: number) => void;
  previousScore?: { score: number; total: number };
}

export const QuizModal: React.FC<QuizModalProps> = ({
  chapterNumber,
  chapterTitle,
  questions,
  onClose,
  onSaveScore,
  previousScore
}) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [submittedQuestions, setSubmittedQuestions] = useState<Record<number, boolean>>({});
  const [isFinished, setIsFinished] = useState<boolean>(false);
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  useEffect(() => {
    return () => {
      speechService.stop();
    };
  }, []);

  const speakText = (text: string, speaker: 'pip' | 'alex' | 'byte' | 'bugsy', id: string) => {
    if (speakingId === id) {
      speechService.stop();
      setSpeakingId(null);
      return;
    }
    soundFX.playPop();
    setSpeakingId(id);
    speechService.speak(
      text,
      speaker,
      id,
      () => setSpeakingId(id),
      () => setSpeakingId((curr) => (curr === id ? null : curr)),
      () => setSpeakingId(null)
    );
  };

  const currentQ = questions[currentIndex];
  const isAnswerSelected = selectedAnswers[currentIndex] !== undefined;
  const isCurrentSubmitted = submittedQuestions[currentIndex] === true;
  const isCorrect = isCurrentSubmitted && selectedAnswers[currentIndex] === currentQ.correctIndex;

  const handleSelectOption = (optionIndex: number) => {
    if (isCurrentSubmitted) return;
    soundFX.playPop();
    setSelectedAnswers((prev) => ({ ...prev, [currentIndex]: optionIndex }));
  };

  const handleSubmitAnswer = () => {
    if (!isAnswerSelected || isCurrentSubmitted) return;
    const correct = selectedAnswers[currentIndex] === currentQ.correctIndex;
    if (correct) {
      soundFX.playSuccess();
    } else {
      soundFX.playBugZap();
    }
    setSubmittedQuestions((prev) => ({ ...prev, [currentIndex]: true }));
  };

  const handleNext = () => {
    soundFX.playPop();
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      // Calculate final score
      let correctCount = 0;
      questions.forEach((q, idx) => {
        if (selectedAnswers[idx] === q.correctIndex) {
          correctCount++;
        }
      });
      setIsFinished(true);
      onSaveScore(chapterNumber, correctCount, questions.length);

      if (correctCount === questions.length) {
        soundFX.playFanfare();
        try {
          confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
        } catch {}
      }
    }
  };

  const restartQuiz = () => {
    setSelectedAnswers({});
    setSubmittedQuestions({});
    setCurrentIndex(0);
    setIsFinished(false);
    soundFX.playPop();
  };

  const totalScore = Object.keys(submittedQuestions).reduce((acc, idxStr) => {
    const idx = parseInt(idxStr, 10);
    return selectedAnswers[idx] === questions[idx].correctIndex ? acc + 1 : acc;
  }, 0);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="w-full max-w-3xl max-h-[92vh] comic-panel shadow-2xl flex flex-col bg-[#FFFDF9] overflow-hidden">
        {/* Header */}
        <div className="bg-[#1E293B] text-white px-5 py-3.5 flex items-center justify-between border-b-4 border-amber-400">
          <div className="flex items-center gap-3">
            <div className="bg-amber-400 p-1.5 rounded-lg text-slate-900">
              <Award size={22} className="stroke-[2.5]" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-amber-300 uppercase tracking-widest">
                Chapter {chapterNumber} Knowledge Check
              </div>
              <h2 className="font-comic text-lg md:text-xl text-white">{chapterTitle}</h2>
            </div>
          </div>

          <button
            onClick={() => {
              soundFX.playPop();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        {!isFinished ? (
          <div className="p-5 sm:p-7 overflow-y-auto space-y-6">
            {/* Progress bar */}
            <div className="flex items-center justify-between text-xs font-bold text-slate-600">
              <span>
                Question {currentIndex + 1} of {questions.length}
              </span>
              <div className="flex gap-1.5">
                {questions.map((_, i) => (
                  <span
                    key={i}
                    className={`w-3 h-3 rounded-full border border-slate-900 ${
                      i === currentIndex
                        ? 'bg-amber-400'
                        : submittedQuestions[i]
                        ? selectedAnswers[i] === questions[i].correctIndex
                          ? 'bg-emerald-400'
                          : 'bg-rose-400'
                        : 'bg-slate-200'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Question Card */}
            <div className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                {currentQ.question}
              </h3>

              {currentQ.codeSnippet && (
                <div className="bg-slate-900 text-emerald-300 p-3.5 rounded-lg font-mono text-xs sm:text-sm shadow-inner overflow-x-auto">
                  <pre>{currentQ.codeSnippet}</pre>
                </div>
              )}
            </div>

            {/* Options List */}
            <div className="space-y-2.5">
              {currentQ.options.map((option, optIdx) => {
                const isSelected = selectedAnswers[currentIndex] === optIdx;
                let btnStyle = 'bg-white border-2 border-slate-300 hover:border-slate-800 text-slate-800';

                if (isCurrentSubmitted) {
                  if (optIdx === currentQ.correctIndex) {
                    btnStyle = 'bg-emerald-100 border-2 border-emerald-600 text-emerald-950 font-bold';
                  } else if (isSelected) {
                    btnStyle = 'bg-rose-100 border-2 border-rose-500 text-rose-950';
                  } else {
                    btnStyle = 'bg-slate-50 border-slate-200 text-slate-400 opacity-60';
                  }
                } else if (isSelected) {
                  btnStyle = 'bg-amber-100 border-2 border-amber-500 text-amber-950 font-bold shadow-sm';
                }

                return (
                  <button
                    key={optIdx}
                    onClick={() => handleSelectOption(optIdx)}
                    disabled={isCurrentSubmitted}
                    className={`w-full text-left p-3.5 rounded-xl text-sm transition-all flex items-center justify-between cursor-pointer ${btnStyle}`}
                  >
                    <span>{option}</span>
                    {isCurrentSubmitted && optIdx === currentQ.correctIndex && (
                      <CheckCircle2 size={18} className="text-emerald-600 shrink-0" />
                    )}
                    {isCurrentSubmitted && isSelected && optIdx !== currentQ.correctIndex && (
                      <XCircle size={18} className="text-rose-600 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Feedback & Explanation Box */}
            {isCurrentSubmitted && (
              <div
                onClick={() =>
                  speakText(
                    isCorrect
                      ? `Correct! Excellent reasoning! ${currentQ.explanation}`
                      : `Here is a helpful tip: ${currentQ.misconceptionHint}`,
                    'pip',
                    'quiz-pip'
                  )
                }
                className={`comic-panel p-4 rounded-xl cursor-pointer transition-all ${
                  isCorrect
                    ? 'bg-emerald-50 border-2 border-emerald-700 hover:bg-emerald-100/60'
                    : 'bg-rose-50 border-2 border-rose-700 hover:bg-rose-100/60'
                } ${speakingId === 'quiz-pip' ? 'ring-4 ring-emerald-300 shadow-md' : ''}`}
                title="Click to hear Pip speak in native Indian English"
              >
                <div className="flex items-start gap-3">
                  <PipCharacter
                    mood={isCorrect ? 'happy' : 'thinking'}
                    size={54}
                    isSpeaking={speakingId === 'quiz-pip'}
                  />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-comic text-xs uppercase tracking-wider text-slate-900">
                        {isCorrect ? 'Correct! Excellent Reasoning' : "Pip's Misconception Guide:"}
                      </h4>
                      <span className="text-[10px] font-bold text-slate-700 bg-white/80 px-2 py-0.5 rounded-full flex items-center gap-1 border border-slate-300">
                        {speakingId === 'quiz-pip' ? (
                          <>
                            <Square size={10} className="fill-slate-800" />
                            Pip Speaking 🇮🇳
                          </>
                        ) : (
                          <>
                            <Volume2 size={10} />
                            Tap to listen 🇮🇳
                          </>
                        )}
                      </span>
                    </div>
                    <p className="text-xs text-slate-800 leading-relaxed font-medium">
                      "{isCorrect ? currentQ.explanation : currentQ.misconceptionHint}"
                    </p>
                    {speakingId === 'quiz-pip' && (
                      <div className="mt-2 flex items-center gap-1 text-[10px] text-emerald-800 font-mono">
                        <span className="w-1 bg-emerald-600 rounded-full animate-eq-1" />
                        <span className="w-1 bg-emerald-600 rounded-full animate-eq-2" />
                        <span className="w-1 bg-emerald-600 rounded-full animate-eq-3" />
                        <span className="ml-1">Pip speaking with native Indian dialect...</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Finished Score Card */
          <div className="p-8 text-center space-y-6">
            <div
              onClick={() =>
                speakText(
                  `Congratulations on completing the Chapter ${chapterNumber} quiz! You scored ${totalScore} out of ${questions.length}! Keep growing your coding superpower!`,
                  'alex',
                  'quiz-alex'
                )
              }
              className="inline-block p-4 bg-amber-100 rounded-full border-4 border-slate-900 cursor-pointer hover:scale-105 transition-transform"
              title="Click to hear Alex celebrate"
            >
              <AlexCharacter
                mood="happy"
                size={96}
                isSpeaking={speakingId === 'quiz-alex'}
              />
            </div>

            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 border border-amber-300 text-xs font-bold text-amber-900 mb-2">
                <Volume2 size={12} />
                {speakingId === 'quiz-alex' ? 'Alex Speaking 🇮🇳' : 'Tap Alex to hear cheer 🇮🇳'}
              </div>
              <h3 className="font-comic text-2xl text-slate-900">Quiz Completed!</h3>
              <p className="text-slate-600 text-sm mt-1">Here is how you scored on Chapter {chapterNumber}:</p>
            </div>

            <div className="p-5 bg-slate-100 rounded-2xl border-2 border-slate-300 inline-block min-w-[260px]">
              <div className="text-4xl font-extrabold font-comic text-slate-900">
                {totalScore} / {questions.length}
              </div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mt-1">
                {Math.round((totalScore / questions.length) * 100)}% Mastery Score
              </div>
            </div>

            <div className="flex items-center justify-center gap-3">
              <button
                onClick={restartQuiz}
                className="comic-button px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs rounded-xl flex items-center gap-2"
              >
                <RotateCcw size={15} /> Retake Quiz
              </button>
              <button
                onClick={onClose}
                className="comic-button px-6 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-900 font-bold text-xs rounded-xl flex items-center gap-2"
              >
                <span>Continue Adventure</span>
              </button>
            </div>
          </div>
        )}

        {/* Footer Controls */}
        {!isFinished && (
          <div className="p-4 bg-slate-100 border-t border-slate-300 flex items-center justify-between">
            <button
              onClick={onClose}
              className="text-xs font-bold text-slate-500 hover:text-slate-800 px-3 py-2"
            >
              Exit Quiz
            </button>

            {!isCurrentSubmitted ? (
              <button
                onClick={handleSubmitAnswer}
                disabled={!isAnswerSelected}
                className="comic-button px-6 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-900 font-extrabold text-xs rounded-xl disabled:opacity-40"
              >
                Submit Answer
              </button>
            ) : (
              <button
                onClick={handleNext}
                className="comic-button px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5"
              >
                <span>{currentIndex < questions.length - 1 ? 'Next Question' : 'See Results'}</span>
                <ArrowRight size={15} />
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
