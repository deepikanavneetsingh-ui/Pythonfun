import React, { useState, useEffect } from 'react';
import { DebugChallenge } from '../types/curriculum';
import { BugsyCharacter } from '../characters/CharacterSvgs';
import { pythonRunner } from '../runtime/pythonRunner';
import { soundFX } from '../utils/soundEffects';
import { speechService } from '../utils/speechService';
import { Play, HelpCircle, CheckCircle2, RotateCcw, X, ShieldAlert, Award, Volume2, Square } from 'lucide-react';

interface DebuggingLabModalProps {
  challenge: DebugChallenge;
  onClose: () => void;
  onSolved: (challengeId: string) => void;
  isSolvedAlready?: boolean;
}

export const DebuggingLabModal: React.FC<DebuggingLabModalProps> = ({
  challenge,
  onClose,
  onSolved,
  isSolvedAlready = false
}) => {
  const [code, setCode] = useState<string>(challenge.buggyCode);
  const [hintLevel, setHintLevel] = useState<number>(0);
  const [output, setOutput] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState<boolean>(isSolvedAlready);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isBugsySpeaking, setIsBugsySpeaking] = useState<boolean>(false);

  useEffect(() => {
    return () => {
      speechService.stop();
    };
  }, []);

  const speakBugsy = (text: string) => {
    if (isBugsySpeaking) {
      speechService.stop();
      setIsBugsySpeaking(false);
      return;
    }

    soundFX.playPop();
    setIsBugsySpeaking(true);
    speechService.speak(
      text,
      'bugsy',
      'debugging-lab',
      () => setIsBugsySpeaking(true),
      () => setIsBugsySpeaking(false),
      () => setIsBugsySpeaking(false)
    );
  };

  const testFix = async () => {
    speechService.stop();
    setIsBugsySpeaking(false);
    setIsRunning(true);
    setError(null);
    setOutput('');
    soundFX.playPop();

    try {
      const res = await pythonRunner.execute(code);
      if (res.error) {
        setError(res.error);
        soundFX.playBugZap();
      } else {
        setOutput(res.output);
        setIsSuccess(true);
        soundFX.playFanfare();
        onSolved(challenge.id);
        // Automatically give celebratory Bugsy feedback
        setTimeout(() => {
          speakBugsy(`Bug crushed! Brilliant work, hero! ${challenge.explanation}`);
        }, 300);
      }
    } catch (err: any) {
      setError(String(err));
      soundFX.playBugZap();
    } finally {
      setIsRunning(false);
    }
  };

  const resetChallenge = () => {
    speechService.stop();
    setIsBugsySpeaking(false);
    setCode(challenge.buggyCode);
    setOutput('');
    setError(null);
    setIsSuccess(false);
    setHintLevel(0);
    soundFX.playPop();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="w-full max-w-4xl max-h-[92vh] comic-panel shadow-2xl flex flex-col bg-[#FFFDF9] overflow-hidden">
        {/* Header */}
        <div className="bg-[#6B21A8] text-white px-5 py-3 flex items-center justify-between border-b-4 border-amber-400">
          <div className="flex items-center gap-3">
            <div className="bg-amber-400 p-1.5 rounded-lg text-slate-900">
              <ShieldAlert size={22} className="stroke-[2.5]" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-purple-200 uppercase tracking-widest">
                Bugsy's Debugging Laboratory
              </div>
              <h2 className="font-comic text-lg md:text-xl text-white">{challenge.title}</h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => speakBugsy(challenge.scenario)}
              className={`comic-button px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                isBugsySpeaking
                  ? 'bg-rose-500 hover:bg-rose-600 text-white animate-pulse'
                  : 'bg-amber-400 hover:bg-amber-300 text-slate-900'
              }`}
              title="Click to hear Bugsy speak with native Indian detective dialect"
            >
              {isBugsySpeaking ? <Square size={13} className="fill-white" /> : <Volume2 size={14} />}
              <span>{isBugsySpeaking ? 'Stop Voice' : '🇮🇳 Bugsy Speaks'}</span>
            </button>

            <button
              onClick={() => {
                speechService.stop();
                soundFX.playPop();
                onClose();
              }}
              className="p-1.5 rounded-lg bg-purple-900/60 hover:bg-purple-900 text-purple-100 cursor-pointer"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Challenge Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
          {/* Scenario Banner with Bugsy */}
          <div
            onClick={() => speakBugsy(challenge.scenario)}
            className={`comic-panel p-4 bg-purple-50 border-2 border-purple-900 flex flex-col sm:flex-row items-center gap-4 cursor-pointer transition-all ${
              isBugsySpeaking
                ? 'border-purple-600 ring-4 ring-purple-300/60 bg-purple-100/60 shadow-lg'
                : 'hover:border-purple-600'
            }`}
            title="Click to hear Bugsy speak his investigation report in Indian English"
          >
            <div className="shrink-0 transform hover:scale-105 transition-transform">
              <BugsyCharacter
                mood={isSuccess ? 'happy' : 'thinking'}
                size={85}
                isSpeaking={isBugsySpeaking}
              />
            </div>
            <div className="flex-1 text-center sm:text-left space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="inline-block px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-200 text-purple-900">
                  Detected Bug: {challenge.errorType}
                </span>
                <span className="text-[10px] font-bold text-purple-800 bg-purple-200/80 px-2 py-0.5 rounded-full flex items-center gap-1">
                  {isBugsySpeaking ? (
                    <>
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-700 animate-ping" />
                      Bugsy Speaking 🇮🇳
                    </>
                  ) : (
                    <>
                      <Volume2 size={11} /> Tap to listen 🇮🇳
                    </>
                  )}
                </span>
              </div>
              <p className="text-sm text-slate-900 leading-relaxed font-medium">
                "{challenge.scenario}"
              </p>
              {isBugsySpeaking && (
                <div className="pt-1 flex items-center gap-1 text-[11px] text-purple-800 font-mono">
                  <span className="w-1 bg-purple-600 rounded-full animate-eq-1" />
                  <span className="w-1 bg-purple-600 rounded-full animate-eq-2" />
                  <span className="w-1 bg-purple-600 rounded-full animate-eq-3" />
                  <span className="w-1 bg-purple-600 rounded-full animate-eq-4" />
                  <span className="ml-1 text-[10px]">Bugsy detective voice active (Indian native)</span>
                </div>
              )}
            </div>
          </div>

          {/* Success Banner if solved */}
          {isSuccess && (
            <div
              onClick={() => speakBugsy(`Bug crushed! You fixed the code! ${challenge.explanation}`)}
              className="p-4 bg-emerald-50 border-2 border-emerald-500 rounded-xl flex items-center justify-between gap-3 animate-in fade-in cursor-pointer hover:bg-emerald-100/60 transition-colors"
              title="Click to hear solution explanation"
            >
              <div className="flex items-center gap-3">
                <div className="bg-emerald-500 p-2 rounded-full text-white shrink-0">
                  <CheckCircle2 size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-emerald-900 text-sm flex items-center gap-1.5">
                    Bug Crushed! You fixed the code! <Award size={16} className="text-amber-500" />
                  </h4>
                  <p className="text-xs text-emerald-800 mt-0.5">
                    {challenge.explanation}
                  </p>
                </div>
              </div>
              <button
                className="p-1.5 bg-white text-emerald-800 rounded-lg border border-emerald-300 text-xs font-bold flex items-center gap-1 shrink-0"
              >
                <Volume2 size={13} />
                <span>Hear Solution</span>
              </button>
            </div>
          )}

          {/* Code Editor */}
          <div className="comic-panel overflow-hidden border-slate-800">
            <div className="bg-slate-800 text-slate-200 px-4 py-2 flex items-center justify-between text-xs font-mono">
              <span>Fix the broken code below:</span>
              <button
                onClick={resetChallenge}
                className="hover:text-amber-400 flex items-center gap-1 transition-colors cursor-pointer"
              >
                <RotateCcw size={13} /> Reset Bug
              </button>
            </div>
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              rows={Math.max(code.split('\n').length + 2, 6)}
              className="w-full bg-[#1E293B] text-emerald-300 font-mono text-sm p-4 focus:outline-none resize-none leading-relaxed"
              spellCheck={false}
            />
          </div>

          {/* Test & Run Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <button
              onClick={testFix}
              disabled={isRunning}
              className="comic-button px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-xs sm:text-sm rounded-xl flex items-center gap-2 shadow-md cursor-pointer disabled:opacity-50"
            >
              <Play size={16} className="fill-white" />
              <span>{isRunning ? 'Testing Fix...' : 'Run & Test Code'}</span>
            </button>

            {/* Hint Toggles */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  soundFX.playPop();
                  const hints = [challenge.hint1Line, challenge.hint2Concept, challenge.hint3Fix];
                  const nextLevel = Math.min(hintLevel + 1, 3);
                  setHintLevel(nextLevel);
                  if (hints[nextLevel - 1]) {
                    speakBugsy(`Detective Hint ${nextLevel}: ${hints[nextLevel - 1]}`);
                  }
                }}
                disabled={hintLevel >= 3}
                className="comic-button px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-900 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer disabled:opacity-40"
              >
                <HelpCircle size={14} />
                <span>
                  {hintLevel === 0 ? 'Unlock Hint 1' : hintLevel === 1 ? 'Unlock Hint 2' : hintLevel === 2 ? 'Unlock Hint 3' : 'All Hints Unlocked'}
                </span>
              </button>
            </div>
          </div>

          {/* Hints Display */}
          {hintLevel > 0 && (
            <div className="space-y-2">
              {[challenge.hint1Line, challenge.hint2Concept, challenge.hint3Fix].slice(0, hintLevel).map((hint: string, idx: number) => (
                <div
                  key={idx}
                  onClick={() => speakBugsy(`Hint ${idx + 1}: ${hint}`)}
                  className="p-3 bg-amber-50 border-2 border-amber-300 rounded-xl text-xs text-amber-950 flex items-center justify-between gap-2 cursor-pointer hover:bg-amber-100/70"
                  title="Click to hear hint"
                >
                  <div>
                    <span className="font-comic font-bold text-amber-800 mr-2">HINT #{idx + 1}:</span>
                    <span>{hint}</span>
                  </div>
                  <Volume2 size={13} className="text-amber-700 shrink-0" />
                </div>
              ))}
            </div>
          )}

          {/* Output / Console result */}
          {error && (
            <div className="p-3.5 bg-rose-50 border-2 border-rose-300 rounded-xl text-xs font-mono text-rose-800 space-y-1">
              <div className="font-bold text-rose-900 flex items-center gap-1">
                Bugsy says: "Code still has a bug!"
              </div>
              <pre className="whitespace-pre-wrap">{error}</pre>
            </div>
          )}

          {output && !error && (
            <div className="p-3.5 bg-slate-900 text-emerald-400 border-2 border-slate-800 rounded-xl font-mono text-xs space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-slate-400">Terminal Output:</div>
              <pre className="whitespace-pre-wrap">{output}</pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
