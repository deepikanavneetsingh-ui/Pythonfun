import React, { useState, useEffect } from 'react';
import { PipCharacter, AlexCharacter, ByteCharacter, BugsyCharacter } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';
import { speechService } from '../utils/speechService';
import {
  Sparkles,
  ArrowRight,
  BookOpen,
  Code2,
  Terminal,
  Play,
  Award,
  Layers,
  HelpCircle,
  ShieldAlert,
  Flame,
  Volume2,
  Square
} from 'lucide-react';
import { AuthWindow } from './AuthWindow';
import { UserAccount } from '../types/auth';

interface LandingProps {
  onStartAdventure: () => void;
  onExploreChapters: () => void;
  onOpenPlayground: (code?: string) => void;
  onStartBranchingAdventure: () => void;
  currentUser: UserAccount | null;
  onLoginSuccess: (user: UserAccount) => void;
  onLogout: () => void;
  onOpenAdminConsole: () => void;
}

export const LandingView: React.FC<LandingProps> = ({
  onStartAdventure,
  onExploreChapters,
  onOpenPlayground,
  onStartBranchingAdventure,
  currentUser,
  onLoginSuccess,
  onLogout,
  onOpenAdminConsole
}) => {
  const [speakingSpeaker, setSpeakingSpeaker] = useState<'pip' | 'alex' | 'byte' | 'bugsy' | null>(null);

  useEffect(() => {
    return () => {
      speechService.stop();
    };
  }, []);

  const CHARACTER_DIALOGUES: Record<'pip' | 'alex' | 'byte' | 'bugsy', string> = {
    pip: "Greetings, noble scholar. I am Pip the Python, your esteemed mentor. Together, we shall master the royal craft of programming, turning intricate logic into triumphant creations with honor and discipline.",
    alex: "Hey there! I am Alex! I'm fifteen and just started coding with zero experience! If I can conquer loops, variables, and build awesome games, you can totally do it too! Let's build something epic!",
    byte: "BEEP-BOOP! GREETINGS HUMAN! I AM UNIT BYTE, YOUR COMIC ROBOT ASSISTANT. MY PROCESSORS DETECT ZERO SYNTAX BUGS. SYSTEM NOMINAL. STANDING BY TO COMPILE AND EXECUTE CODE!",
    bugsy: "Hehehe, I am Bugsy! When you hit a tricky syntax error or traceback, do not panic! I will help you investigate and crush the bug!"
  };

  const handleSpeak = (speaker: 'pip' | 'alex' | 'byte' | 'bugsy') => {
    if (speakingSpeaker === speaker) {
      speechService.stop();
      setSpeakingSpeaker(null);
      return;
    }
    soundFX.playPop();
    setSpeakingSpeaker(speaker);
    speechService.speak(
      CHARACTER_DIALOGUES[speaker],
      speaker,
      `landing-${speaker}`,
      () => setSpeakingSpeaker(speaker),
      () => setSpeakingSpeaker((curr) => (curr === speaker ? null : curr)),
      () => setSpeakingSpeaker(null)
    );
  };

  return (
    <div className="space-y-16 pb-20">
      {/* Hero Section */}
      <section className="comic-panel p-6 sm:p-12 bg-gradient-to-br from-amber-400 via-amber-300 to-yellow-100 border-slate-900 shadow-2xl relative overflow-hidden">
        {/* Decorative background grid pattern */}
        <div
          className="absolute inset-0 opacity-10 pointer-events-none"
          style={{
            backgroundImage: 'radial-gradient(#1E293B 1.5px, transparent 1.5px)',
            backgroundSize: '24px 24px'
          }}
        />

        <div className="max-w-4xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-10 relative z-10">
          <div className="space-y-5 text-center lg:text-left flex-1">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/80 border-2 border-slate-900 shadow-xs text-xs font-comic uppercase tracking-wider text-slate-800">
              <Sparkles size={14} className="text-amber-600" />
              <span>Interactive Digital Comic Book & Course</span>
            </div>

            <h1 className="font-comic text-4xl sm:text-5xl lg:text-6xl text-slate-900 leading-[1.1] tracking-wide">
              PYTHON ADVENTURES
            </h1>

            <div className="text-lg sm:text-2xl font-bold text-amber-950 font-sans">
              Learn Python from Zero to Coding Hero
            </div>

            <p className="text-xs sm:text-sm text-slate-800 max-w-xl leading-relaxed font-medium">
              No Coding Experience Required. Just Curiosity. Learn real Python 3 through original
              comic stories, friendly character dialogue, practical projects, and a real in-browser
              coding playground.
            </p>

            {/* CTA Buttons */}
            <div className="pt-2 flex flex-wrap items-center justify-center lg:justify-start gap-3">
              <button
                onClick={() => {
                  soundFX.playFanfare();
                  onStartAdventure();
                }}
                className="comic-button px-7 py-3.5 bg-[#1E293B] hover:bg-slate-800 text-white font-extrabold text-sm rounded-xl flex items-center gap-2.5 shadow-lg cursor-pointer transform hover:-translate-y-0.5"
              >
                <span>Start My Adventure</span>
                <ArrowRight size={18} />
              </button>

              <button
                onClick={() => {
                  soundFX.playPop();
                  onExploreChapters();
                }}
                className="comic-button px-6 py-3.5 bg-white hover:bg-slate-50 text-slate-900 font-extrabold text-sm rounded-xl flex items-center gap-2 shadow-md cursor-pointer"
              >
                <BookOpen size={17} />
                <span>Explore the 20 Chapters</span>
              </button>
            </div>
          </div>

          {/* Hero Comic Vignette with Interactive Speaking Characters */}
          <div className="relative shrink-0 w-full max-w-md">
            {/* Live Character Speech Bubble Box if speaking */}
            {speakingSpeaker && (
              <div
                onClick={() => handleSpeak(speakingSpeaker)}
                className="mb-3 comic-panel p-3.5 bg-white border-2 border-amber-500 shadow-lg speech-bubble-bottom animate-speaking-bubble cursor-pointer"
                title="Click to pause or stop"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-comic font-black uppercase tracking-wider text-amber-800">
                    {speakingSpeaker === 'pip'
                      ? 'Pip the Python (Noble Deep Voice 👑)'
                      : speakingSpeaker === 'alex'
                      ? 'Alex (Teenager Boy Voice 🎒)'
                      : speakingSpeaker === 'byte'
                      ? 'Byte (Comic Robot Voice 🤖)'
                      : 'Bugsy the Detective Bug 🔍'}
                  </span>
                  <div className="flex items-center gap-1 text-[9px] font-mono text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded-full">
                    <span className="w-1 bg-amber-600 rounded-full animate-eq-1" />
                    <span className="w-1 bg-amber-600 rounded-full animate-eq-2" />
                    <span className="w-1 bg-amber-600 rounded-full animate-eq-3" />
                    <span>Speaking 🇮🇳</span>
                  </div>
                </div>
                <p className="font-comic-bubble text-xs sm:text-sm text-slate-900 leading-snug">
                  "{CHARACTER_DIALOGUES[speakingSpeaker]}"
                </p>
              </div>
            )}

            <div className="comic-panel p-5 bg-white border-4 border-slate-900 shadow-2xl rounded-3xl flex items-end justify-around gap-2">
              {/* Pip */}
              <div
                onClick={() => handleSpeak('pip')}
                className={`flex flex-col items-center cursor-pointer transition-all p-1.5 rounded-2xl ${
                  speakingSpeaker === 'pip' ? 'bg-emerald-50 ring-2 ring-emerald-500 scale-105' : 'hover:scale-105'
                }`}
                title="Click to hear Pip's deep noble voice"
              >
                <PipCharacter mood="happy" size={105} isSpeaking={speakingSpeaker === 'pip'} />
                <span className="text-[10px] font-bold text-emerald-800 mt-1 flex items-center gap-0.5">
                  <Volume2 size={10} /> 👑 Pip (Deep Noble)
                </span>
              </div>

              {/* Alex */}
              <div
                onClick={() => handleSpeak('alex')}
                className={`flex flex-col items-center cursor-pointer transition-all p-1.5 rounded-2xl ${
                  speakingSpeaker === 'alex' ? 'bg-amber-50 ring-2 ring-amber-500 scale-105' : 'hover:scale-105'
                }`}
                title="Click to hear Alex's teenager boy voice"
              >
                <AlexCharacter mood="coding" size={100} isSpeaking={speakingSpeaker === 'alex'} />
                <span className="text-[10px] font-bold text-amber-800 mt-1 flex items-center gap-0.5">
                  <Volume2 size={10} /> 🎒 Alex (Teenager Boy)
                </span>
              </div>

              {/* Byte */}
              <div
                onClick={() => handleSpeak('byte')}
                className={`flex flex-col items-center cursor-pointer transition-all p-1.5 rounded-2xl ${
                  speakingSpeaker === 'byte' ? 'bg-sky-50 ring-2 ring-sky-500 scale-105' : 'hover:scale-105'
                }`}
                title="Click to hear Byte's comic robot voice with square-wave chirps"
              >
                <ByteCharacter mood="happy" size={90} isSpeaking={speakingSpeaker === 'byte'} />
                <span className="text-[10px] font-bold text-sky-800 mt-1 flex items-center gap-0.5">
                  <Volume2 size={10} /> 🤖 Byte (Comic Robot)
                </span>
              </div>
            </div>

            {/* Bugsy Floating Badge */}
            <div
              onClick={() => handleSpeak('bugsy')}
              className={`absolute -top-3 -right-3 comic-panel px-3 py-1.5 text-xs font-comic rotate-6 shadow-md cursor-pointer transition-all ${
                speakingSpeaker === 'bugsy'
                  ? 'bg-rose-600 text-white ring-4 ring-rose-300 scale-110'
                  : 'bg-purple-600 hover:bg-purple-700 text-white hover:scale-105'
              }`}
              title="Click to hear Bugsy speak in detective Indian English"
            >
              <BugsyCharacter mood="happy" size={32} isSpeaking={speakingSpeaker === 'bugsy'} className="inline mr-1" />
              <span>{speakingSpeaker === 'bugsy' ? 'Bugsy Talking 🇮🇳' : 'Tap Bugsy 🇮🇳'}</span>
            </div>

            {/* Instruction tooltip */}
            <div className="mt-2 text-center text-[10px] font-bold text-amber-900 bg-amber-200/60 rounded-full py-0.5 px-3">
              ✨ Tap any character to hear them speak in native Indian English dialect!
            </div>
          </div>
        </div>
      </section>
      
      {/* Registration & Login Portal Window (EXCLUSIVELY VISIBLE AT THE HOMEPAGE) */}
      <section id="auth-portal" className="scroll-mt-6">
        <AuthWindow
          currentUser={currentUser}
          onLoginSuccess={onLoginSuccess}
          onLogout={onLogout}
          onOpenAdminConsole={onOpenAdminConsole}
          onStartAdventure={onStartAdventure}
        />
      </section>

      {/* Interactive "Try It Right Now" Live Playground Preview */}
      <section className="comic-panel p-6 sm:p-8 bg-[#1E293B] text-white border-slate-900 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 flex-1">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 font-mono">
              <Terminal size={16} /> ZERO INSTALLATION REQUIRED
            </div>
            <h2 className="font-comic text-2xl text-white">
              Try Your First Python Command Right Now!
            </h2>
            <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
              You don\'t need to download or configure software. Click below to launch our interactive
              in-browser Python engine and run your first line of code instantly!
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                soundFX.playPop();
                onOpenPlayground(`print("Hello, World!")\nprint("I am officially learning Python!")`);
              }}
              className="comic-button px-6 py-3 bg-emerald-400 hover:bg-emerald-300 text-slate-900 font-extrabold text-xs sm:text-sm rounded-xl flex items-center gap-2 cursor-pointer shadow-md"
            >
              <Play size={16} className="fill-slate-900" />
              <span>Launch Live Playground</span>
            </button>
          </div>
        </div>
      </section>

      {/* The 4-Part Teaching Method */}
      <section className="space-y-6">
        <div className="text-center space-y-1">
          <div className="text-xs font-comic uppercase tracking-widest text-amber-700">
            Instructional Design Standard
          </div>
          <h2 className="font-comic text-3xl text-slate-900">How This Book Teaches You</h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl mx-auto">
            Every lesson follows a verified learning cycle designed to make complex ideas feel natural and fun.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Pillar 1 */}
          <div className="comic-panel p-5 bg-white border-slate-900 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-amber-100 border border-slate-900 flex items-center justify-center text-xl shadow-xs">
              💬
            </div>
            <h3 className="font-comic text-sm text-slate-900">1. Illustrated Comic Scenes</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Every chapter starts with an original comic panel showing characters facing real problems,
              so you understand *why* code exists.
            </p>
          </div>

          {/* Pillar 2 */}
          <div className="comic-panel p-5 bg-white border-slate-900 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-teal-100 border border-slate-900 flex items-center justify-center text-xl shadow-xs">
              🏷️
            </div>
            <h3 className="font-comic text-sm text-slate-900">2. Plain-English Analogies</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              No academic jargon. Variables are labeled boxes, functions are vending machines, and lists
              are multi-slot tackle trays.
            </p>
          </div>

          {/* Pillar 3 */}
          <div className="comic-panel p-5 bg-white border-slate-900 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-sky-100 border border-slate-900 flex items-center justify-center text-xl shadow-xs">
              ⚡
            </div>
            <h3 className="font-comic text-sm text-slate-900">3. Working Playground</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Run real Python in your browser. Interactive <code className="text-sky-700 font-bold">input()</code> prompts let you type
              and converse with your code!
            </p>
          </div>

          {/* Pillar 4 */}
          <div className="comic-panel p-5 bg-white border-slate-900 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-purple-100 border border-slate-900 flex items-center justify-center text-xl shadow-xs">
              🔍
            </div>
            <h3 className="font-comic text-sm text-slate-900">4. Friendly Debugging Lab</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Mistakes are normal! Bugsy the Bug shows you realistic beginner errors and guides you
              through 3 progressive hints to fix them.
            </p>
          </div>
        </div>
      </section>

      {/* Curriculum Acts Overview */}
      <section className="comic-panel p-8 bg-white border-slate-900 space-y-8">
        <div className="text-center space-y-1">
          <div className="text-xs font-comic uppercase tracking-widest text-amber-700">
            20 Comprehensive Chapters
          </div>
          <h2 className="font-comic text-3xl text-slate-900">The 4-Act Hero's Journey</h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl mx-auto">
            A continuous progression from basic print statements to object-oriented programming and AI workflows.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Act 1 */}
          <div className="p-5 rounded-2xl border-2 border-slate-900 bg-amber-50/50 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-comic text-sm text-amber-900">Act 1: The First Spark</span>
              <span className="text-xs font-mono font-bold text-amber-700">Chapters 1 – 5</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed">
              Computers & programs, print statements, numbers, calculations, variables, and text manipulation with modern f-strings.
            </p>
          </div>

          {/* Act 2 */}
          <div className="p-5 rounded-2xl border-2 border-slate-900 bg-sky-50/50 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-comic text-sm text-sky-900">Act 2: Logic & Control</span>
              <span className="text-xs font-mono font-bold text-sky-700">Chapters 6 – 9</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed">
              Interactive input(), type casting, boolean comparisons, if / elif / else decisions, compound logic, and for / while loops.
            </p>
          </div>

          {/* Act 3 */}
          <div className="p-5 rounded-2xl border-2 border-slate-900 bg-teal-50/50 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-comic text-sm text-teal-900">Act 3: Data & Structures</span>
              <span className="text-xs font-mono font-bold text-teal-700">Chapters 10 – 13</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed">
              Dynamic lists, key-value dictionaries, immutable tuples, unique sets, reusable functions with def, and standard library modules.
            </p>
          </div>

          {/* Act 4 */}
          <div className="p-5 rounded-2xl border-2 border-slate-900 bg-purple-50/50 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-comic text-sm text-purple-900">Act 4: Real-World Mastery</span>
              <span className="text-xs font-mono font-bold text-purple-700">Chapters 14 – 20</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed">
              Data persistence, try / except error handling, classes & OOP, JSON data, application architecture, AI concepts, and the Capstone Graduation Adventure!
            </p>
          </div>
        </div>

        <div className="text-center pt-2">
          <button
            onClick={() => {
              soundFX.playPop();
              onStartAdventure();
            }}
            className="comic-button px-8 py-3 bg-amber-400 hover:bg-amber-300 text-slate-900 font-extrabold text-sm rounded-xl inline-flex items-center gap-2 shadow-md cursor-pointer"
          >
            <span>Begin Chapter 1: Enter the World of Programming</span>
            <ArrowRight size={16} />
          </button>
        </div>
      </section>
    </div>
  );
};
