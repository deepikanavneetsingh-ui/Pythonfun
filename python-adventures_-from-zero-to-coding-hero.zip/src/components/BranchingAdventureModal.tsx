import React, { useState, useEffect } from 'react';
import { BranchingStory } from '../types/curriculum';
import { PipCharacter, AlexCharacter, ByteCharacter, BugsyCharacter } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';
import { speechService } from '../utils/speechService';
import { Compass, RotateCcw, X, ArrowRight, Sparkles, Volume2, Square } from 'lucide-react';

interface BranchingAdventureProps {
  story: BranchingStory;
  onClose: () => void;
}

export const BranchingAdventureModal: React.FC<BranchingAdventureProps> = ({ story, onClose }) => {
  const [currentNodeId, setCurrentNodeId] = useState<string>(story.startNodeId);
  const [lastFeedback, setLastFeedback] = useState<{ text: string; isSuccess: boolean } | null>(null);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  const currentNode = story.nodes[currentNodeId] || story.nodes[story.startNodeId];

  // Stop speech when closing or changing nodes
  useEffect(() => {
    return () => {
      speechService.stop();
    };
  }, []);

  const handleSpeak = (text: string, speaker: string) => {
    if (isSpeaking) {
      speechService.stop();
      setIsSpeaking(false);
      return;
    }

    soundFX.playPop();
    setIsSpeaking(true);
    speechService.speak(
      text,
      speaker as any,
      'branching-modal',
      () => setIsSpeaking(true),
      () => setIsSpeaking(false),
      () => setIsSpeaking(false)
    );
  };

  const handleChoose = (choice: any) => {
    speechService.stop();
    setIsSpeaking(false);

    if (choice.isEducationalSuccess) {
      soundFX.playSuccess();
    } else {
      soundFX.playBugZap();
    }
    setLastFeedback({ text: choice.feedback, isSuccess: choice.isEducationalSuccess });
    setCurrentNodeId(choice.leadsToNodeId);
  };

  const restartAdventure = () => {
    speechService.stop();
    setIsSpeaking(false);
    soundFX.playPop();
    setCurrentNodeId(story.startNodeId);
    setLastFeedback(null);
  };

  const getSpeakerLabel = (speaker: string) => {
    switch (speaker) {
      case 'alex':
        return 'Alex the Learner';
      case 'byte':
        return 'Byte the Robot';
      case 'bugsy':
        return 'Bugsy the Bug';
      case 'pip':
      default:
        return 'Pip the Python';
    }
  };

  const renderCharacter = (speaker: string, mood: any, speaking = false) => {
    switch (speaker) {
      case 'alex':
        return <AlexCharacter mood={mood} size={95} isSpeaking={speaking} />;
      case 'byte':
        return <ByteCharacter mood={mood} size={95} isSpeaking={speaking} />;
      case 'bugsy':
        return <BugsyCharacter mood={mood} size={95} isSpeaking={speaking} />;
      case 'pip':
      default:
        return <PipCharacter mood={mood} size={95} isSpeaking={speaking} />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="w-full max-w-3xl max-h-[92vh] comic-panel shadow-2xl flex flex-col bg-[#FFFDF9] overflow-hidden">
        {/* Header */}
        <div className="bg-[#1E293B] text-white px-5 py-3.5 flex items-center justify-between border-b-4 border-amber-400">
          <div className="flex items-center gap-3">
            <div className="bg-amber-400 p-1.5 rounded-lg text-slate-900">
              <Compass size={22} className="stroke-[2.5]" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-amber-300 uppercase tracking-widest">
                Interactive Branching Adventure
              </div>
              <h2 className="font-comic text-lg md:text-xl text-white">{story.title}</h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleSpeak(currentNode.situationText, currentNode.speaker)}
              className={`comic-button px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                isSpeaking
                  ? 'bg-rose-500 hover:bg-rose-600 text-white animate-pulse'
                  : 'bg-amber-400 hover:bg-amber-300 text-slate-900'
              }`}
              title="Click to hear character speak in native Indian English"
            >
              {isSpeaking ? <Square size={13} className="fill-white" /> : <Volume2 size={14} />}
              <span>{isSpeaking ? 'Stop Voice' : '🇮🇳 Speak Scene'}</span>
            </button>

            <button
              onClick={() => {
                speechService.stop();
                soundFX.playPop();
                onClose();
              }}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Story Body */}
        <div className="p-5 sm:p-7 overflow-y-auto space-y-6">
          {/* Situation Dialogue Card */}
          <div
            onClick={() => handleSpeak(currentNode.situationText, currentNode.speaker)}
            className={`comic-panel p-5 bg-white border-2 border-slate-900 flex flex-col sm:flex-row items-center gap-5 cursor-pointer transition-all ${
              isSpeaking
                ? 'border-amber-500 ring-4 ring-amber-300/50 bg-amber-50/40 shadow-xl'
                : 'hover:border-amber-400'
            }`}
            title="Click to hear character speak with native Indian English accent"
          >
            <div className="shrink-0 transform transition-transform">
              {renderCharacter(currentNode.speaker, currentNode.mood, isSpeaking)}
            </div>
            <div className="flex-1 text-center sm:text-left space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-comic uppercase tracking-wider text-amber-700 font-black">
                  {getSpeakerLabel(currentNode.speaker)}
                </span>
                <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                  {isSpeaking ? (
                    <>
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-600 animate-ping" />
                      Speaking 🇮🇳
                    </>
                  ) : (
                    <>
                      <Volume2 size={11} /> Tap to speak 🇮🇳
                    </>
                  )}
                </span>
              </div>
              <p className="font-comic-bubble text-base sm:text-lg text-slate-900 leading-relaxed">
                "{currentNode.situationText}"
              </p>
              {isSpeaking && (
                <div className="pt-2 flex items-center gap-1 text-[11px] text-amber-800 font-mono">
                  <span className="w-1 bg-amber-600 rounded-full animate-eq-1" />
                  <span className="w-1 bg-amber-600 rounded-full animate-eq-2" />
                  <span className="w-1 bg-amber-600 rounded-full animate-eq-3" />
                  <span className="w-1 bg-amber-600 rounded-full animate-eq-4" />
                  <span className="ml-1 text-[10px]">Speaking in native Indian dialect...</span>
                </div>
              )}
            </div>
          </div>

          {/* Code Context Display if present */}
          {currentNode.codeDisplay && (
            <div className="bg-slate-900 text-emerald-300 p-3.5 rounded-xl font-mono text-xs sm:text-sm shadow-inner overflow-x-auto">
              <pre>{currentNode.codeDisplay}</pre>
            </div>
          )}

          {/* Feedback from previous choice if any */}
          {lastFeedback && (
            <div
              className={`p-3.5 rounded-xl text-xs sm:text-sm font-medium border-2 flex items-center justify-between gap-3 ${
                lastFeedback.isSuccess
                  ? 'bg-emerald-50 text-emerald-950 border-emerald-400'
                  : 'bg-rose-50 text-rose-950 border-rose-400'
              }`}
            >
              <span>{lastFeedback.text}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleSpeak(lastFeedback.text, 'pip');
                }}
                className="shrink-0 p-1 rounded-lg bg-white/80 hover:bg-white text-slate-700 text-xs flex items-center gap-1 border border-slate-300 cursor-pointer"
                title="Hear feedback spoken"
              >
                <Volume2 size={12} />
              </button>
            </div>
          )}

          {/* Decision Choices */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Sparkles size={14} className="text-amber-500" /> Choose Your Python Action:
            </h3>

            {currentNode.choices.map((choice, idx) => (
              <button
                key={idx}
                onClick={() => handleChoose(choice)}
                className="w-full text-left comic-panel p-4 bg-white hover:bg-amber-50/60 border-slate-900 transition-all cursor-pointer group"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="font-comic text-xs uppercase tracking-wider text-slate-500">
                      Option {idx + 1}
                    </div>
                    <div className="font-bold text-sm text-slate-900 group-hover:text-amber-800 transition-colors">
                      {choice.text}
                    </div>
                    {choice.pythonSnippet && (
                      <div className="bg-slate-900 text-emerald-300 p-2 rounded font-mono text-xs mt-1">
                        <code>{choice.pythonSnippet}</code>
                      </div>
                    )}
                  </div>
                  <ArrowRight
                    size={18}
                    className="text-slate-400 group-hover:text-slate-900 group-hover:translate-x-1 transition-all shrink-0 mt-1"
                  />
                </div>
              </button>
            ))}
          </div>

          {/* Restart option */}
          <div className="pt-4 border-t border-slate-200 flex justify-end">
            <button
              onClick={restartAdventure}
              className="text-xs font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw size={13} />
              <span>Restart Scenario</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
