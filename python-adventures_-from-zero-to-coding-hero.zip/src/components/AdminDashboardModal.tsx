import React, { useState } from 'react';
import { UserAccount } from '../types/auth';
import { authService, DEFAULT_ADMIN } from '../services/authService';
import { PipCharacter, AlexCharacter, ByteCharacter, BugsyCharacter } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';
import {
  ShieldCheck,
  Users,
  UserPlus,
  Trash2,
  KeyRound,
  CheckCircle,
  AlertTriangle,
  X,
  Sparkles,
  Download,
  BookOpen,
  Activity,
  Award,
  RefreshCw,
  Search,
  Lock,
  Mail,
  User,
  GraduationCap
} from 'lucide-react';

interface AdminDashboardModalProps {
  currentUser: UserAccount;
  onClose: () => void;
  onUnlockAllChapters?: () => void;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  currentUser,
  onClose,
  onUnlockAllChapters
}) => {
  const [activeTab, setActiveTab] = useState<'roster' | 'analytics' | 'diagnostics' | 'add_user'>('roster');
  const [users, setUsers] = useState<UserAccount[]>(() => authService.getAllUsers());
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedUserForPasswordReset, setSelectedUserForPasswordReset] = useState<UserAccount | null>(null);
  const [newPasswordInput, setNewPasswordInput] = useState<string>('');
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  // New User form state
  const [newName, setNewName] = useState<string>('');
  const [newEmail, setNewEmail] = useState<string>('');
  const [newPass, setNewPass] = useState<string>('');
  const [newRole, setNewRole] = useState<'student' | 'admin'>('student');
  const [newAvatar, setNewAvatar] = useState<'pip' | 'alex' | 'byte' | 'bugsy'>('alex');

  const refreshRoster = () => {
    setUsers(authService.getAllUsers());
  };

  const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 3500);
  };

  const handleDeleteUser = (userId: string, userName: string) => {
    if (userId === DEFAULT_ADMIN.id || userName === DEFAULT_ADMIN.name) {
      soundFX.playError();
      showNotification('Cannot delete primary system administrator account.', 'error');
      return;
    }

    if (window.confirm(`Are you sure you want to remove user "${userName}"?`)) {
      soundFX.playPop();
      const success = authService.deleteUser(userId);
      if (success) {
        refreshRoster();
        showNotification(`User "${userName}" has been removed.`);
      }
    }
  };

  const handleToggleRole = (userId: string) => {
    soundFX.playPop();
    const success = authService.toggleUserRole(userId);
    if (success) {
      refreshRoster();
      showNotification('User role updated successfully.');
    } else {
      showNotification('Cannot alter primary system admin role.', 'error');
    }
  };

  const handleSavePasswordReset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserForPasswordReset || !newPasswordInput.trim()) return;

    soundFX.playFanfare();
    authService.resetUserPassword(selectedUserForPasswordReset.id, newPasswordInput.trim());
    setSelectedUserForPasswordReset(null);
    setNewPasswordInput('');
    refreshRoster();
    showNotification('Password updated successfully.');
  };

  const handleCreateNewUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newEmail.trim() || !newPass.trim()) return;

    try {
      authService.addStudentDirectly({
        name: newName.trim(),
        email: newEmail.trim().toLowerCase(),
        password: newPass.trim(),
        role: newRole,
        avatarCharacter: newAvatar,
        gradeOrLevel: newRole === 'admin' ? 'Teaching Faculty' : 'Registered Student',
        enrolledChapter: 1
      });

      soundFX.playFanfare();
      refreshRoster();
      setNewName('');
      setNewEmail('');
      setNewPass('');
      setActiveTab('roster');
      showNotification(`Account created for "${newName}"!`);
    } catch (e: any) {
      soundFX.playError();
      showNotification(e.message || 'Failed to create user', 'error');
    }
  };

  const handleExportRoster = () => {
    soundFX.playPop();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(users, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `python-adventures-students-${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showNotification('Student roster downloaded as JSON file.');
  };

  const filteredUsers = users.filter((u) => {
    const q = searchTerm.toLowerCase();
    return u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || u.role.toLowerCase().includes(q);
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-fadeIn overflow-y-auto">
      <div className="comic-panel bg-white border-4 border-slate-900 shadow-2xl rounded-2xl w-full max-w-5xl my-8 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-300 p-5 border-b-4 border-slate-900 flex items-center justify-between text-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-white rounded-xl border-2 border-slate-900 flex items-center justify-center text-slate-900 shadow-md">
              <ShieldCheck size={26} className="text-amber-600" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-comic text-xl sm:text-2xl tracking-wide">
                  ADMINISTRATIVE CONTROL CONSOLE
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-black uppercase bg-slate-900 text-amber-300">
                  Role: Super Admin
                </span>
              </div>
              <div className="text-xs font-medium text-amber-950">
                Logged in as <strong>{currentUser.name}</strong> ({currentUser.email})
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              soundFX.playPop();
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-900 text-white hover:bg-slate-800 transition-colors cursor-pointer border-2 border-slate-900 shadow-sm"
            aria-label="Close Admin Console"
          >
            <X size={20} />
          </button>
        </div>

        {/* Global Notification Banner */}
        {notification && (
          <div className={`px-6 py-2.5 text-xs font-bold flex items-center gap-2 border-b-2 ${
            notification.type === 'error'
              ? 'bg-rose-100 text-rose-900 border-rose-300'
              : 'bg-emerald-100 text-emerald-900 border-emerald-300'
          }`}>
            {notification.type === 'error' ? <AlertTriangle size={16} /> : <CheckCircle size={16} />}
            <span>{notification.message}</span>
          </div>
        )}

        {/* Console Navigation Tabs */}
        <div className="bg-slate-100 px-6 py-3 border-b-2 border-slate-300 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                soundFX.playPop();
                setActiveTab('roster');
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-comic font-black uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'roster'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Users size={14} />
              <span>Learner Roster ({users.length})</span>
            </button>

            <button
              onClick={() => {
                soundFX.playPop();
                setActiveTab('add_user');
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-comic font-black uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'add_user'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-700 hover:bg-slate-200'
              }`}
            >
              <UserPlus size={14} />
              <span>Add Account</span>
            </button>

            <button
              onClick={() => {
                soundFX.playPop();
                setActiveTab('analytics');
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-comic font-black uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'analytics'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Award size={14} />
              <span>Course Analytics</span>
            </button>

            <button
              onClick={() => {
                soundFX.playPop();
                setActiveTab('diagnostics');
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-comic font-black uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'diagnostics'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Activity size={14} />
              <span>Diagnostics</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportRoster}
              className="px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="Download Student Roster JSON"
            >
              <Download size={13} />
              <span>Export Roster</span>
            </button>
          </div>
        </div>

        {/* Tab Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: ROSTER VIEW */}
          {activeTab === 'roster' && (
            <div className="space-y-4">
              {/* Search & Stats Bar */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="relative w-full sm:w-72">
                  <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search by name, email, or role..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border-2 border-slate-300 focus:border-slate-900 focus:outline-hidden"
                  />
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-600">
                  <span className="font-bold">Total Accounts:</span>
                  <span className="bg-slate-200 px-2 py-0.5 rounded-md font-mono text-slate-900 font-bold">
                    {users.length}
                  </span>
                  <span>•</span>
                  <span>Admins:</span>
                  <span className="bg-amber-100 text-amber-900 px-2 py-0.5 rounded-md font-mono font-bold">
                    {users.filter(u => u.role === 'admin').length}
                  </span>
                  <span>•</span>
                  <span>Students:</span>
                  <span className="bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded-md font-mono font-bold">
                    {users.filter(u => u.role === 'student').length}
                  </span>
                </div>
              </div>

              {/* Roster Table */}
              <div className="border-2 border-slate-900 rounded-xl overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-900 text-amber-300 uppercase font-comic text-[11px] tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Learner / Staff</th>
                      <th className="py-3 px-4">Email ID</th>
                      <th className="py-3 px-4">Role</th>
                      <th className="py-3 px-4">Level / School</th>
                      <th className="py-3 px-4">Registered Date</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 bg-white">
                    {filteredUsers.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-8 text-center text-slate-400 font-comic">
                          No users found matching your search.
                        </td>
                      </tr>
                    ) : (
                      filteredUsers.map((user) => {
                        const isMainAdmin = user.email.toLowerCase() === DEFAULT_ADMIN.email.toLowerCase();
                        return (
                          <tr key={user.id} className="hover:bg-slate-50 transition-colors">
                            <td className="py-3 px-4 font-bold text-slate-900 flex items-center gap-2">
                              <span className="p-1 rounded-md bg-slate-100 border border-slate-300">
                                {user.avatarCharacter === 'pip' && <PipCharacter mood="happy" size={20} />}
                                {user.avatarCharacter === 'byte' && <ByteCharacter mood="happy" size={20} />}
                                {user.avatarCharacter === 'bugsy' && <BugsyCharacter mood="happy" size={20} />}
                                {(!user.avatarCharacter || user.avatarCharacter === 'alex') && (
                                  <AlexCharacter mood="happy" size={20} />
                                )}
                              </span>
                              <span>{user.name}</span>
                              {isMainAdmin && (
                                <span className="text-[10px] bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded font-black">
                                  MASTER
                                </span>
                              )}
                            </td>
                            <td className="py-3 px-4 font-mono text-slate-700">
                              {user.email}
                            </td>
                            <td className="py-3 px-4">
                              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full font-bold text-[10px] uppercase ${
                                user.role === 'admin'
                                  ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                  : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                              }`}>
                                {user.role === 'admin' ? '🛡️ Admin' : '🎓 Student'}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-slate-600">
                              {user.gradeOrLevel || 'Python Adventurer'}
                            </td>
                            <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                              {new Date(user.createdAt).toLocaleDateString()}
                            </td>
                            <td className="py-3 px-4 text-right space-x-1.5">
                              {/* Reset Password */}
                              <button
                                onClick={() => {
                                  soundFX.playPop();
                                  setSelectedUserForPasswordReset(user);
                                  setNewPasswordInput('');
                                }}
                                className="p-1.5 rounded-lg border border-slate-200 hover:bg-amber-50 hover:text-amber-700 text-slate-600 transition-colors cursor-pointer"
                                title="Reset Password"
                              >
                                <KeyRound size={14} />
                              </button>

                              {/* Toggle Role */}
                              {!isMainAdmin && (
                                <button
                                  onClick={() => handleToggleRole(user.id)}
                                  className="p-1.5 rounded-lg border border-slate-200 hover:bg-sky-50 hover:text-sky-700 text-slate-600 transition-colors cursor-pointer"
                                  title={`Switch to ${user.role === 'admin' ? 'Student' : 'Admin'}`}
                                >
                                  <RefreshCw size={14} />
                                </button>
                              )}

                              {/* Delete User */}
                              {!isMainAdmin && (
                                <button
                                  onClick={() => handleDeleteUser(user.id, user.name)}
                                  className="p-1.5 rounded-lg border border-slate-200 hover:bg-rose-50 hover:text-rose-700 text-slate-600 transition-colors cursor-pointer"
                                  title="Delete Account"
                                >
                                  <Trash2 size={14} />
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: ADD USER FORM */}
          {activeTab === 'add_user' && (
            <div className="comic-panel p-6 bg-slate-50 border-2 border-slate-900 rounded-xl max-w-2xl mx-auto space-y-4">
              <div className="space-y-1">
                <h3 className="font-comic text-xl text-slate-900">
                  Register New Student or Administrative Account
                </h3>
                <p className="text-xs text-slate-600">
                  Add custom enrolled learners directly into the local learning database.
                </p>
              </div>

              <form onSubmit={handleCreateNewUser} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="block text-xs font-comic font-black uppercase text-slate-700">
                      Full Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Vikram Malhotra"
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg border-2 border-slate-300 focus:border-slate-900 focus:outline-hidden bg-white"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-comic font-black uppercase text-slate-700">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="vikram@school.edu.in"
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg border-2 border-slate-300 focus:border-slate-900 focus:outline-hidden bg-white"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-comic font-black uppercase text-slate-700">
                      Temporary Password
                    </label>
                    <input
                      type="password"
                      required
                      placeholder="Minimum 6 characters"
                      value={newPass}
                      onChange={(e) => setNewPass(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg border-2 border-slate-300 focus:border-slate-900 focus:outline-hidden bg-white"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-comic font-black uppercase text-slate-700">
                      Account Role
                    </label>
                    <select
                      value={newRole}
                      onChange={(e) => setNewRole(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs rounded-lg border-2 border-slate-300 focus:border-slate-900 focus:outline-hidden bg-white font-medium"
                    >
                      <option value="student">🎓 Student Learner</option>
                      <option value="admin">🛡️ System Administrator</option>
                    </select>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="submit"
                    className="comic-button px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs sm:text-sm rounded-xl flex items-center gap-2 cursor-pointer shadow-md"
                  >
                    <UserPlus size={15} />
                    <span>Create & Enroll User</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 3: COURSE ANALYTICS */}
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="comic-panel p-4 bg-amber-50 border-2 border-slate-900 rounded-xl space-y-1">
                  <div className="text-xs font-comic font-black uppercase text-amber-800">
                    Enrolled Students
                  </div>
                  <div className="font-comic text-3xl text-slate-900">
                    {users.filter(u => u.role === 'student').length}
                  </div>
                  <div className="text-[11px] text-slate-500">Across 20 Python chapters</div>
                </div>

                <div className="comic-panel p-4 bg-emerald-50 border-2 border-slate-900 rounded-xl space-y-1">
                  <div className="text-xs font-comic font-black uppercase text-emerald-800">
                    Curriculum Scope
                  </div>
                  <div className="font-comic text-3xl text-slate-900">20 Ch</div>
                  <div className="text-[11px] text-slate-500">From Print to OOP & AI</div>
                </div>

                <div className="comic-panel p-4 bg-sky-50 border-2 border-slate-900 rounded-xl space-y-1">
                  <div className="text-xs font-comic font-black uppercase text-sky-800">
                    Interactive Modules
                  </div>
                  <div className="font-comic text-3xl text-slate-900">80+</div>
                  <div className="text-[11px] text-slate-500">Quizzes, Labs, Projects</div>
                </div>

                <div className="comic-panel p-4 bg-purple-50 border-2 border-slate-900 rounded-xl space-y-1">
                  <div className="text-xs font-comic font-black uppercase text-purple-800">
                    Voice Narration
                  </div>
                  <div className="font-comic text-3xl text-slate-900">en-IN</div>
                  <div className="text-[11px] text-slate-500">Native Indian Dialect</div>
                </div>
              </div>

              {/* Course Unlock Controls */}
              <div className="comic-panel p-5 bg-gradient-to-r from-amber-100 to-yellow-100 border-2 border-slate-900 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="space-y-1 text-center sm:text-left">
                  <h4 className="font-comic text-base text-slate-900 flex items-center gap-2 justify-center sm:justify-start">
                    <Sparkles size={18} className="text-amber-600" />
                    <span>Administrator Override: Instant Curriculum Grant</span>
                  </h4>
                  <p className="text-xs text-slate-700">
                    Need to demonstrate all 20 chapters for curriculum review or evaluation? Unlock all lessons instantly.
                  </p>
                </div>

                {onUnlockAllChapters && (
                  <button
                    onClick={() => {
                      soundFX.playFanfare();
                      onUnlockAllChapters();
                      showNotification('All 20 chapters and milestone badges unlocked!');
                    }}
                    className="shrink-0 comic-button px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs sm:text-sm rounded-xl flex items-center gap-2 shadow-md cursor-pointer border-2 border-slate-900"
                  >
                    <Award size={16} />
                    <span>Unlock All 20 Chapters</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: DIAGNOSTICS */}
          {activeTab === 'diagnostics' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="comic-panel p-4 bg-white border-2 border-slate-900 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-comic text-sm text-slate-900">Python Runtime Engine</span>
                    <span className="text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                      ONLINE
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Pure in-browser JavaScript sandbox with real-time output capturing and syntax error parsing.
                  </p>
                </div>

                <div className="comic-panel p-4 bg-white border-2 border-slate-900 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-comic text-sm text-slate-900">Code Replay Studio</span>
                    <span className="text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                      ONLINE
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    AST line-by-line tracer with variable memory snapshots and Indian voice walkthrough commentary.
                  </p>
                </div>

                <div className="comic-panel p-4 bg-white border-2 border-slate-900 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-comic text-sm text-slate-900">Separated Character Voices</span>
                    <span className="text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                      MULTI-TIMBRE
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Alex (15yo boy, pitch 1.28) • Pip (deep noble baritone, pitch 0.66) • Byte (comic robot with square-wave chirps, pitch 0.52).
                  </p>
                </div>

                <div className="comic-panel p-4 bg-white border-2 border-slate-900 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-comic text-sm text-slate-900">Local Auth Storage</span>
                    <span className="text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                      PERSISTENT
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Admin credentials <code>deepikanavneetsingh@gmail.com</code> safely seeded and validated.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-100 px-6 py-3 border-t-2 border-slate-300 flex items-center justify-between text-xs text-slate-500">
          <span>Python Adventures Administrator Console v2.0</span>
          <button
            onClick={() => {
              soundFX.playPop();
              onClose();
            }}
            className="comic-button px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg cursor-pointer"
          >
            Close Console
          </button>
        </div>
      </div>

      {/* Password Reset Submodal */}
      {selectedUserForPasswordReset && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/70">
          <div className="comic-panel bg-white border-4 border-slate-900 rounded-2xl p-6 w-full max-w-md space-y-4 shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between">
              <h4 className="font-comic text-lg text-slate-900 flex items-center gap-2">
                <KeyRound size={18} className="text-amber-600" />
                <span>Reset Password</span>
              </h4>
              <button
                onClick={() => setSelectedUserForPasswordReset(null)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Set a new password for <strong>{selectedUserForPasswordReset.name}</strong> ({selectedUserForPasswordReset.email}):
            </p>

            <form onSubmit={handleSavePasswordReset} className="space-y-3">
              <input
                type="text"
                required
                minLength={6}
                placeholder="Enter new password (min 6 characters)"
                value={newPasswordInput}
                onChange={(e) => setNewPasswordInput(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border-2 border-slate-300 focus:border-slate-900 focus:outline-hidden font-mono"
              />

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedUserForPasswordReset(null)}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="comic-button px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg cursor-pointer"
                >
                  Save New Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
