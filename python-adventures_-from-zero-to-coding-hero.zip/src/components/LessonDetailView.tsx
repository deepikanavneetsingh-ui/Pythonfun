import React, { useState, useEffect } from 'react';
import { Chapter, Lesson } from '../types/curriculum';
import { PipCharacter, AlexCharacter, ByteCharacter, BugsyCharacter } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';
import { speechService } from '../utils/speechService';
import {
  BookOpen,
  Code2,
  CheckCircle2,
  HelpCircle,
  Lightbulb,
  AlertTriangle,
  Play,
  RotateCcw,
  Sparkles,
  ArrowRight,
  Bookmark,
  Volume2,
  Square
} from 'lucide-react';

interface LessonDetailProps {
  chapter: Chapter;
  lesson: Lesson;
  onOpenPlayground: (code: string) => void;
  onCompleteLesson: (lessonId: string, chapterNumber: number) => void;
  isCompleted: boolean;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
  onGoToComic: () => void;
  onNextLesson?: () => void;
}

export const LessonDetailView: React.FC<LessonDetailProps> = ({
  chapter,
  lesson,
  onOpenPlayground,
  onCompleteLesson,
  isCompleted,
  isBookmarked,
  onToggleBookmark,
  onGoToComic,
  onNextLesson
}) => {
  // Prediction question state
  const [selectedPrediction, setSelectedPrediction] = useState<number | null>(null);
  const [predictionSubmitted, setPredictionSubmitted] = useState<boolean>(false);

  // Practice challenge hints state
  const [hintStage, setHintStage] = useState<number>(0);
  const [showSolution, setShowSolution] = useState<boolean>(false);

  const isPredictionCorrect =
    predictionSubmitted && selectedPrediction === lesson.prediction.correctIndex;

  const handlePredictSubmit = () => {
    if (selectedPrediction === null) return;
    setPredictionSubmitted(true);
    if (selectedPrediction === lesson.prediction.correctIndex) {
      soundFX.playSuccess();
    } else {
      soundFX.playBugZap();
    }
  };

  // Active character speaking state
  const [activeSpeaker, setActiveSpeaker] = useState<string | null>(null);

  useEffect(() => {
    return () => {
      speechService.stop();
    };
  }, [lesson.id]);

  const speakCharacter = (text: string, speaker: 'pip' | 'alex' | 'byte' | 'bugsy', id: string) => {
    if (activeSpeaker === id) {
      speechService.stop();
      setActiveSpeaker(null);
      return;
    }
    soundFX.playPop();
    setActiveSpeaker(id);
    speechService.speak(
      text,
      speaker,
      id,
      () => setActiveSpeaker(id),
      () => setActiveSpeaker((curr) => (curr === id ? null : curr)),
      () => setActiveSpeaker(null)
    );
  };

  const handleFinishLesson = () => {
    onCompleteLesson(lesson.id, chapter.number);
    speakCharacter(
      `Congratulations! You have completed Lesson ${lesson.lessonNumber}: ${lesson.title}! Keep up the outstanding momentum!`,
      'alex',
      'alex-complete'
    );
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto pb-12">
      {/* 1. Header Bar */}
      <div className="bg-white p-6 rounded-2xl border-2 border-slate-900 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-700 uppercase tracking-widest">
            <span>Chapter {chapter.number}</span>
            <span>•</span>
            <span>Lesson {lesson.lessonNumber}</span>
          </div>
          <h1 className="font-comic text-2xl sm:text-3xl text-slate-900 mt-1">
            {lesson.title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 font-medium mt-1">
            🎯 Learning Objective: {lesson.objective}
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={onToggleBookmark}
            className={`p-2 rounded-xl border-2 transition-all ${
              isBookmarked
                ? 'bg-amber-100 border-amber-500 text-amber-900'
                : 'bg-white border-slate-300 text-slate-500 hover:border-slate-800'
            }`}
            title="Bookmark lesson"
          >
            <Bookmark size={18} className={isBookmarked ? 'fill-amber-500' : ''} />
          </button>

          <button
            onClick={onGoToComic}
            className="comic-button px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-1.5"
          >
            <BookOpen size={15} /> Comic Panels
          </button>
        </div>
      </div>

      {/* 2. Real-Life Problem & Analogy */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Real-life problem */}
        <div className="comic-panel p-5 bg-amber-50/60 border-amber-900">
          <div className="flex items-center gap-2 text-xs font-comic uppercase tracking-wider text-amber-900 mb-2">
            <Lightbulb size={16} className="text-amber-600" /> Real-Life Everyday Problem
          </div>
          <p className="text-xs sm:text-sm text-slate-800 leading-relaxed">
            {lesson.realLifeProblem}
          </p>
        </div>

        {/* Visual Analogy */}
        <div className="comic-panel p-5 bg-teal-50/60 border-teal-900">
          <div className="flex items-center gap-2 text-xs font-comic uppercase tracking-wider text-teal-900 mb-2">
            <span className="text-base">{lesson.analogy.icon}</span> {lesson.analogy.title}
          </div>
          <p className="text-xs sm:text-sm text-slate-800 leading-relaxed">
            {lesson.analogy.description}
          </p>
        </div>
      </div>

      {/* 3. Concept Explanation Prose */}
      <div className="comic-panel p-6 sm:p-7 bg-white">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <h2 className="font-comic text-lg sm:text-xl text-slate-900 flex items-center gap-2">
            <Sparkles size={20} className="text-amber-500" /> Core Programming Concept
          </h2>
          <button
            onClick={() => speakCharacter(lesson.conceptText, 'pip', 'pip-concept')}
            className={`comic-button px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer self-start sm:self-auto ${
              activeSpeaker === 'pip-concept' ? 'bg-rose-500 text-white' : 'bg-emerald-400 hover:bg-emerald-300 text-slate-900'
            }`}
          >
            {activeSpeaker === 'pip-concept' ? <Square size={12} className="fill-white" /> : <Volume2 size={13} />}
            <span>{activeSpeaker === 'pip-concept' ? 'Stop Voice' : '🇮🇳 Pip Speaks'}</span>
          </button>
        </div>

        <div className="flex items-start gap-4">
          <PipCharacter
            mood="explaining"
            size={65}
            isSpeaking={activeSpeaker === 'pip-concept'}
            className="shrink-0 hidden sm:inline-block"
          />
          <div className="flex-1">
            <p className="text-sm sm:text-base text-slate-800 leading-relaxed">
              {lesson.conceptText}
            </p>
            {activeSpeaker === 'pip-concept' && (
              <div className="mt-2 flex items-center gap-1 text-[11px] text-emerald-800 font-mono">
                <span className="w-1 bg-emerald-600 rounded-full animate-eq-1" />
                <span className="w-1 bg-emerald-600 rounded-full animate-eq-2" />
                <span className="w-1 bg-emerald-600 rounded-full animate-eq-3" />
                <span className="w-1 bg-emerald-600 rounded-full animate-eq-4" />
                <span className="ml-1 text-[10px]">Pip speaking in native Indian English dialect...</span>
              </div>
            )}
          </div>
        </div>

        {/* Syntax Rules Pill List */}
        <div className="mt-5 pt-4 border-t border-slate-200">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2.5">
            Key Python Rules to Remember:
          </h3>
          <ul className="space-y-2">
            {lesson.syntaxRules.map((rule, idx) => (
              <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0 text-xs mt-0.5">
                  {idx + 1}
                </span>
                <span>{rule}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* 4. Worked Python Example */}
      <div className="comic-panel overflow-hidden border-slate-900">
        <div className="bg-[#1E293B] text-white px-5 py-3 flex items-center justify-between border-b-2 border-slate-700">
          <div className="flex items-center gap-2">
            <Code2 size={18} className="text-amber-400" />
            <span className="font-comic text-sm tracking-wide">
              {lesson.workedExample.title}
            </span>
          </div>

          <button
            onClick={() => onOpenPlayground(lesson.workedExample.code)}
            className="comic-button px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-900 text-xs font-extrabold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <Play size={13} className="fill-slate-900" /> Run in Playground
          </button>
        </div>

        {/* Code Box */}
        <div className="bg-[#0F172A] p-4 text-emerald-300 font-mono text-xs sm:text-sm overflow-x-auto leading-relaxed">
          <pre>{lesson.workedExample.code}</pre>
        </div>

        {/* Expected Output */}
        <div className="bg-slate-100 p-4 border-t border-slate-300">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
            Expected Screen Output:
          </div>
          <pre className="p-2.5 bg-white border border-slate-300 rounded font-mono text-xs text-slate-800 whitespace-pre-wrap">
            {lesson.workedExample.expectedOutput}
          </pre>
        </div>

        {/* Line-by-Line Breakdown */}
        <div className="p-5 bg-white border-t border-slate-200">
          <h4 className="font-comic text-xs uppercase tracking-wider text-slate-900 mb-3">
            Line-by-Line Code Breakdown:
          </h4>
          <div className="space-y-2">
            {lesson.workedExample.lineByLine.map((lineItem, idx) => (
              <div
                key={idx}
                className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
              >
                <div className="font-mono font-bold text-slate-800 bg-slate-200 px-2 py-0.5 rounded shrink-0">
                  Line {lineItem.line}: {lineItem.code}
                </div>
                <div className="text-slate-600 font-sans">{lineItem.explanation}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 5. Interactive Prediction Question */}
      <div className="comic-panel p-6 bg-amber-50/50 border-amber-900 space-y-4">
        <div className="flex items-center gap-2">
          <ByteCharacter mood="thinking" size={42} />
          <div>
            <div className="text-[11px] font-comic uppercase tracking-wider text-amber-900">
              Byte\'s Prediction Challenge
            </div>
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              {lesson.prediction.question}
            </h3>
          </div>
        </div>

        {lesson.prediction.codeSnippet && (
          <div className="bg-slate-900 text-emerald-300 p-3 rounded-lg font-mono text-xs overflow-x-auto">
            <pre>{lesson.prediction.codeSnippet}</pre>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {lesson.prediction.options.map((opt, idx) => {
            const isSelected = selectedPrediction === idx;
            let style = 'bg-white border-2 border-slate-300 text-slate-800 hover:border-slate-800';

            if (predictionSubmitted) {
              if (idx === lesson.prediction.correctIndex) {
                style = 'bg-emerald-100 border-2 border-emerald-600 text-emerald-950 font-bold';
              } else if (isSelected) {
                style = 'bg-rose-100 border-2 border-rose-500 text-rose-950';
              } else {
                style = 'bg-slate-50 border-slate-200 text-slate-400 opacity-60';
              }
            } else if (isSelected) {
              style = 'bg-amber-100 border-2 border-amber-500 text-amber-950 font-bold';
            }

            return (
              <button
                key={idx}
                onClick={() => {
                  if (predictionSubmitted) return;
                  soundFX.playPop();
                  setSelectedPrediction(idx);
                }}
                disabled={predictionSubmitted}
                className={`p-3 rounded-xl text-left text-xs sm:text-sm transition-all cursor-pointer ${style}`}
              >
                {opt}
              </button>
            );
          })}
        </div>

        {!predictionSubmitted ? (
          <button
            onClick={handlePredictSubmit}
            disabled={selectedPrediction === null}
            className="comic-button px-5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-900 font-extrabold text-xs rounded-xl disabled:opacity-40"
          >
            Confirm Prediction
          </button>
        ) : (
          <div
            className={`p-3.5 rounded-xl text-xs ${
              isPredictionCorrect
                ? 'bg-emerald-100 text-emerald-950 border border-emerald-400'
                : 'bg-rose-100 text-rose-950 border border-rose-400'
            }`}
          >
            <div className="font-bold mb-0.5">
              {isPredictionCorrect ? 'Spot on! Correct execution prediction.' : 'Misconception spotted:'}
            </div>
            <div>{lesson.prediction.explanation}</div>
          </div>
        )}
      </div>

      {/* 6. Guided Practice Challenge */}
      <div className="comic-panel p-6 bg-white border-slate-900 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] font-comic uppercase tracking-wider text-emerald-700">
              Interactive Coding Exercise
            </span>
            <h3 className="font-comic text-base sm:text-lg text-slate-900">
              {lesson.practiceChallenge.title}
            </h3>
          </div>

          <button
            onClick={() => onOpenPlayground(lesson.practiceChallenge.starterCode)}
            className="comic-button px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <Code2 size={15} /> Code in Playground
          </button>
        </div>

        <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-medium">
          {lesson.practiceChallenge.prompt}
        </p>

        {/* Starter Code Box */}
        <div className="bg-slate-900 text-emerald-300 p-3 rounded-lg font-mono text-xs overflow-x-auto">
          <pre>{lesson.practiceChallenge.starterCode}</pre>
        </div>

        {/* 3 Hints Accordion */}
        <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-700 flex items-center gap-1">
              <HelpCircle size={14} /> Need a hint?
            </span>
            <button
              onClick={() => {
                soundFX.playPop();
                setHintStage((prev) => Math.min(prev + 1, 3));
              }}
              disabled={hintStage >= 3}
              className="text-amber-700 hover:text-amber-800 font-bold"
            >
              {hintStage === 0 ? 'Reveal Hint 1' : hintStage === 1 ? 'Reveal Hint 2' : hintStage === 2 ? 'Reveal Hint 3' : 'All Hints Unlocked'}
            </button>
          </div>

          {hintStage >= 1 && (
            <div className="p-2 bg-amber-50 rounded border border-amber-200 text-amber-900">
              <span className="font-bold">Hint 1:</span> {lesson.practiceChallenge.hints[0]}
            </div>
          )}
          {hintStage >= 2 && (
            <div className="p-2 bg-amber-50 rounded border border-amber-200 text-amber-900">
              <span className="font-bold">Hint 2:</span> {lesson.practiceChallenge.hints[1]}
            </div>
          )}
          {hintStage >= 3 && (
            <div className="p-2 bg-amber-50 rounded border border-amber-200 text-amber-900">
              <span className="font-bold">Hint 3:</span> {lesson.practiceChallenge.hints[2]}
            </div>
          )}

          {/* Reveal Solution Button */}
          <div className="pt-2 flex items-center justify-between">
            <button
              onClick={() => {
                soundFX.playPop();
                setShowSolution(!showSolution);
              }}
              className="text-slate-500 hover:text-slate-800 font-medium"
            >
              {showSolution ? 'Hide Solution' : 'Reveal Solution'}
            </button>
          </div>

          {showSolution && (
            <div className="p-3 bg-emerald-50 rounded border border-emerald-300 text-emerald-950 font-mono">
              <div className="font-bold text-emerald-800 mb-1">Official Solution:</div>
              <pre className="whitespace-pre-wrap">{lesson.practiceChallenge.solutionCode}</pre>
            </div>
          )}
        </div>
      </div>

      {/* 7. Common Mistake Comparison */}
      <div className="comic-panel p-6 bg-rose-50/50 border-rose-900 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <BugsyCharacter
              mood="thinking"
              size={56}
              isSpeaking={activeSpeaker === 'bugsy-mistake'}
            />
            <div>
              <div className="text-[11px] font-comic uppercase tracking-wider text-rose-900">
                Bugsy's Watchlist: Common Mistake
              </div>
              <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                {lesson.commonMistake.title}
              </h3>
            </div>
          </div>

          <button
            onClick={() =>
              speakCharacter(
                `Watch out for this common mistake: ${lesson.commonMistake.title}! Why it fails: ${lesson.commonMistake.whyItFails}. Pro tip: ${lesson.commonMistake.tip}`,
                'bugsy',
                'bugsy-mistake'
              )
            }
            className={`comic-button px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer self-start sm:self-auto shrink-0 ${
              activeSpeaker === 'bugsy-mistake'
                ? 'bg-rose-500 text-white animate-pulse'
                : 'bg-purple-600 hover:bg-purple-500 text-white'
            }`}
          >
            {activeSpeaker === 'bugsy-mistake' ? <Square size={12} className="fill-white" /> : <Volume2 size={13} />}
            <span>{activeSpeaker === 'bugsy-mistake' ? 'Stop Bugsy' : '🇮🇳 Bugsy Explains'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-3 bg-white border-2 border-rose-300 rounded-xl space-y-1">
            <div className="text-xs font-bold text-rose-700 flex items-center gap-1">
              <AlertTriangle size={14} /> Incorrect Syntax:
            </div>
            <pre className="p-2 bg-rose-50 rounded text-rose-900 font-mono text-xs overflow-x-auto">
              {lesson.commonMistake.badCode}
            </pre>
            <p className="text-[11px] text-rose-800 mt-1">{lesson.commonMistake.whyItFails}</p>
          </div>

          <div className="p-3 bg-white border-2 border-emerald-300 rounded-xl space-y-1">
            <div className="text-xs font-bold text-emerald-700 flex items-center gap-1">
              <CheckCircle2 size={14} /> Correct Syntax:
            </div>
            <pre className="p-2 bg-emerald-50 rounded text-emerald-900 font-mono text-xs overflow-x-auto">
              {lesson.commonMistake.fixedCode}
            </pre>
            <p className="text-[11px] text-emerald-800 mt-1">{lesson.commonMistake.tip}</p>
          </div>
        </div>
      </div>

      {/* 8. 3 Key Takeaways Recap */}
      <div className="comic-panel p-6 bg-slate-900 text-white space-y-3">
        <h3 className="font-comic text-sm uppercase tracking-wider text-amber-400 flex items-center gap-2">
          <Sparkles size={16} /> 3 Key Takeaways from This Lesson
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {lesson.threeKeyTakeaways.map((takeaway, idx) => (
            <div key={idx} className="p-3 bg-slate-800 rounded-xl border border-slate-700 text-xs">
              <span className="font-comic text-amber-400 mr-1.5">{idx + 1}.</span>
              <span className="text-slate-200">{takeaway}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 9. Completion Bar */}
      <div className="comic-panel p-6 bg-white border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div
          onClick={() =>
            speakCharacter(
              isCompleted
                ? `Lesson ${lesson.lessonNumber} mastered! Fantastic job on ${lesson.title}!`
                : `Ready to master Lesson ${lesson.lessonNumber}: ${lesson.title}? Finish the exercise and click complete!`,
              'alex',
              'alex-complete'
            )
          }
          className="flex items-center gap-3 cursor-pointer group"
          title="Click to hear Alex speak"
        >
          <AlexCharacter
            mood={isCompleted ? 'happy' : 'coding'}
            size={55}
            isSpeaking={activeSpeaker === 'alex-complete'}
          />
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-comic text-base text-slate-900 group-hover:text-amber-700 transition-colors">
                {isCompleted ? 'Lesson Mastered!' : 'Ready to mark this lesson complete?'}
              </h4>
              <span className="text-[10px] text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded-full flex items-center gap-1">
                <Volume2 size={10} />
                {activeSpeaker === 'alex-complete' ? 'Alex Speaking 🇮🇳' : 'Hear Alex 🇮🇳'}
              </span>
            </div>
            <p className="text-xs text-slate-600">
              {isCompleted
                ? 'Great progress! Your mastery is recorded in your hero journal.'
                : 'Complete the prediction or run the code example to advance your hero stats!'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {!isCompleted ? (
            <button
              onClick={handleFinishLesson}
              className="comic-button px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <CheckCircle2 size={16} /> Mark Lesson Completed
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-emerald-700 text-xs font-bold flex items-center gap-1">
                <CheckCircle2 size={16} /> Completed
              </span>
              {onNextLesson && (
                <button
                  onClick={onNextLesson}
                  className="comic-button px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-900 font-extrabold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <span>Next Lesson</span>
                  <ArrowRight size={15} />
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
