import React, { useState, useRef, useEffect } from 'react';
import { Play, RotateCcw, Copy, Check, Terminal, X, Sparkles, AlertCircle, MessageSquare, Volume2, Square, Film } from 'lucide-react';
import { pythonRunner, RunResult } from '../runtime/pythonRunner';
import { codeTracer, ReplayTraceResult } from '../runtime/codeTracer';
import { CodeReplayViewer } from './CodeReplayViewer';
import { PipCharacter, BugsyCharacter, ByteCharacter } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';
import { speechService } from '../utils/speechService';

interface PlaygroundProps {
  initialCode?: string;
  onClose?: () => void;
  isModal?: boolean;
  title?: string;
}

const STARTER_PRESETS: { title: string; code: string }[] = [
  {
    title: '1. Hello World',
    code: `# Welcome to the Python Adventures Playground!
print("Hello, Python Adventurer!")
print("Byte and Pip are ready to run your code.")`
  },
  {
    title: '2. Variables & Calculations',
    code: `hero_name = "Alex"
level = 5
coins = 50 + 25

print(f"Hero: {hero_name} | Level: {level}")
print(f"Total Gold: {coins} coins")`
  },
  {
    title: '3. Interactive input()',
    code: `name = input("What is your name? ")
age = int(input("How old are you? "))
future_age = age + 1

print(f"Greetings, {name}!")
print(f"Next year you will be {future_age} years old.")`
  },
  {
    title: '4. Decision (if / else)',
    code: `score = 85

if score >= 90:
    print("Rank: S Tier (Legendary!)")
elif score >= 70:
    print("Rank: A Tier (Master!)")
else:
    print("Rank: B Tier (Keep questing!)")`
  },
  {
    title: '5. Loop (Countdown)',
    code: `print("Initiating launch sequence...")
for count in range(5, 0, -1):
    print(f"T-minus {count}...")

print("BLAST OFF! 🚀")`
  },
  {
    title: '6. Lists & Collections',
    code: `loot_bag = ["Sword", "Shield"]
loot_bag.append("Magic Potion")

print(f"Bag contains {len(loot_bag)} items:")
for item in loot_bag:
    print(f" * {item}")`
  },
  {
    title: '7. Custom Function',
    code: `def calculate_heal(base_heal, magic_bonus):
    return base_heal + (magic_bonus * 2)

hp_gained = calculate_heal(20, 5)
print(f"Spell cast! Restored {hp_gained} Health Points.")`
  }
];

export const PlaygroundModal: React.FC<PlaygroundProps> = ({
  initialCode = STARTER_PRESETS[0].code,
  onClose,
  isModal = true,
  title = 'Python Interactive Playground'
}) => {
  const [code, setCode] = useState<string>(initialCode);
  const [output, setOutput] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [beginnerTip, setBeginnerTip] = useState<string | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [activePreset, setActivePreset] = useState<number>(0);

  // Interactive input() state
  const [inputPrompt, setInputPrompt] = useState<string | null>(null);
  const [userInputValue, setUserInputValue] = useState<string>('');
  const inputResolverRef = useRef<((val: string) => void) | null>(null);
  const inputFieldRef = useRef<HTMLInputElement>(null);

  // Code Replay state
  const [isReplayMode, setIsReplayMode] = useState<boolean>(false);
  const [traceResult, setTraceResult] = useState<ReplayTraceResult | null>(null);
  const [isTracing, setIsTracing] = useState<boolean>(false);

  const [speakingId, setSpeakingId] = useState<string | null>(null);

  const startCodeReplay = async () => {
    speechService.stop();
    setSpeakingId(null);
    setIsTracing(true);
    soundFX.playPop();

    try {
      const trace = await codeTracer.trace(code);
      setTraceResult(trace);
      setIsReplayMode(true);
      soundFX.playFanfare();
    } catch (err: any) {
      setError(String(err));
      soundFX.playBugZap();
    } finally {
      setIsTracing(false);
    }
  };

  useEffect(() => {
    return () => {
      speechService.stop();
    };
  }, []);

  const speakText = (text: string, speaker: 'pip' | 'alex' | 'byte' | 'bugsy', id: string) => {
    if (speakingId === id) {
      speechService.stop();
      setSpeakingId(null);
      return;
    }
    soundFX.playPop();
    setSpeakingId(id);
    speechService.speak(
      text,
      speaker,
      id,
      () => setSpeakingId(id),
      () => setSpeakingId((curr) => (curr === id ? null : curr)),
      () => setSpeakingId(null)
    );
  };

  useEffect(() => {
    if (initialCode) {
      setCode(initialCode);
    }
  }, [initialCode]);

  useEffect(() => {
    if (inputPrompt && inputFieldRef.current) {
      inputFieldRef.current.focus();
    }
  }, [inputPrompt]);

  const handlePrompt = (promptText: string): Promise<string> => {
    return new Promise((resolve) => {
      setInputPrompt(promptText || 'Enter input: ');
      setUserInputValue('');
      inputResolverRef.current = resolve;
    });
  };

  const handleInputSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputResolverRef.current) {
      soundFX.playPop();
      inputResolverRef.current(userInputValue);
      inputResolverRef.current = null;
      setInputPrompt(null);
    }
  };

  const runCode = async () => {
    setIsRunning(true);
    setError(null);
    setBeginnerTip(null);
    setOutput('');
    soundFX.playPop();

    try {
      const result: RunResult = await pythonRunner.execute(code, handlePrompt);
      if (result.error) {
        setError(result.error);
        setBeginnerTip(result.beginnerTip || null);
        soundFX.playBugZap();
      } else {
        setOutput(result.output);
        soundFX.playSuccess();
      }
    } catch (err: any) {
      setError(String(err));
      soundFX.playBugZap();
    } finally {
      setIsRunning(false);
    }
  };

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    soundFX.playPop();
    setTimeout(() => setCopied(false), 2000);
  };

  const resetCode = () => {
    setCode(STARTER_PRESETS[activePreset].code);
    setOutput('');
    setError(null);
    setBeginnerTip(null);
    soundFX.playPop();
  };

  const selectPreset = (index: number) => {
    setActivePreset(index);
    setCode(STARTER_PRESETS[index].code);
    setOutput('');
    setError(null);
    setBeginnerTip(null);
    soundFX.playPop();
  };

  const lineCount = code.split('\n').length;

  const content = (
    <div className="flex flex-col h-full bg-[#FFFDF9] text-[#1E293B]">
      {/* Playground Header */}
      <div className="bg-[#1E293B] text-white px-5 py-3.5 flex items-center justify-between border-b-4 border-amber-400">
        <div className="flex items-center gap-3">
          <div className="bg-amber-400 p-1.5 rounded-lg text-[#1E293B]">
            <Terminal size={22} className="stroke-[2.5]" />
          </div>
          <div>
            <h2 className="font-comic text-lg md:text-xl tracking-wide">{title}</h2>
            <p className="text-xs text-slate-300">Python 3 Web Engine • Interactive Console</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={startCodeReplay}
            disabled={isRunning || isTracing}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
              isReplayMode
                ? 'bg-amber-400 text-slate-900 shadow-md ring-2 ring-amber-300'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white'
            }`}
            title="Step-by-step visual execution of your code"
          >
            <Film size={14} />
            <span>{isTracing ? 'Tracing...' : isReplayMode ? 'Replay Active' : 'Code Replay'}</span>
          </button>

          {onClose && (
            <button
              onClick={() => {
                soundFX.playPop();
                onClose();
              }}
              className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 transition-colors"
              aria-label="Close playground"
            >
              <X size={20} />
            </button>
          )}
        </div>
      </div>

      {/* Preset selector bar */}
      <div className="bg-slate-100 border-b border-slate-200 px-4 py-2 flex items-center gap-2 overflow-x-auto text-xs no-scrollbar">
        <span className="font-bold text-slate-600 shrink-0 flex items-center gap-1">
          <Sparkles size={13} className="text-amber-500" /> Presets:
        </span>
        {STARTER_PRESETS.map((preset, idx) => (
          <button
            key={idx}
            onClick={() => selectPreset(idx)}
            className={`px-2.5 py-1 rounded-md font-medium shrink-0 transition-all ${
              activePreset === idx
                ? 'bg-[#1E293B] text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-300'
            }`}
          >
            {preset.title}
          </button>
        ))}
      </div>

      {/* Editor & Console Split Body OR Replay Viewer */}
      {isReplayMode && traceResult ? (
        <CodeReplayViewer
          code={code}
          traceResult={traceResult}
          onCloseReplay={() => setIsReplayMode(false)}
        />
      ) : (
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-slate-300 overflow-hidden min-h-[460px]">
        {/* Left: Code Editor */}
        <div className="flex flex-col bg-[#1E293B] text-slate-100 relative overflow-hidden">
          {/* Editor Action Bar */}
          <div className="bg-[#0F172A] px-4 py-2 flex items-center justify-between border-b border-slate-700 text-xs text-slate-300 font-mono">
            <span className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span> main.py
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={copyCode}
                className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 flex items-center gap-1 text-slate-200 transition-colors"
                title="Copy code"
              >
                {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                <span>{copied ? 'Copied!' : 'Copy'}</span>
              </button>
              <button
                onClick={resetCode}
                className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 flex items-center gap-1 text-slate-200 transition-colors"
                title="Reset code"
              >
                <RotateCcw size={14} />
                <span>Reset</span>
              </button>
            </div>
          </div>

          {/* Line Numbers + Textarea Container */}
          <div className="flex-1 flex overflow-auto font-mono text-sm leading-relaxed p-2">
            <div className="py-2 px-2 text-right text-slate-500 select-none bg-[#0F172A] rounded-l text-xs font-mono min-w-[34px]">
              {Array.from({ length: Math.max(lineCount, 12) }).map((_, i) => (
                <div key={i}>{i + 1}</div>
              ))}
            </div>
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              spellCheck={false}
              autoCapitalize="off"
              autoComplete="off"
              className="flex-1 py-2 px-3 bg-[#1E293B] text-emerald-300 focus:outline-none resize-none font-mono text-sm leading-relaxed"
              placeholder="# Type your Python code here..."
            />
          </div>

          {/* Action Button Bar */}
          <div className="p-3 bg-[#0F172A] border-t border-slate-700 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <PipCharacter mood="coding" size={32} />
              <span className="hidden sm:inline">Choose step-by-step Replay or Run!</span>
            </div>

            <div className="flex items-center gap-2.5">
              <button
                onClick={startCodeReplay}
                disabled={isRunning || isTracing}
                className="comic-button px-4 py-2.5 bg-gradient-to-r from-sky-400 to-indigo-400 hover:from-sky-300 hover:to-indigo-300 text-slate-900 font-extrabold text-xs sm:text-sm rounded-lg flex items-center gap-1.5 cursor-pointer shadow-md disabled:opacity-50"
                title="Watch step-by-step visual execution of your code"
              >
                <Film size={16} className="text-slate-900" />
                <span>{isTracing ? 'Tracing...' : 'Code Replay'}</span>
              </button>

              <button
                onClick={runCode}
                disabled={isRunning || isTracing}
                className="comic-button px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-900 font-extrabold text-xs sm:text-sm rounded-lg flex items-center gap-2 disabled:opacity-50 cursor-pointer shadow-md"
              >
                <Play size={16} className="fill-slate-900" />
                <span>{isRunning ? 'Running...' : 'Run Code'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right: Output Console & Error Guidance */}
        <div className="flex flex-col bg-[#FAF8F5] overflow-y-auto">
          {/* Console Header */}
          <div className="bg-slate-200 px-4 py-2 border-b border-slate-300 flex items-center justify-between text-xs font-bold text-slate-700">
            <span className="flex items-center gap-1.5">
              <Terminal size={14} /> Console Output
            </span>
            <div className="flex items-center gap-2">
              {output && !error && (
                <span className="text-emerald-700 font-mono text-[11px] bg-emerald-100 px-2 py-0.5 rounded">
                  Exit Code: 0 (Success)
                </span>
              )}
              <button
                onClick={startCodeReplay}
                disabled={isRunning || isTracing}
                className="text-[11px] font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 px-2 py-0.5 rounded flex items-center gap-1 cursor-pointer transition-colors"
                title="Watch execution visualized line by line"
              >
                <Film size={12} />
                <span>Watch Replay</span>
              </button>
            </div>
          </div>

          {/* Interactive input() Modal Bar if waiting for input */}
          {inputPrompt && (
            <div className="p-4 bg-amber-50 border-b-2 border-amber-300 animate-pulse">
              <div className="flex items-start gap-3">
                <div
                  onClick={() => speakText(inputPrompt, 'byte', 'playground-prompt')}
                  className="cursor-pointer"
                  title="Click to hear Byte speak this prompt"
                >
                  <ByteCharacter
                    mood="surprised"
                    size={48}
                    isSpeaking={speakingId === 'playground-prompt'}
                  />
                </div>
                <form onSubmit={handleInputSubmit} className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-amber-900 flex items-center gap-1">
                      <MessageSquare size={14} /> {inputPrompt}
                    </label>
                    <button
                      type="button"
                      onClick={() => speakText(inputPrompt, 'byte', 'playground-prompt')}
                      className="text-[10px] font-bold text-sky-800 bg-sky-100 px-2 py-0.5 rounded-full flex items-center gap-1 hover:bg-sky-200 cursor-pointer"
                    >
                      {speakingId === 'playground-prompt' ? <Square size={10} className="fill-sky-800" /> : <Volume2 size={10} />}
                      <span>{speakingId === 'playground-prompt' ? 'Stop' : 'Hear Byte 🇮🇳'}</span>
                    </button>
                  </div>
                  <div className="flex gap-2">
                    <input
                      ref={inputFieldRef}
                      type="text"
                      value={userInputValue}
                      onChange={(e) => setUserInputValue(e.target.value)}
                      placeholder="Type your answer here..."
                      className="flex-1 px-3 py-1.5 text-sm bg-white border-2 border-amber-400 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                    />
                    <button
                      type="submit"
                      className="px-4 py-1.5 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-md shadow-sm cursor-pointer"
                    >
                      Submit
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Console Text Area */}
          <div className="flex-1 p-4 font-mono text-sm leading-relaxed overflow-y-auto">
            {error ? (
              <div className="space-y-4">
                {/* Error Banner */}
                <div className="p-3 bg-rose-50 border-2 border-rose-300 rounded-lg text-rose-800 text-xs">
                  <div className="flex items-center gap-2 font-bold mb-1 text-rose-900 text-sm">
                    <AlertCircle size={16} /> Python Traceback (Error)
                  </div>
                  <pre className="whitespace-pre-wrap font-mono mt-1 text-rose-700">{error}</pre>
                </div>

                {/* Bugsy Friendly Guidance */}
                {beginnerTip && (
                  <div
                    onClick={() => speakText(beginnerTip, 'bugsy', 'playground-bugsy')}
                    className={`comic-panel p-4 bg-purple-50 border-2 border-purple-800 cursor-pointer transition-all ${
                      speakingId === 'playground-bugsy'
                        ? 'ring-4 ring-purple-300 bg-purple-100/70 border-purple-600 shadow-md'
                        : 'hover:border-purple-600'
                    }`}
                    title="Click to hear Bugsy speak this clue in Indian English"
                  >
                    <div className="flex items-start gap-3">
                      <BugsyCharacter
                        mood="thinking"
                        size={56}
                        isSpeaking={speakingId === 'playground-bugsy'}
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <div className="font-comic text-xs uppercase tracking-wider text-purple-900 font-bold">
                            Bugsy & Pip's Detective Clue:
                          </div>
                          <span className="text-[10px] font-bold text-purple-800 bg-purple-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                            {speakingId === 'playground-bugsy' ? (
                              <>
                                <Square size={10} className="fill-purple-800" />
                                Bugsy Speaking 🇮🇳
                              </>
                            ) : (
                              <>
                                <Volume2 size={10} />
                                Tap to listen 🇮🇳
                              </>
                            )}
                          </span>
                        </div>
                        <p className="text-xs text-purple-950 font-sans mt-1 leading-relaxed">
                          "{beginnerTip}"
                        </p>
                        {speakingId === 'playground-bugsy' && (
                          <div className="mt-2 flex items-center gap-1 text-[10px] text-purple-800 font-mono">
                            <span className="w-1 bg-purple-600 rounded-full animate-eq-1" />
                            <span className="w-1 bg-purple-600 rounded-full animate-eq-2" />
                            <span className="w-1 bg-purple-600 rounded-full animate-eq-3" />
                            <span className="ml-1">Speaking with Indian detective accent...</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : output ? (
              <div className="bg-slate-900 text-emerald-400 p-4 rounded-lg shadow-inner font-mono whitespace-pre-wrap text-sm leading-relaxed">
                {output}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400">
                <ByteCharacter mood="happy" size={72} />
                <p className="font-bold text-slate-600 mt-2">Console Ready</p>
                <p className="text-xs max-w-xs mt-1">
                  Click "Run Code" to execute your instructions and see the output here!
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    )}
    </div>
  );

  if (!isModal) {
    return <div className="comic-panel shadow-lg overflow-hidden h-full">{content}</div>;
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 md:p-6 animate-in fade-in">
      <div className="w-full max-w-5xl h-[88vh] comic-panel shadow-2xl flex flex-col overflow-hidden">
        {content}
      </div>
    </div>
  );
};
