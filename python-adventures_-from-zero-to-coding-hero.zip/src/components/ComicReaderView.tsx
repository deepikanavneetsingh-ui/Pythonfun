import React, { useState, useEffect, useRef } from 'react';
import { Chapter, Lesson, ComicPanel } from '../types/curriculum';
import { PipCharacter, AlexCharacter, ByteCharacter, BugsyCharacter, ComicSoundFx } from '../characters/CharacterSvgs';
import { soundFX } from '../utils/soundEffects';
import { speechService } from '../utils/speechService';
import {
  ChevronLeft,
  ChevronRight,
  Grid,
  Maximize2,
  Bookmark,
  ArrowRight,
  Code,
  Volume2,
  VolumeX,
  Play,
  Square,
  Sparkles,
  Wand2,
  Lock
} from 'lucide-react';
import { getChapterByNumber } from '../data/chapters';

interface ComicReaderProps {
  chapter: Chapter;
  lesson: Lesson;
  onOpenLessonExplanation: () => void;
  onOpenPlayground: (codeSnippet?: string) => void;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
  onNextLesson?: () => void;
  onPrevLesson?: () => void;
  onNextChapter?: () => void;
  isAuthenticated?: boolean;
  onRequireAuth?: (chapterNumber: number) => void;
}

export const ComicReaderView: React.FC<ComicReaderProps> = ({
  chapter,
  lesson,
  onOpenLessonExplanation,
  onOpenPlayground,
  isBookmarked,
  onToggleBookmark,
  onNextLesson,
  onPrevLesson,
  onNextChapter,
  isAuthenticated = false,
  onRequireAuth
}) => {
  const [panelByPanel, setPanelByPanel] = useState<boolean>(false);
  const [activePanelIndex, setActivePanelIndex] = useState<number>(0);
  const [speakingPanelId, setSpeakingPanelId] = useState<string | null>(null);
  const [isAutoPlaying, setIsAutoPlaying] = useState<boolean>(false);
  const [isMagicalTransitioning, setIsMagicalTransitioning] = useState<boolean>(false);

  const nextChapterNumber = chapter.number < 20 ? chapter.number + 1 : null;
  const nextChapter = nextChapterNumber ? getChapterByNumber(nextChapterNumber) : null;
  const isNextChapterLocked = nextChapterNumber !== null && nextChapterNumber > 1 && !isAuthenticated;

  const handleMagicalNextChapter = () => {
    if (isNextChapterLocked) {
      soundFX.playPop();
      if (onRequireAuth) {
        onRequireAuth(nextChapterNumber);
      }
      return;
    }

    soundFX.playMagicChime();
    setIsMagicalTransitioning(true);
    speechService.stop();

    setTimeout(() => {
      setIsMagicalTransitioning(false);
      if (onNextChapter) {
        onNextChapter();
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 850);
  };

  const panels = lesson.comicPanels;
  const currentPanel = panels[activePanelIndex] || panels[0];
  const autoPlayIndexRef = useRef<number>(0);

  // Stop speech when lesson changes or component unmounts
  useEffect(() => {
    speechService.stop();
    setSpeakingPanelId(null);
    setIsAutoPlaying(false);
    return () => {
      speechService.stop();
    };
  }, [lesson.id]);

  const stopSpeech = () => {
    speechService.stop();
    setSpeakingPanelId(null);
    setIsAutoPlaying(false);
  };

  const speakPanel = (panel: ComicPanel) => {
    if (speakingPanelId === panel.id) {
      stopSpeech();
      return;
    }

    setIsAutoPlaying(false);
    setSpeakingPanelId(panel.id);
    soundFX.playPop();

    speechService.speak(
      panel.dialogue,
      panel.speaker as any,
      panel.id,
      () => setSpeakingPanelId(panel.id),
      () => setSpeakingPanelId((current) => (current === panel.id ? null : current)),
      () => setSpeakingPanelId(null)
    );
  };

  // Autoplay all panels in sequence with Indian English dialect
  const startAutoPlay = () => {
    if (isAutoPlaying) {
      stopSpeech();
      return;
    }

    soundFX.playPop();
    setIsAutoPlaying(true);
    autoPlayIndexRef.current = 0;
    playNextAutoPanel(0);
  };

  const playNextAutoPanel = (index: number) => {
    if (index >= panels.length) {
      setIsAutoPlaying(false);
      setSpeakingPanelId(null);
      soundFX.playSuccess();
      return;
    }

    const panel = panels[index];
    setSpeakingPanelId(panel.id);
    if (panelByPanel) {
      setActivePanelIndex(index);
    }

    speechService.speak(
      panel.dialogue,
      panel.speaker as any,
      panel.id,
      () => setSpeakingPanelId(panel.id),
      () => {
        setSpeakingPanelId(null);
        autoPlayIndexRef.current = index + 1;
        // Small pause between characters speaking
        setTimeout(() => {
          playNextAutoPanel(index + 1);
        }, 450);
      },
      () => {
        setIsAutoPlaying(false);
        setSpeakingPanelId(null);
      }
    );
  };

  const renderCharacter = (speaker: string, mood: any, size = 120, isSpeaking = false) => {
    switch (speaker) {
      case 'pip':
        return <PipCharacter mood={mood} size={size} isSpeaking={isSpeaking} />;
      case 'alex':
        return <AlexCharacter mood={mood} size={size} isSpeaking={isSpeaking} />;
      case 'byte':
        return <ByteCharacter mood={mood} size={size} isSpeaking={isSpeaking} />;
      case 'bugsy':
        return <BugsyCharacter mood={mood} size={size} isSpeaking={isSpeaking} />;
      default:
        return <PipCharacter mood={mood} size={size} isSpeaking={isSpeaking} />;
    }
  };

  const getSpeakerBadge = (speaker: string) => {
    switch (speaker) {
      case 'pip':
        return { name: 'Pip the Python', bg: 'bg-emerald-600', text: 'text-white' };
      case 'alex':
        return { name: 'Alex the Learner', bg: 'bg-amber-500', text: 'text-slate-900' };
      case 'byte':
        return { name: 'Byte the Robot', bg: 'bg-sky-500', text: 'text-slate-900' };
      case 'bugsy':
        return { name: 'Bugsy the Bug', bg: 'bg-purple-600', text: 'text-white' };
      default:
        return { name: 'Narrator', bg: 'bg-slate-700', text: 'text-white' };
    }
  };

  return (
    <div className="space-y-6">
      {/* Chapter & Lesson Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border-2 border-slate-900 shadow-sm">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-700 uppercase tracking-widest">
            <span>{chapter.actTitle}</span>
            <span>•</span>
            <span>Chapter {chapter.number}</span>
          </div>
          <h1 className="font-comic text-2xl md:text-3xl text-slate-900 mt-0.5">
            {lesson.title}
          </h1>
          <p className="text-xs md:text-sm text-slate-600 mt-1 max-w-2xl font-medium">
            Objective: {lesson.objective}
          </p>
        </div>

        {/* View mode toggle, Indian Dialect Auto-Read & bookmarks */}
        <div className="flex flex-wrap items-center gap-2 self-start md:self-auto">
          {/* Native Indian Voice Auto-Read Scene Button */}
          <button
            onClick={startAutoPlay}
            className={`comic-button px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
              isAutoPlaying
                ? 'bg-rose-500 hover:bg-rose-600 text-white animate-pulse'
                : 'bg-amber-400 hover:bg-amber-300 text-slate-900'
            }`}
            title="Listen to all characters speak with native Indian English dialect"
          >
            {isAutoPlaying ? <Square size={14} className="fill-white" /> : <Volume2 size={15} />}
            <span>{isAutoPlaying ? 'Stop Reading' : '🇮🇳 Read Scene Aloud'}</span>
          </button>

          <button
            onClick={onToggleBookmark}
            className={`p-2 rounded-xl border-2 transition-all cursor-pointer ${
              isBookmarked
                ? 'bg-amber-100 border-amber-500 text-amber-900'
                : 'bg-white border-slate-300 text-slate-500 hover:border-slate-800'
            }`}
            title="Bookmark lesson"
          >
            <Bookmark size={18} className={isBookmarked ? 'fill-amber-500' : ''} />
          </button>

          <button
            onClick={() => {
              soundFX.playPop();
              setPanelByPanel(!panelByPanel);
            }}
            className="comic-button px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
          >
            {panelByPanel ? <Grid size={15} /> : <Maximize2 size={15} />}
            <span>{panelByPanel ? 'All Panels' : 'Panel Focus'}</span>
          </button>
        </div>
      </div>

      {/* Comic Panels Display */}
      {!panelByPanel ? (
        /* Grid Overview Mode */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {panels.map((panel, idx) => {
            const badge = getSpeakerBadge(panel.speaker);
            const isSpeakingThis = speakingPanelId === panel.id;

            return (
              <div
                key={panel.id}
                className={`comic-panel p-5 flex flex-col justify-between bg-white relative transition-all ${
                  isSpeakingThis
                    ? 'border-amber-500 ring-4 ring-amber-300/60 shadow-xl'
                    : 'hover:-translate-y-1'
                }`}
              >
                {/* Panel number indicator */}
                <div className="absolute top-2 left-3 text-[11px] font-comic font-black text-slate-400 select-none">
                  PANEL #{idx + 1}
                </div>

                {/* Sound FX if present */}
                {panel.soundFx && (
                  <div className="absolute top-2 right-2 z-10">
                    <ComicSoundFx
                      text={panel.soundFx}
                      color={panel.soundFxColor || '#F59E0B'}
                    />
                  </div>
                )}

                {/* Top Narration if any */}
                {panel.narration && (
                  <div className="mt-4 mb-3 p-2 bg-amber-50 border border-amber-300 rounded-md text-[11px] font-serif italic text-amber-950">
                    {panel.narration}
                  </div>
                )}

                {/* Comic Speech Bubble with Interactive Speech & Audio Equalizer */}
                <div
                  onClick={() => speakPanel(panel)}
                  className={`relative border-2 rounded-2xl p-4 my-2 speech-bubble-bottom cursor-pointer transition-all ${
                    isSpeakingThis
                      ? 'bg-amber-50 border-amber-500 animate-speaking-bubble'
                      : 'bg-slate-50 border-slate-800 hover:bg-amber-50/40'
                  }`}
                  title="Click to hear this character speak in native Indian English"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${badge.bg} ${badge.text}`}
                    >
                      {badge.name}
                    </span>

                    {/* Speaker trigger / speaking indicator */}
                    <div className="flex items-center gap-1.5">
                      {isSpeakingThis ? (
                        <div className="flex items-center gap-1 text-[10px] text-amber-800 font-bold bg-amber-200/70 px-2 py-0.5 rounded-full">
                          <span className="w-1 bg-amber-700 rounded-full animate-eq-1" />
                          <span className="w-1 bg-amber-700 rounded-full animate-eq-2" />
                          <span className="w-1 bg-amber-700 rounded-full animate-eq-3" />
                          <span className="w-1 bg-amber-700 rounded-full animate-eq-4" />
                          <span className="ml-1 text-[9px] font-mono">Speaking 🇮🇳</span>
                        </div>
                      ) : (
                        <span className="text-slate-400 hover:text-amber-600 transition-colors flex items-center gap-1 text-[10px] font-bold">
                          <Volume2 size={14} />
                          <span className="text-[9px]">Speak</span>
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="font-comic-bubble text-sm sm:text-base text-slate-900 leading-snug">
                    "{panel.dialogue}"
                  </p>
                </div>

                {/* Character Illustration & Visual Action */}
                <div className="mt-4 flex items-end justify-between">
                  <div className="text-[11px] text-slate-500 max-w-[140px] italic">
                    {panel.visualAction}
                  </div>
                  <div
                    onClick={() => speakPanel(panel)}
                    className="shrink-0 transform hover:scale-105 transition-transform cursor-pointer"
                    title="Click character to speak in native Indian English"
                  >
                    {renderCharacter(panel.speaker, panel.mood, 110, isSpeakingThis)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Panel-by-Panel Focus Mode */
        <div className="comic-panel p-6 sm:p-8 bg-white max-w-3xl mx-auto shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <span className="font-comic text-xs uppercase tracking-wider text-slate-500">
              Panel {activePanelIndex + 1} of {panels.length}
            </span>
            {currentPanel.soundFx && (
              <ComicSoundFx
                text={currentPanel.soundFx}
                color={currentPanel.soundFxColor || '#F59E0B'}
              />
            )}
          </div>

          {currentPanel.narration && (
            <div className="p-3 bg-amber-50 border-2 border-amber-300 rounded-lg text-xs italic text-amber-950 mb-4">
              {currentPanel.narration}
            </div>
          )}

          {/* Large Speech Bubble with Talking Indicator */}
          {(() => {
            const isSpeakingCurrent = speakingPanelId === currentPanel.id;
            return (
              <div
                onClick={() => speakPanel(currentPanel)}
                className={`border-3 rounded-2xl p-6 relative speech-bubble-bottom cursor-pointer transition-all ${
                  isSpeakingCurrent
                    ? 'bg-amber-50 border-amber-500 animate-speaking-bubble'
                    : 'bg-slate-50 border-slate-900 hover:bg-amber-50/30'
                }`}
                title="Click to hear this character speak in native Indian English"
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${
                      getSpeakerBadge(currentPanel.speaker).bg
                    } ${getSpeakerBadge(currentPanel.speaker).text}`}
                  >
                    {getSpeakerBadge(currentPanel.speaker).name}
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      speakPanel(currentPanel);
                    }}
                    className="comic-button px-3 py-1 bg-amber-300 hover:bg-amber-400 text-slate-900 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    {isSpeakingCurrent ? (
                      <>
                        <Square size={12} className="fill-slate-900" />
                        <span>Stop Voice</span>
                      </>
                    ) : (
                      <>
                        <Volume2 size={13} />
                        <span>🇮🇳 Speak Dialogue</span>
                      </>
                    )}
                  </button>
                </div>

                <p className="font-comic-bubble text-lg sm:text-xl text-slate-900 mt-3 leading-relaxed">
                  "{currentPanel.dialogue}"
                </p>

                {isSpeakingCurrent && (
                  <div className="mt-3 pt-2 border-t border-amber-200 flex items-center gap-1.5 text-xs text-amber-800 font-bold">
                    <span className="w-1.5 bg-amber-600 rounded-full animate-eq-1" />
                    <span className="w-1.5 bg-amber-600 rounded-full animate-eq-2" />
                    <span className="w-1.5 bg-amber-600 rounded-full animate-eq-3" />
                    <span className="w-1.5 bg-amber-600 rounded-full animate-eq-4" />
                    <span className="ml-1 text-[11px]">Speaking with Indian native dialect...</span>
                  </div>
                )}
              </div>
            );
          })()}

          {/* Large Character Pose with Mouth Animation */}
          <div className="mt-8 flex items-center justify-between px-4">
            <div className="text-xs text-slate-500 max-w-xs italic">
              {currentPanel.visualAction}
            </div>
            <div
              onClick={() => speakPanel(currentPanel)}
              className="transform scale-110 cursor-pointer hover:scale-115 transition-transform"
              title="Click character to speak dialogue in native Indian English"
            >
              {renderCharacter(
                currentPanel.speaker,
                currentPanel.mood,
                150,
                speakingPanelId === currentPanel.id
              )}
            </div>
          </div>

          {/* Panel Navigation Bar */}
          <div className="mt-8 pt-4 border-t border-slate-200 flex items-center justify-between">
            <button
              onClick={() => {
                soundFX.playPop();
                stopSpeech();
                setActivePanelIndex((prev) => Math.max(0, prev - 1));
              }}
              disabled={activePanelIndex === 0}
              className="comic-button px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold flex items-center gap-1 disabled:opacity-30 cursor-pointer"
            >
              <ChevronLeft size={16} /> Previous Panel
            </button>

            <div className="flex gap-1.5">
              {panels.map((_, i) => (
                <button
                  key={i}
                  onClick={() => {
                    soundFX.playPop();
                    stopSpeech();
                    setActivePanelIndex(i);
                  }}
                  className={`w-3 h-3 rounded-full border border-slate-900 cursor-pointer ${
                    i === activePanelIndex ? 'bg-amber-400' : 'bg-slate-200'
                  }`}
                />
              ))}
            </div>

            <button
              onClick={() => {
                soundFX.playPop();
                stopSpeech();
                setActivePanelIndex((prev) => Math.min(panels.length - 1, prev + 1));
              }}
              disabled={activePanelIndex === panels.length - 1}
              className="comic-button px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold flex items-center gap-1 disabled:opacity-30 cursor-pointer"
            >
              Next Panel <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}

      {/* Next Actions Bar: Lesson Explanation & Live Playground */}
      <div className="comic-panel p-6 bg-gradient-to-r from-amber-50 to-emerald-50 border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 text-center sm:text-left">
          <PipCharacter mood="happy" size={56} />
          <div>
            <h3 className="font-comic text-base md:text-lg text-slate-900">
              Ready to learn the rules behind the story?
            </h3>
            <p className="text-xs text-slate-600">
              Explore the line-by-line explanation, real-life analogy, and run live Python code!
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center sm:justify-end gap-2.5">
          <button
            onClick={() => onOpenPlayground(lesson.workedExample.code)}
            className="comic-button px-3.5 py-2.5 bg-white hover:bg-slate-100 text-slate-900 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Code size={15} /> Try in Playground
          </button>

          <button
            onClick={onOpenLessonExplanation}
            className="comic-button px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-900 text-xs font-extrabold rounded-xl flex items-center gap-1.5 shadow-md cursor-pointer"
          >
            <span>Read Lesson & Code</span>
            <ArrowRight size={15} />
          </button>

          {/* Magical Next Chapter Button */}
          <button
            onClick={handleMagicalNextChapter}
            disabled={isMagicalTransitioning}
            className={`relative group comic-button px-5 py-2.5 rounded-xl font-comic font-black text-xs text-white shadow-lg flex items-center gap-2 cursor-pointer transition-all transform hover:scale-105 active:scale-95 border-2 border-slate-900 overflow-hidden ${
              isNextChapterLocked
                ? 'bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 hover:from-amber-500 hover:to-yellow-400'
                : 'bg-gradient-to-r from-purple-600 via-indigo-600 to-amber-500 hover:from-purple-500 hover:via-indigo-500 hover:to-amber-400 animate-magic-shimmer animate-magic-halo'
            }`}
            title={
              isNextChapterLocked
                ? `Chapter ${nextChapter?.number} is locked! Register free on homepage to unlock.`
                : nextChapter
                ? `Magically warp to Chapter ${nextChapter.number}: ${nextChapter.title}`
                : 'Magically view Graduation Certificate'
            }
          >
            {/* Shimmer light sweep reflection beam */}
            <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full bg-gradient-to-r from-transparent via-white/35 to-transparent transition-transform duration-1000 ease-in-out pointer-events-none" />

            {isNextChapterLocked ? (
              <Lock size={15} className="text-amber-200 shrink-0" />
            ) : (
              <Sparkles size={16} className="text-amber-300 animate-magic-sparkle fill-amber-300 shrink-0" />
            )}

            <span className="tracking-wide">
              {isNextChapterLocked
                ? `Chapter ${nextChapter?.number} (Register to Unlock 🔒)`
                : nextChapter
                ? `Next Chapter ${nextChapter.number}`
                : 'Graduation 🎓'}
            </span>

            {isNextChapterLocked ? (
              <ArrowRight size={15} className="group-hover:translate-x-1 transition-transform shrink-0 text-amber-200" />
            ) : (
              <>
                <Wand2 size={14} className="text-yellow-300 group-hover:rotate-12 transition-transform shrink-0" />
                <ArrowRight size={15} className="group-hover:translate-x-1 transition-transform shrink-0" />
              </>
            )}
          </button>
        </div>
      </div>

      {/* Magical Chapter Warp Transition Overlay */}
      {isMagicalTransitioning && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
          {/* Swirling background magic elements */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none flex items-center justify-center">
            <div className="w-96 h-96 rounded-full border-4 border-dashed border-amber-400/40 animate-spin" style={{ animationDuration: '6s' }} />
            <div className="absolute w-[520px] h-[520px] rounded-full border-2 border-dashed border-purple-500/30 animate-spin" style={{ animationDuration: '9s', animationDirection: 'reverse' }} />
            <div className="absolute inset-0 bg-radial from-amber-500/20 via-purple-600/20 to-transparent opacity-60 animate-pulse" />
          </div>

          {/* Central Magical Portal Card */}
          <div className="relative z-10 comic-panel p-8 bg-gradient-to-br from-slate-900 via-purple-950 to-slate-900 border-4 border-amber-400 shadow-2xl rounded-3xl text-center max-w-md w-full space-y-4 animate-portal-zoom">
            <div className="flex justify-center -space-x-2">
              <span className="p-3 bg-amber-400/20 rounded-2xl border border-amber-400 animate-magic-sparkle">
                <Sparkles size={32} className="text-amber-300" />
              </span>
              <span className="p-3 bg-purple-500/20 rounded-2xl border border-purple-400 animate-bounce">
                <Wand2 size={32} className="text-purple-300" />
              </span>
            </div>

            <div className="space-y-1">
              <div className="text-xs font-comic font-black uppercase tracking-widest text-amber-400 flex items-center justify-center gap-1.5">
                <span>✨ MAGICAL CHAPTER WARP ✨</span>
              </div>
              <h3 className="font-comic text-2xl sm:text-3xl text-white">
                {nextChapter ? `Entering Chapter ${nextChapter.number}` : 'Graduation Finale'}
              </h3>
              <p className="text-sm font-bold text-amber-200">
                {nextChapter ? nextChapter.title : 'All 20 Chapters Mastered!'}
              </p>
            </div>

            {nextChapter && (
              <div className="p-3 bg-white/10 rounded-xl border border-amber-400/30 text-xs text-slate-200 font-medium leading-relaxed">
                "{nextChapter.tagline || nextChapter.subtitle}"
              </div>
            )}

            <div className="pt-2 flex items-center justify-center gap-2 text-xs font-mono font-bold text-amber-300">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              <span>Summoning Next Python Realm...</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
