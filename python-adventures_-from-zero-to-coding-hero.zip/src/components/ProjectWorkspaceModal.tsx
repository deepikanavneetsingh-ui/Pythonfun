import React, { useState } from 'react';
import { GuidedProject } from '../types/curriculum';
import { ByteCharacter, PipCharacter } from '../characters/CharacterSvgs';
import { pythonRunner } from '../runtime/pythonRunner';
import { soundFX } from '../utils/soundEffects';
import { Play, CheckCircle2, RotateCcw, X, Hammer, Eye, FileText, Terminal } from 'lucide-react';
import confetti from 'canvas-confetti';

interface ProjectWorkspaceProps {
  project: GuidedProject;
  onClose: () => void;
  onCompleteProject: (projectId: string) => void;
  isCompleted?: boolean;
}

export const ProjectWorkspaceModal: React.FC<ProjectWorkspaceProps> = ({
  project,
  onClose,
  onCompleteProject,
  isCompleted = false
}) => {
  const [code, setCode] = useState<string>(project.starterCode || project.solutionCode);
  const [output, setOutput] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [showSolution, setShowSolution] = useState<boolean>(false);
  const [completed, setCompleted] = useState<boolean>(isCompleted);

  const runProjectCode = async () => {
    setIsRunning(true);
    setError(null);
    setOutput('');
    soundFX.playPop();

    try {
      const res = await pythonRunner.execute(code);
      if (res.error) {
        setError(res.error);
        soundFX.playBugZap();
      } else {
        setOutput(res.output);
        soundFX.playSuccess();
      }
    } catch (err: any) {
      setError(String(err));
      soundFX.playBugZap();
    } finally {
      setIsRunning(false);
    }
  };

  const handleMarkComplete = () => {
    setCompleted(true);
    soundFX.playFanfare();
    onCompleteProject(project.id);
    try {
      confetti({ particleCount: 70, spread: 60 });
    } catch {}
  };

  const resetCode = () => {
    setCode(project.starterCode);
    setOutput('');
    setError(null);
    soundFX.playPop();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="w-full max-w-5xl max-h-[94vh] comic-panel shadow-2xl flex flex-col bg-[#FFFDF9] overflow-hidden">
        {/* Header */}
        <div className="bg-[#0F172A] text-white px-5 py-3.5 flex items-center justify-between border-b-4 border-amber-400">
          <div className="flex items-center gap-3">
            <div className="bg-amber-400 p-1.5 rounded-lg text-slate-900">
              <Hammer size={22} className="stroke-[2.5]" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-amber-300 uppercase tracking-widest">
                Chapter {project.chapterNumber} Guided Practical Project
              </div>
              <h2 className="font-comic text-lg md:text-xl text-white">{project.title}</h2>
            </div>
          </div>

          <button
            onClick={() => {
              soundFX.playPop();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
          >
            <X size={20} />
          </button>
        </div>

        {/* Project Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Project Specs, Planning & Pseudocode (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="comic-panel p-4 bg-amber-50/50 border-amber-900">
              <h3 className="font-comic text-xs uppercase tracking-wider text-amber-900 mb-1 flex items-center gap-1.5">
                <FileText size={15} /> Mission Brief
              </h3>
              <p className="text-xs text-slate-800 leading-relaxed font-medium">
                {project.description}
              </p>
            </div>

            {/* Requirements Checklist */}
            <div className="comic-panel p-4 bg-white border-slate-900">
              <h4 className="font-comic text-xs uppercase tracking-wider text-slate-900 mb-2">
                Requirements Checklist:
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-700">
                {project.requirements.map((req, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0 text-[10px] mt-0.5">
                      ✓
                    </span>
                    <span>{req}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Pseudocode Blueprint */}
            <div className="comic-panel p-4 bg-slate-900 text-white border-slate-900">
              <h4 className="font-comic text-xs uppercase tracking-wider text-amber-400 mb-2 flex items-center gap-1.5">
                <ByteCharacter mood="coding" size={24} /> Byte\'s Pseudocode Blueprint:
              </h4>
              <pre className="text-xs font-mono text-slate-300 p-2.5 bg-slate-800 rounded-lg overflow-x-auto whitespace-pre-wrap">
                {project.pseudocode}
              </pre>
            </div>

            {/* Solution Toggle */}
            <div className="comic-panel p-3 bg-slate-100 border-slate-300">
              <button
                onClick={() => {
                  soundFX.playPop();
                  setShowSolution(!showSolution);
                }}
                className="w-full text-xs font-bold text-slate-700 hover:text-slate-900 flex items-center justify-between"
              >
                <span className="flex items-center gap-1.5">
                  <Eye size={14} /> {showSolution ? 'Hide Reference Solution' : 'View Reference Solution'}
                </span>
                <span>{showSolution ? '▲' : '▼'}</span>
              </button>

              {showSolution && (
                <pre className="mt-3 p-3 bg-slate-900 text-emerald-300 rounded font-mono text-xs overflow-x-auto whitespace-pre-wrap">
                  {project.solutionCode}
                </pre>
              )}
            </div>
          </div>

          {/* Right: Code Workspace & Live Execution (7 cols) */}
          <div className="lg:col-span-7 flex flex-col space-y-4">
            <div className="comic-panel overflow-hidden border-slate-900 flex-1 flex flex-col min-h-[300px]">
              <div className="bg-[#1E293B] text-slate-200 px-4 py-2 flex items-center justify-between text-xs font-mono">
                <span>project.py</span>
                <button
                  onClick={resetCode}
                  className="hover:text-amber-400 flex items-center gap-1 transition-colors"
                >
                  <RotateCcw size={13} /> Reset Starter
                </button>
              </div>
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full flex-1 bg-[#0F172A] text-emerald-300 font-mono text-xs sm:text-sm p-4 focus:outline-none resize-none min-h-[220px]"
                spellCheck={false}
              />
              <div className="p-3 bg-[#1E293B] border-t border-slate-700 flex items-center justify-between">
                <span className="text-xs text-slate-400">Run code to verify your project!</span>
                <button
                  onClick={runProjectCode}
                  disabled={isRunning}
                  className="comic-button px-5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-900 font-extrabold text-xs rounded-lg flex items-center gap-2 cursor-pointer shadow-sm"
                >
                  <Play size={15} className="fill-slate-900" />
                  <span>{isRunning ? 'Running...' : 'Run Project'}</span>
                </button>
              </div>
            </div>

            {/* Output Screen */}
            <div className="comic-panel p-4 bg-slate-50 border-slate-400">
              <div className="text-xs font-bold text-slate-600 flex items-center gap-1.5 mb-2">
                <Terminal size={14} /> Execution Console
              </div>
              {error ? (
                <pre className="p-3 bg-rose-50 border border-rose-300 rounded text-rose-800 text-xs font-mono whitespace-pre-wrap">
                  {error}
                </pre>
              ) : output ? (
                <pre className="p-3 bg-slate-900 text-emerald-400 rounded text-xs font-mono whitespace-pre-wrap shadow-inner">
                  {output}
                </pre>
              ) : (
                <div className="p-4 text-center text-xs text-slate-400 font-mono">
                  Output will appear here after clicking Run Project.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-100 border-t border-slate-300 flex items-center justify-between">
          <button
            onClick={onClose}
            className="text-xs font-bold text-slate-600 hover:text-slate-900 px-3 py-1.5"
          >
            Close Workspace
          </button>

          <button
            onClick={handleMarkComplete}
            className={`comic-button px-6 py-2.5 rounded-xl font-extrabold text-xs flex items-center gap-2 cursor-pointer ${
              completed
                ? 'bg-emerald-600 text-white'
                : 'bg-emerald-500 hover:bg-emerald-400 text-white'
            }`}
          >
            <CheckCircle2 size={16} />
            <span>{completed ? 'Project Completed ✓' : 'Mark Project Complete'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
