export type CharacterId = 'pip' | 'alex' | 'byte' | 'bugsy';

export interface ComicPanel {
  id: string;
  speaker: CharacterId;
  mood: 'happy' | 'thinking' | 'surprised' | 'explaining' | 'coding';
  dialogue: string;
  narration?: string;
  visualAction: string;
  soundFx?: string;
  soundFxColor?: string;
}

export interface LineExplanation {
  line: number;
  code: string;
  explanation: string;
}

export interface WorkedExample {
  id: string;
  title: string;
  code: string;
  expectedOutput: string;
  lineByLine: LineExplanation[];
  newlyIntroduced: string[];
}

export interface PredictionQuestion {
  question: string;
  codeSnippet: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface PracticeChallenge {
  title: string;
  prompt: string;
  starterCode: string;
  solutionCode: string;
  hints: [string, string, string]; // 3 progressive hints
  testCases?: { expectedSubstring?: string; mustInclude?: string[] };
}

export interface CommonMistake {
  title: string;
  badCode: string;
  whyItFails: string;
  fixedCode: string;
  tip: string;
}

export interface Lesson {
  id: string;
  chapterNumber: number;
  lessonNumber: number;
  title: string;
  objective: string;
  comicPanels: ComicPanel[];
  realLifeProblem: string;
  analogy: {
    title: string;
    description: string;
    icon: string;
  };
  conceptText: string;
  syntaxRules: string[];
  workedExample: WorkedExample;
  prediction: PredictionQuestion;
  practiceChallenge: PracticeChallenge;
  commonMistake: CommonMistake;
  threeKeyTakeaways: [string, string, string];
}

export interface QuizQuestion {
  id: string;
  question: string;
  codeSnippet?: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  misconceptionHint?: string;
}

export interface DebugChallenge {
  id: string;
  title: string;
  scenario: string;
  buggyCode: string;
  fixedCode: string;
  errorType: 'SyntaxError' | 'TypeError' | 'NameError' | 'IndexError' | 'LogicError' | 'ZeroDivisionError' | 'KeyError' | 'AttributeError';
  hint1Line: string;
  hint2Concept: string;
  hint3Fix: string;
  explanation: string;
}

export interface BranchingChoice {
  text: string;
  pythonSnippet: string;
  feedback: string;
  leadsToNodeId: string;
  isEducationalSuccess: boolean;
}

export interface BranchingNode {
  id: string;
  speaker: CharacterId;
  mood: 'happy' | 'thinking' | 'surprised' | 'explaining' | 'coding';
  situationText: string;
  codeDisplay?: string;
  choices: BranchingChoice[];
}

export interface BranchingStory {
  id: string;
  title: string;
  startNodeId: string;
  nodes: Record<string, BranchingNode>;
}

export interface GuidedProject {
  id: string;
  chapterNumber: number;
  title: string;
  description: string;
  requirements: string[];
  planningSteps: string[];
  pseudocode: string;
  starterCode: string;
  solutionCode: string;
  verificationTips?: string[];
}

export interface Chapter {
  number: number;
  act: 1 | 2 | 3 | 4;
  actTitle: string;
  title: string;
  subtitle: string;
  tagline: string;
  icon: string;
  summary: string;
  lessons: Lesson[];
  quiz: QuizQuestion[];
  debugChallenge: DebugChallenge;
  guidedProject: GuidedProject;
  branchingStory?: BranchingStory;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'code' | 'quiz' | 'debug' | 'milestone' | 'hero';
  unlockedAt?: string;
}

export interface UserProgress {
  completedLessons: string[]; // lesson ids e.g. "ch1-l1"
  completedChapters: number[]; // chapter numbers
  quizScores: Record<number, { score: number; total: number; date: string }>;
  solvedDebugs: string[]; // debug ids
  completedProjects: string[]; // project ids
  unlockedAchievements: string[];
  bookmarks: string[]; // lesson ids
  notes: Record<string, string>;
  lastVisitedChapter: number;
  lastVisitedLesson: string;
  streakCount: number;
  lastActiveDate: string;
  userName: string;
  soundEnabled: boolean;
  fontSize: 'small' | 'medium' | 'large';
  codeTheme: 'dark' | 'light';
  dailyLessonsCompleted?: Record<string, number>; // date 'YYYY-MM-DD' -> count
}
