export type UserRole = 'admin' | 'student';

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  password: string; // Stored securely in client auth registry
  role: UserRole;
  createdAt: string;
  lastLoginAt: string;
  avatarCharacter?: 'pip' | 'alex' | 'byte' | 'bugsy';
  gradeOrLevel?: string;
  enrolledChapter?: number;
}

export interface AuthSession {
  user: UserAccount | null;
  isAuthenticated: boolean;
}
