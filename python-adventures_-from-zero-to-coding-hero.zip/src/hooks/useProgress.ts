import { useState, useEffect, useCallback } from 'react';
import { UserProgress } from '../types/curriculum';
import { ALL_ACHIEVEMENTS } from '../data/achievementsData';
import { soundFX } from '../utils/soundEffects';

const STORAGE_KEY = 'python_adventures_progress_v2';

const DEFAULT_PROGRESS: UserProgress = {
  completedLessons: [],
  completedChapters: [],
  quizScores: {},
  solvedDebugs: [],
  completedProjects: [],
  unlockedAchievements: [],
  bookmarks: [],
  notes: {},
  lastVisitedChapter: 1,
  lastVisitedLesson: 'ch1-l1',
  streakCount: 1,
  lastActiveDate: new Date().toISOString().split('T')[0],
  userName: 'Adventurer',
  soundEnabled: true,
  fontSize: 'medium',
  codeTheme: 'dark',
  dailyLessonsCompleted: {}
};

export function useProgress() {
  const [progress, setProgress] = useState<UserProgress>(() => {
    if (typeof window === 'undefined') return DEFAULT_PROGRESS;
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...DEFAULT_PROGRESS, ...parsed };
      }
    } catch {
      // Fallback
    }
    return DEFAULT_PROGRESS;
  });

  // Keep soundFX manager synced with preference
  useEffect(() => {
    soundFX.enabled = progress.soundEnabled;
  }, [progress.soundEnabled]);

  // Save to localStorage whenever progress changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    } catch (e) {
      console.warn('Failed to save progress to localStorage', e);
    }
  }, [progress]);

  // Calculate streak on load
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    if (progress.lastActiveDate !== today) {
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      const isConsecutive = progress.lastActiveDate === yesterday;
      const newStreak = isConsecutive ? progress.streakCount + 1 : 1;
      setProgress((prev) => ({
        ...prev,
        lastActiveDate: today,
        streakCount: newStreak
      }));
    }
  }, [progress.lastActiveDate, progress.streakCount]);

  // Check achievements after any state update
  const checkAchievements = useCallback((current: UserProgress) => {
    const newUnlocked = [...current.unlockedAchievements];

    // 1. First Program
    if (current.completedLessons.length >= 1 && !newUnlocked.includes('first_program')) {
      newUnlocked.push('first_program');
      soundFX.playFanfare();
    }
    // 2. Variable Explorer (Ch 3 completed)
    if (current.completedLessons.includes('ch3-l1') && !newUnlocked.includes('variable_explorer')) {
      newUnlocked.push('variable_explorer');
    }
    // 3. Math Magician (Ch 4 completed)
    if (current.completedLessons.includes('ch4-l1') && !newUnlocked.includes('math_magician')) {
      newUnlocked.push('math_magician');
    }
    // 4. Text Wizard (Ch 5 completed)
    if (current.completedLessons.includes('ch5-l1') && !newUnlocked.includes('text_wizard')) {
      newUnlocked.push('text_wizard');
    }
    // 5. Interactive Master (Ch 6 completed)
    if (current.completedLessons.includes('ch6-l1') && !newUnlocked.includes('interactive_master')) {
      newUnlocked.push('interactive_master');
    }
    // 6. Decision Maker (Ch 7 completed)
    if (current.completedLessons.includes('ch7-l1') && !newUnlocked.includes('decision_maker')) {
      newUnlocked.push('decision_maker');
    }
    // 7. Logic Knight (Ch 8 completed)
    if (current.completedLessons.includes('ch8-l1') && !newUnlocked.includes('logic_knight')) {
      newUnlocked.push('logic_knight');
    }
    // 8. Loop Explorer (Ch 9 completed)
    if (current.completedLessons.includes('ch9-l1') && !newUnlocked.includes('loop_explorer')) {
      newUnlocked.push('loop_explorer');
    }
    // 9. Collection Keeper (Ch 10 or 11 completed)
    if (current.completedLessons.includes('ch10-l1') && !newUnlocked.includes('collection_keeper')) {
      newUnlocked.push('collection_keeper');
    }
    // 10. Function Builder (Ch 12 completed)
    if (current.completedLessons.includes('ch12-l1') && !newUnlocked.includes('function_builder')) {
      newUnlocked.push('function_builder');
    }
    // 11. Bug Detective (3 debugs solved)
    if (current.solvedDebugs.length >= 3 && !newUnlocked.includes('bug_detective')) {
      newUnlocked.push('bug_detective');
      soundFX.playFanfare();
    }
    // 12. Quiz Ace (scored 100% on any quiz)
    const hasPerfectQuiz = Object.values(current.quizScores).some((q) => q.score === q.total && q.total > 0);
    if (hasPerfectQuiz && !newUnlocked.includes('quiz_ace')) {
      newUnlocked.push('quiz_ace');
      soundFX.playFanfare();
    }
    // 13. Project Creator (2 projects completed)
    if (current.completedProjects.length >= 2 && !newUnlocked.includes('project_creator')) {
      newUnlocked.push('project_creator');
    }
    // 14. 7 Day Streak (7 consecutive days active)
    if (current.streakCount >= 7 && !newUnlocked.includes('seven_day_streak')) {
      newUnlocked.push('seven_day_streak');
      soundFX.playFanfare();
    }
    // 15. Completed First 5 Chapters (Act 1 Master)
    const hasFirst5 = [1, 2, 3, 4, 5].every((ch) => current.completedChapters.includes(ch));
    if (hasFirst5 && !newUnlocked.includes('first_5_chapters')) {
      newUnlocked.push('first_5_chapters');
      soundFX.playFanfare();
    }
    // 16. Python Hero (Ch 20 completed!)
    if (current.completedChapters.includes(20) && !newUnlocked.includes('python_hero')) {
      newUnlocked.push('python_hero');
      soundFX.playFanfare();
    }

    if (newUnlocked.length !== current.unlockedAchievements.length) {
      return { ...current, unlockedAchievements: newUnlocked };
    }
    return current;
  }, []);

  const completeLesson = useCallback((lessonId: string, chapterNumber: number) => {
    setProgress((prev) => {
      const isNew = !prev.completedLessons.includes(lessonId);
      const lessons = isNew
        ? [...prev.completedLessons, lessonId]
        : prev.completedLessons;

      const chapters = prev.completedChapters.includes(chapterNumber)
        ? prev.completedChapters
        : [...prev.completedChapters, chapterNumber];

      const today = new Date().toISOString().split('T')[0];
      const dailyMap = prev.dailyLessonsCompleted || {};
      const updatedDaily = {
        ...dailyMap,
        [today]: isNew ? (dailyMap[today] || 0) + 1 : (dailyMap[today] || 1)
      };

      soundFX.playSuccess();

      const updated: UserProgress = {
        ...prev,
        completedLessons: lessons,
        completedChapters: chapters,
        dailyLessonsCompleted: updatedDaily,
        lastVisitedChapter: chapterNumber,
        lastVisitedLesson: lessonId
      };
      return checkAchievements(updated);
    });
  }, [checkAchievements]);

  const saveQuizScore = useCallback((chapterNum: number, score: number, total: number) => {
    setProgress((prev) => {
      const updated: UserProgress = {
        ...prev,
        quizScores: {
          ...prev.quizScores,
          [chapterNum]: { score, total, date: new Date().toISOString() }
        }
      };
      soundFX.playSuccess();
      return checkAchievements(updated);
    });
  }, [checkAchievements]);

  const solveDebug = useCallback((debugId: string) => {
    setProgress((prev) => {
      if (prev.solvedDebugs.includes(debugId)) return prev;
      soundFX.playBugZap();
      const updated: UserProgress = {
        ...prev,
        solvedDebugs: [...prev.solvedDebugs, debugId]
      };
      return checkAchievements(updated);
    });
  }, [checkAchievements]);

  const completeProject = useCallback((projectId: string) => {
    setProgress((prev) => {
      if (prev.completedProjects.includes(projectId)) return prev;
      soundFX.playSuccess();
      const updated: UserProgress = {
        ...prev,
        completedProjects: [...prev.completedProjects, projectId]
      };
      return checkAchievements(updated);
    });
  }, [checkAchievements]);

  const toggleBookmark = useCallback((lessonId: string) => {
    setProgress((prev) => {
      const exists = prev.bookmarks.includes(lessonId);
      const bookmarks = exists
        ? prev.bookmarks.filter((id) => id !== lessonId)
        : [...prev.bookmarks, lessonId];
      soundFX.playPop();
      return { ...prev, bookmarks };
    });
  }, []);

  const saveNote = useCallback((lessonId: string, noteText: string) => {
    setProgress((prev) => ({
      ...prev,
      notes: { ...prev.notes, [lessonId]: noteText }
    }));
  }, []);

  const setUserName = useCallback((userName: string) => {
    setProgress((prev) => ({ ...prev, userName }));
  }, []);

  const toggleSound = useCallback(() => {
    setProgress((prev) => {
      const next = !prev.soundEnabled;
      soundFX.enabled = next;
      return { ...prev, soundEnabled: next };
    });
  }, []);

  const setFontSize = useCallback((fontSize: 'small' | 'medium' | 'large') => {
    setProgress((prev) => ({ ...prev, fontSize }));
  }, []);

  const setCodeTheme = useCallback((codeTheme: 'dark' | 'light') => {
    setProgress((prev) => ({ ...prev, codeTheme }));
  }, []);

  const resetAllProgress = useCallback(() => {
    setProgress(DEFAULT_PROGRESS);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {}
    soundFX.playPop();
  }, []);

  const unlockAllChapters = useCallback(() => {
    setProgress((prev) => {
      const allChNums = Array.from({ length: 20 }, (_, i) => i + 1);
      const allLessons: string[] = [];
      for (let ch = 1; ch <= 20; ch++) {
        for (let l = 1; l <= 4; l++) {
          allLessons.push(`ch${ch}-l${l}`);
        }
      }
      return {
        ...prev,
        completedChapters: allChNums,
        completedLessons: Array.from(new Set([...prev.completedLessons, ...allLessons]))
      };
    });
    soundFX.playFanfare();
  }, []);

  return {
    progress,
    completeLesson,
    saveQuizScore,
    solveDebug,
    completeProject,
    toggleBookmark,
    saveNote,
    setUserName,
    toggleSound,
    setFontSize,
    setCodeTheme,
    resetAllProgress,
    unlockAllChapters,
    allAchievements: ALL_ACHIEVEMENTS
  };
}
