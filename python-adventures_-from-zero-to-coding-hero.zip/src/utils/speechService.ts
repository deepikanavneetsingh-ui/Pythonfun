/**
 * Native Character Speech Synthesis Service
 * Provides differentiated character voices:
 * - Alex: Voice of a 15-year-old boy (youthful, energetic, curious, bright pitch: 1.28)
 * - Pip: Deep voice of a Noble person (dignified baritone, stately, regal cadence: 0.66)
 * - Byte: Comic character robot (retro mechanical, monotone, square-wave chirp FX, pitch: 0.52)
 * - Bugsy: Squeaky detective bug (quirky, lively cadence: 1.48)
 */

import { soundFX } from './soundEffects';

export type CharacterSpeaker = 'pip' | 'alex' | 'byte' | 'bugsy' | 'narrator';

export interface VoiceProfile {
  pitch: number;
  rate: number;
  lang: string;
  description: string;
  preferredVoices: string[];
}

export const CHARACTER_PROFILES: Record<CharacterSpeaker, VoiceProfile> = {
  // Alex: Authentic teenager boy — energetic, curious adolescent male pitch and upbeat cadence
  alex: {
    pitch: 1.34,
    rate: 1.08,
    lang: 'en-IN',
    description: 'Teenager Boy • Energetic, curious, adolescent male timbre',
    preferredVoices: [
      'rishi',
      'oliver',
      'junior',
      'guy',
      'alex',
      'daniel',
      'fred',
      'google uk english male',
      'male'
    ]
  },

  // Pip: Deep voice of a Noble person — stately, majestic baritone, wise elder instructor
  pip: {
    pitch: 0.66,
    rate: 0.86,
    lang: 'en-IN',
    description: 'Noble Mentor • Deep, majestic, aristocratic baritone',
    preferredVoices: [
      'george',
      'david',
      'arthur',
      'prabhat',
      'ravi',
      'great britain',
      'uk english male',
      'male',
      'james',
      'en-gb',
      'en-in'
    ]
  },

  // Byte: Robot in a comic character — flat mechanical synth, staccato, retro droid chirps
  byte: {
    pitch: 0.52,
    rate: 1.0,
    lang: 'en-IN',
    description: 'Comic Robot • Monotone mechanical synthesis with robotic chirps',
    preferredVoices: [
      'zarvox',
      'trinoids',
      'cellos',
      'bad news',
      'robot',
      'mechanical',
      'google us english',
      'en-us',
      'en-in'
    ]
  },

  // Bugsy: Squeaky detective bug
  bugsy: {
    pitch: 1.48,
    rate: 1.15,
    lang: 'en-IN',
    description: 'Detective Bug • Squeaky, fast-paced investigator',
    preferredVoices: [
      'veena',
      'heera',
      'victoria',
      'kavya',
      'samantha',
      'en-in'
    ]
  },

  narrator: {
    pitch: 0.95,
    rate: 0.95,
    lang: 'en-IN',
    description: 'Course Narrator • Neutral, clear pedagogical cadence',
    preferredVoices: ['en-in', 'en-gb', 'en-us']
  }
};

type SpeechListener = (speakingId: string | null) => void;

class SpeechService {
  private synth: SpeechSynthesis | null = null;
  private voices: SpeechSynthesisVoice[] = [];
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private currentId: string | null = null;
  private currentSpeaker: CharacterSpeaker | null = null;
  private listeners: Set<SpeechListener> = new Set();
  public enabled: boolean = true;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.loadVoices();
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.loadVoices();
      }
      setTimeout(() => this.loadVoices(), 300);
      setTimeout(() => this.loadVoices(), 1000);
    }
  }

  private loadVoices() {
    if (!this.synth) return;
    const v = this.synth.getVoices();
    if (v && v.length > 0) {
      this.voices = v;
    }
  }

  public subscribe(listener: SpeechListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(id: string | null) {
    this.currentId = id;
    this.listeners.forEach((listener) => {
      try {
        listener(id);
      } catch (err) {
        console.error('Speech listener error:', err);
      }
    });
  }

  public getCurrentId(): string | null {
    return this.currentId;
  }

  public getCurrentSpeaker(): CharacterSpeaker | null {
    return this.currentSpeaker;
  }

  /**
   * Character-specific voice selector: Finds the best matching system voice
   * tailored for each personality (Noble deep baritone for Pip, 15yo boy for Alex, comic robot for Byte).
   */
  public getVoiceForCharacter(speaker: CharacterSpeaker): SpeechSynthesisVoice | null {
    this.loadVoices();
    if (!this.voices || this.voices.length === 0) {
      return null;
    }

    const profile = CHARACTER_PROFILES[speaker] || CHARACTER_PROFILES.pip;
    const preferred = profile.preferredVoices;

    // Special case for Alex: strictly filter for teenager boy / young male voices
    if (speaker === 'alex') {
      const femaleKeywords = [
        'female', 'woman', 'girl', 'neerja', 'kavya', 'heera', 'veena',
        'samantha', 'victoria', 'zira', 'hazel', 'susan', 'karen', 'moira',
        'fiona', 'tessa', 'catherine', 'allison', 'ava', 'zoe'
      ];

      // 1. Try preferred young boy/male voices
      for (const key of preferred) {
        const match = this.voices.find((v) => {
          const name = (v.name || '').toLowerCase();
          const isFemale = femaleKeywords.some((f) => name.includes(f));
          return !isFemale && name.includes(key);
        });
        if (match) return match;
      }

      // 2. Try any non-female Indian English or English voice
      const maleFallback = this.voices.find((v) => {
        const name = (v.name || '').toLowerCase();
        const lang = (v.lang || '').toLowerCase();
        const isFemale = femaleKeywords.some((f) => name.includes(f));
        return !isFemale && lang.startsWith('en');
      });
      if (maleFallback) return maleFallback;
    }

    // Default flow for other speakers:
    // 1. Try finding a preferred voice matching the character's exact timbre profile
    for (const key of preferred) {
      const match = this.voices.find((v) => {
        const name = (v.name || '').toLowerCase();
        const lang = (v.lang || '').toLowerCase().replace('_', '-');
        return name.includes(key) || lang === key;
      });
      if (match) {
        return match;
      }
    }

    // 2. Fallback to native Indian English voice if available
    const indianVoice = this.voices.find((v) => {
      const lang = (v.lang || '').toLowerCase().replace('_', '-');
      const name = (v.name || '').toLowerCase();
      return (
        lang === 'en-in' ||
        name.includes('india') ||
        name.includes('heera') ||
        name.includes('ravi') ||
        name.includes('neerja') ||
        name.includes('rishi')
      );
    });
    if (indianVoice) return indianVoice;

    // 3. Fallback to any English voice
    const englishVoice = this.voices.find((v) => (v.lang || '').toLowerCase().startsWith('en'));
    return englishVoice || this.voices[0] || null;
  }

  /**
   * Preprocesses technical code tokens and applies character-specific phrasing:
   * - Byte receives comic mechanical cadence formatting
   * - Pip receives stately noble cadence
   * - Alex receives casual, punchy 15yo boy cadence
   */
  public cleanTextForSpeech(text: string, speaker: CharacterSpeaker = 'pip'): string {
    let cleaned = text
      .replace(/print\(\s*f?["'](.*?)["']\s*\)/gi, 'print statement "$1"')
      .replace(/print\(\)/gi, 'print function')
      .replace(/input\(\s*["'](.*?)["']\s*\)/gi, 'input prompt "$1"')
      .replace(/input\(\)/gi, 'input function')
      .replace(/#\s*/g, 'Comment: ')
      .replace(/==/g, ' is equal to ')
      .replace(/!=/g, ' is not equal to ')
      .replace(/>=/g, ' is greater than or equal to ')
      .replace(/<=/g, ' is less than or equal to ')
      .replace(/len\((.*?)\)/gi, 'length of $1')
      .replace(/def\s+(\w+)/gi, 'define function $1')
      .replace(/elif/gi, 'else if')
      .replace(/\{\}/g, 'curly braces')
      .replace(/\[\]/g, 'brackets')
      .replace(/\(\)/g, 'parentheses')
      .replace(/->/g, 'returns')
      .replace(/__name__/g, 'dunder name')
      .replace(/__main__/g, 'dunder main')
      .replace(/\+/g, ' plus ')
      .replace(/\*/g, ' times ');

    // Character personality text styling
    if (speaker === 'byte') {
      // Comic robot phrasing: insert slight mechanical pauses for staccato rhythm
      cleaned = cleaned
        .replace(/\. /g, '... ')
        .replace(/! /g, '. ')
        .replace(/\? /g, '... Query detected. ');
    }

    return cleaned;
  }

  /**
   * Speaks character dialogue with distinctly separated voices:
   * - Alex: 15-year-old boy
   * - Pip: Deep noble mentor
   * - Byte: Comic character robot (with retro chirps)
   */
  public speak(
    text: string,
    speaker: CharacterSpeaker = 'pip',
    idOrOnStart?: string | (() => void),
    onStartOrEnd?: () => void,
    onEndOrError?: () => void,
    onError?: (err: any) => void
  ) {
    if (!this.enabled || !this.synth) {
      if (typeof idOrOnStart === 'function') idOrOnStart();
      else if (onStartOrEnd) onStartOrEnd();
      return;
    }

    let speechId = 'generic';
    let startCb: (() => void) | undefined;
    let endCb: (() => void) | undefined;
    let errCb: ((err: any) => void) | undefined;

    if (typeof idOrOnStart === 'string') {
      speechId = idOrOnStart;
      startCb = onStartOrEnd;
      endCb = onEndOrError;
      errCb = onError;
    } else if (typeof idOrOnStart === 'function') {
      startCb = idOrOnStart;
      endCb = onStartOrEnd;
      errCb = onEndOrError;
    }

    // Stop ongoing speech
    this.stop();

    // If Byte (comic robot), play comic retro robot square-wave bleeps
    if (speaker === 'byte') {
      soundFX.playRobotChirp();
    }

    this.currentSpeaker = speaker;
    const clean = this.cleanTextForSpeech(text, speaker);
    const utterance = new SpeechSynthesisUtterance(clean);
    this.currentUtterance = utterance;
    if (typeof window !== 'undefined') {
      (window as any).__currentUtterance = utterance;
    }

    // Apply character voice profile
    const profile = CHARACTER_PROFILES[speaker] || CHARACTER_PROFILES.pip;
    utterance.pitch = profile.pitch;
    utterance.rate = profile.rate;
    utterance.lang = profile.lang;

    const matchedVoice = this.getVoiceForCharacter(speaker);
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    utterance.onstart = () => {
      this.notify(speechId);
      if (startCb) startCb();
    };

    const cleanup = () => {
      this.currentUtterance = null;
      this.currentSpeaker = null;
      if (typeof window !== 'undefined') {
        delete (window as any).__currentUtterance;
      }
      this.notify(null);
    };

    utterance.onend = () => {
      cleanup();
      if (endCb) endCb();
    };

    utterance.onerror = (e) => {
      cleanup();
      if (errCb) errCb(e);
      if (endCb) endCb();
    };

    try {
      this.synth.speak(utterance);
    } catch (e) {
      cleanup();
      if (endCb) endCb();
    }
  }

  public stop() {
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch {}
      this.currentUtterance = null;
      this.currentSpeaker = null;
      if (typeof window !== 'undefined') {
        delete (window as any).__currentUtterance;
      }
      this.notify(null);
    }
  }

  public isSpeaking(): boolean {
    return this.synth !== null && this.synth.speaking;
  }
}

export const speechService = new SpeechService();
